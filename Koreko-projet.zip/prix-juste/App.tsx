import React, { useEffect } from 'react';
import { AppState, type AppStateStatus } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { SQLiteProvider, useSQLiteContext } from 'expo-sqlite';
import RootNavigator from './src/navigation/RootNavigator';
import { DATABASE_NAME, migrateDbIfNeeded } from './src/db/database';
import { getSettings } from './src/db/repositories/settingsRepo';
import { setCurrencySymbol } from './src/utils/format';
import { ThemeProvider } from './src/theme/ThemeContext';
import { I18nProvider } from './src/i18n/I18nContext';
import { AccessProvider } from './src/access/AccessContext';
import { HintsProvider } from './src/hints/HintsContext';
import { runAutoBackup } from './src/backup/autoBackup';

function CurrencyBootstrap({ children }: { children: React.ReactNode }) {
  const db = useSQLiteContext();
  useEffect(() => {
    getSettings(db).then((s) => setCurrencySymbol(s.currencySymbol));
  }, [db]);
  return <>{children}</>;
}

// Writes an automatic backup to the user's chosen folder (if configured) on
// cold start and every time the app leaves the foreground, so recipes and
// ingredients survive even if the app itself gets uninstalled or reset.
function AutoBackupRunner({ children }: { children: React.ReactNode }) {
  const db = useSQLiteContext();
  useEffect(() => {
    runAutoBackup(db);
    const subscription = AppState.addEventListener('change', (nextState: AppStateStatus) => {
      if (nextState === 'background' || nextState === 'inactive') {
        runAutoBackup(db);
      }
    });
    return () => subscription.remove();
  }, [db]);
  return <>{children}</>;
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <SQLiteProvider databaseName={DATABASE_NAME} onInit={migrateDbIfNeeded}>
          <CurrencyBootstrap>
            <AutoBackupRunner>
              <I18nProvider>
                <ThemeProvider>
                  <AccessProvider>
                    <HintsProvider>
                      <NavigationContainer>
                        <RootNavigator />
                      </NavigationContainer>
                    </HintsProvider>
                  </AccessProvider>
                </ThemeProvider>
              </I18nProvider>
            </AutoBackupRunner>
          </CurrencyBootstrap>
        </SQLiteProvider>
        <StatusBar style="dark" />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
