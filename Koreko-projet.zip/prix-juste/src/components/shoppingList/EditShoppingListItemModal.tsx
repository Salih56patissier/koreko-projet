import React, { useEffect, useState } from 'react';
import { Modal, View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { PurchaseUnitPicker } from '../ingredient/UnitFields';
import KeyboardAwareScrollView from '../common/KeyboardAwareScrollView';
import FieldLabel from '../common/FieldLabel';
import PrimaryButton from '../common/PrimaryButton';
import SupplierPicker from '../ingredient/SupplierPicker';
import { PurchaseUnit, ShoppingListItem, Supplier } from '../../types/models';
import { purchaseUnitLabel } from '../../utils/format';


interface Props {
  visible: boolean;
  item: ShoppingListItem | null;
  suppliers: Supplier[];
  onSuppliersChanged: (suppliers: Supplier[]) => void;
  onSubmit: (data: { quantity: number; unit: PurchaseUnit; supplierId: string | null }) => void;
  onDelete: () => void;
  onCancel: () => void;
}

export default function EditShoppingListItemModal({
  visible,
  item,
  suppliers,
  onSuppliersChanged,
  onSubmit,
  onDelete,
  onCancel,
}: Props) {
  const { accent } = useTheme();
  const { t } = useI18n();
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState<PurchaseUnit>('kg');
  const [supplierId, setSupplierId] = useState<string | null>(null);

  useEffect(() => {
    if (!visible || !item) return;
    setQuantity(String(item.quantity));
    setUnit(item.unit);
    setSupplierId(item.supplierId);
  }, [visible, item]);

  const canSubmit = parseFloat(quantity.replace(',', '.')) > 0;

  function handleSubmit() {
    onSubmit({ quantity: parseFloat(quantity.replace(',', '.')), unit, supplierId });
  }

  if (!item) return null;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.card}>
          <KeyboardAwareScrollView>
            <Text style={styles.title}>{item.ingredientName}</Text>

            <FieldLabel>{t('Quantité correspondante')}</FieldLabel>
            <TextInput
              style={inputStyles.input}
              value={quantity}
              onChangeText={setQuantity}
              keyboardType="decimal-pad"
              placeholder={t('ex: 500')}
              autoFocus
            />

            <FieldLabel>{t('Unité')}</FieldLabel>
            <PurchaseUnitPicker value={unit} onChange={setUnit} />

            <FieldLabel>{t('Fournisseur')}</FieldLabel>
            <SupplierPicker
              suppliers={suppliers}
              selectedId={supplierId}
              onSelect={setSupplierId}
              onSuppliersChanged={onSuppliersChanged}
            />

            <View style={styles.row}>
              <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={styles.flexBtn} />
              <PrimaryButton label={t('Valider')} disabled={!canSubmit} onPress={handleSubmit} style={styles.flexBtn} />
            </View>
            <PrimaryButton
              label={t('Retirer de la liste')}
              variant="danger"
              onPress={onDelete}
              style={{ marginTop: spacing.sm }}
            />
          </KeyboardAwareScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '90%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  unitRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  unitBtn: {
    flex: 1,
    paddingVertical: spacing.sm + 2,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  unitBtnText: {
    color: colors.text,
    fontWeight: '600',
  },
  unitBtnTextActive: {
    color: '#fff',
  },
  row: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  flexBtn: {
    flex: 1,
  },
});
