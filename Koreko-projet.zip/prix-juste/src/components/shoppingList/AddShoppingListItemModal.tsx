import React, { useEffect, useMemo, useState } from 'react';
import { Modal, View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSQLiteContext } from 'expo-sqlite';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import KeyboardAwareScrollView from '../common/KeyboardAwareScrollView';
import FieldLabel from '../common/FieldLabel';
import PrimaryButton from '../common/PrimaryButton';
import { Ingredient, PurchaseUnit } from '../../types/models';
import { createIngredient } from '../../db/repositories/ingredientsRepo';
import { useTheme } from '../../theme/ThemeContext';
import { useEditGuard } from '../../access/AccessContext';
import { useI18n } from '../../i18n/I18nContext';
import { PurchaseUnitPicker } from '../ingredient/UnitFields';
import { purchaseUnitLabel } from '../../utils/format';
import { normalizeSearch } from '../../utils/normalize';


interface Props {
  visible: boolean;
  ingredients: Ingredient[];
  // Présent = on saute l'étape de recherche (ex: appui depuis la fiche d'un ingrédient précis).
  fixedIngredient?: Ingredient;
  onSubmit: (data: { ingredientId: string; quantity: number; unit: PurchaseUnit }) => void;
  onCancel: () => void;
}

export default function AddShoppingListItemModal({ visible, ingredients, fixedIngredient, onSubmit, onCancel }: Props) {
  const db = useSQLiteContext();
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Ingredient | 'new' | undefined>(undefined);
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState<PurchaseUnit>('kg');

  useEffect(() => {
    if (!visible) return;
    setSearch('');
    setQuantity('');
    setSelected(fixedIngredient);
    setUnit(fixedIngredient?.purchaseUnit ?? 'kg');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, fixedIngredient]);

  const filtered = useMemo(
    () => ingredients.filter((i) => normalizeSearch(i.name).includes(normalizeSearch(search))),
    [ingredients, search]
  );
  const exactMatch = ingredients.some((i) => normalizeSearch(i.name) === normalizeSearch(search));

  const guard = useEditGuard();

  const canSubmit =
    !!selected &&
    parseFloat(quantity.replace(',', '.')) > 0 &&
    (selected !== 'new' || search.trim().length > 0);

  async function handleSubmit() {
    if (!selected) return;
    if (selected === 'new' && !guard()) {
      onCancel();
      return;
    }
    const parsedQuantity = parseFloat(quantity.replace(',', '.'));
    let ingredientId: string;
    if (selected === 'new') {
      ingredientId = await createIngredient(db, {
        name: search.trim(),
        purchasePrice: 0,
        purchaseQuantity: parsedQuantity,
        purchaseUnit: unit,
        vatRate: 0,
        categoryId: null,
      });
    } else {
      ingredientId = selected.id;
    }
    onSubmit({ ingredientId, quantity: parsedQuantity, unit });
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onCancel}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.card}>
          {!selected ? (
            <>
              <Text style={styles.title}>{t('Ajouter à la liste de courses')}</Text>
              <TextInput
                style={inputStyles.input}
                value={search}
                onChangeText={setSearch}
                placeholder={t('Rechercher un ingrédient...')}
                placeholderTextColor={colors.textMuted}
                autoFocus
              />
              <KeyboardAwareScrollView style={styles.list}>
                {filtered.length === 0 && <Text style={styles.emptyText}>{t('Aucun ingrédient trouvé.')}</Text>}
                {filtered.map((item) => (
                  <Pressable
                    key={item.id}
                    style={styles.ingredientRow}
                    onPress={() => {
                      setSelected(item);
                      // L'unité habituelle de l'ingrédient (œufs : pièce, farine : kg…), pas « kg » d'office.
                      setUnit(item.purchaseUnit);
                    }}
                  >
                    <Text style={styles.ingredientName}>{item.name}</Text>
                  </Pressable>
                ))}
                {search.trim().length > 0 && !exactMatch && (
                  <Pressable style={styles.newRow} onPress={() => setSelected('new')}>
                    <Ionicons name="add-circle-outline" size={18} color={accent} style={{ marginRight: spacing.sm }} />
                    <Text style={[styles.ingredientName, { color: accent }]}>
                      {t('Créer "{name}" comme nouvel ingrédient', { name: search.trim() })}
                    </Text>
                  </Pressable>
                )}
                <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={{ marginTop: spacing.md }} />
              </KeyboardAwareScrollView>
            </>
          ) : (
            <KeyboardAwareScrollView>
              {!fixedIngredient && (
                <Pressable style={styles.backRow} onPress={() => setSelected(undefined)}>
                  <Ionicons name="chevron-back" size={18} color={accentDark} />
                  <Text style={[styles.backText, { color: accentDark }]}>{t('Changer')}</Text>
                </Pressable>
              )}
              <Text style={styles.title}>{selected === 'new' ? search.trim() : selected.name}</Text>
              {selected === 'new' && <Text style={styles.newBadge}>{t('Nouvel ingrédient')}</Text>}

              <FieldLabel>{t('Quantité correspondante')}</FieldLabel>
              <TextInput
                style={inputStyles.input}
                value={quantity}
                onChangeText={setQuantity}
                keyboardType="decimal-pad"
                placeholder={t('ex: 500')}
                autoFocus
              />

              <FieldLabel>{t('Unité')}</FieldLabel>
              <PurchaseUnitPicker value={unit} onChange={setUnit} />

              <View style={styles.row}>
                <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={styles.flexBtn} />
                <PrimaryButton label={t('Ajouter')} disabled={!canSubmit} onPress={handleSubmit} style={styles.flexBtn} />
              </View>
            </KeyboardAwareScrollView>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'flex-end',
  },
  card: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '85%',
    minHeight: '40%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  list: {
    marginTop: spacing.sm,
  },
  ingredientRow: {
    paddingVertical: spacing.sm + 2,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  ingredientName: {
    fontSize: 15,
    color: colors.text,
    fontWeight: '600',
  },
  newRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.sm,
    padding: spacing.sm + 2,
    marginTop: spacing.xs,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderStyle: 'dashed',
  },
  newBadge: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.textMuted,
    marginBottom: spacing.sm,
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginTop: spacing.lg,
  },
  backRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  backText: {
    fontWeight: '600',
    marginLeft: 2,
  },
  unitRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  unitBtn: {
    flex: 1,
    paddingVertical: spacing.sm + 2,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  unitBtnText: {
    color: colors.text,
    fontWeight: '600',
  },
  unitBtnTextActive: {
    color: '#fff',
  },
  row: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  flexBtn: {
    flex: 1,
  },
});
