import React from 'react';
import { Modal, View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import KeyboardAwareScrollView from '../common/KeyboardAwareScrollView';
import PrimaryButton from '../common/PrimaryButton';
import { SupplierIngredientSuggestion } from '../../types/models';
import { purchaseUnitLabel } from '../../utils/format';

interface Props {
  visible: boolean;
  supplierName: string;
  suggestions: SupplierIngredientSuggestion[];
  // Ingrédients déjà dans la liste de courses pour ce fournisseur — affichés cochés, non
  // re-ajoutables, pour ne pas créer de doublons.
  alreadyAddedIds: Set<string>;
  onAdd: (suggestion: SupplierIngredientSuggestion) => void;
  onClose: () => void;
}

// Propose, quand on ouvre un fournisseur, tout ce qu'on lui a déjà acheté par le passé — pour ne
// rien oublier de ce qu'on prend d'habitude à cet endroit, sans avoir à tout retaper de mémoire.
export default function SupplierSuggestionsModal({
  visible,
  supplierName,
  suggestions,
  alreadyAddedIds,
  onAdd,
  onClose,
}: Props) {
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.card}>
          <Text style={styles.title}>{t('Tes habitudes chez {supplier}', { supplier: supplierName })}</Text>
          <Text style={styles.subtitle}>
            {t('Ce que tu as déjà acheté ici — touche pour ajouter à la liste.')}
          </Text>

          <KeyboardAwareScrollView style={styles.list}>
            {suggestions.length === 0 ? (
              <Text style={styles.emptyText}>{t("Pas encore d'historique d'achat pour ce fournisseur.")}</Text>
            ) : (
              suggestions.map((s) => {
                const added = alreadyAddedIds.has(s.ingredientId);
                return (
                  <Pressable
                    key={s.ingredientId}
                    style={[styles.row, added && styles.rowAdded]}
                    onPress={() => !added && onAdd(s)}
                    disabled={added}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={styles.ingredientName}>{s.ingredientName}</Text>
                      <Text style={styles.ingredientQty}>
                        {s.lastQuantity} {purchaseUnitLabel(s.lastUnit, t)}
                      </Text>
                    </View>
                    <Ionicons
                      name={added ? 'checkmark-circle' : 'add-circle-outline'}
                      size={24}
                      color={added ? colors.success : accent}
                    />
                  </Pressable>
                );
              })
            )}
          </KeyboardAwareScrollView>

          <PrimaryButton label={t('Fermer')} variant="secondary" onPress={onClose} style={{ marginTop: spacing.md }} />
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'flex-end',
  },
  card: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '85%',
    minHeight: '40%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  subtitle: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 2,
    marginBottom: spacing.sm,
  },
  list: {
    marginTop: spacing.xs,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm + 2,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  rowAdded: {
    opacity: 0.5,
  },
  ingredientName: {
    fontSize: 15,
    color: colors.text,
    fontWeight: '600',
  },
  ingredientQty: {
    fontSize: 12.5,
    color: colors.textMuted,
    marginTop: 1,
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginTop: spacing.lg,
  },
});
