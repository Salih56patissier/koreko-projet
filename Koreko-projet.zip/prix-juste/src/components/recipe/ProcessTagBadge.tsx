import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { radius, spacing } from '../../theme/colors';

export default function ProcessTagBadge({ name, color }: { name: string; color: string }) {
  return (
    <View style={[styles.badge, { backgroundColor: color + '22', borderColor: color }]}>
      <Text style={[styles.text, { color }]}>{name}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 4,
    borderRadius: radius.pill,
    borderWidth: 1,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
  },
  text: {
    fontSize: 12,
    fontWeight: '700',
  },
});
