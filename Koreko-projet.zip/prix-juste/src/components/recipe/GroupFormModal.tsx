import React, { useEffect, useRef, useState } from 'react';
import { Modal, View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import KeyboardAwareScrollView from '../common/KeyboardAwareScrollView';
import FieldLabel from '../common/FieldLabel';
import PrimaryButton from '../common/PrimaryButton';
import PromptModal from '../common/PromptModal';
import { useI18n } from '../../i18n/I18nContext';
import { ProcessAction, RecipeGroupWithItems } from '../../types/models';

interface Props {
  visible: boolean;
  group: RecipeGroupWithItems | null;
  processActions: ProcessAction[];
  onAddCustomAction: (name: string) => Promise<void>;
  onRenameAction: (actionId: string, newName: string) => Promise<void>;
  onDeleteAction: (actionId: string) => Promise<void>;
  onSave: (groupId: string, data: { name: string; instruction: string | null; tagIds: string[] }) => void;
  onDelete: (groupId: string) => void;
  onClose: () => void;
}

export default function GroupFormModal({
  visible,
  group,
  processActions,
  onAddCustomAction,
  onRenameAction,
  onDeleteAction,
  onSave,
  onDelete,
  onClose,
}: Props) {
  const { t } = useI18n();
  const [instruction, setInstruction] = useState('');
  // Une seule action par étape ("je choisis un mot") — c'est elle qui donne son nom à
  // l'étape (plus de champ "nom" séparé à remplir en double).
  const [tagId, setTagId] = useState<string | null>(null);
  const [addActionVisible, setAddActionVisible] = useState(false);
  const [renamingAction, setRenamingAction] = useState<ProcessAction | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Repère ce qui vient d'être chargé pour cette étape, pour ne sauvegarder que les vrais
  // changements de l'utilisateur — et non un booléen "premier rendu" qui, selon l'ordre exact
  // d'exécution des effets, pouvait aussi avaler la toute première sélection d'action.
  const loaded = useRef<{ instruction: string; tagId: string | null } | null>(null);

  useEffect(() => {
    if (visible && group) {
      const initialInstruction = group.instruction ?? '';
      const initialTagId = group.processTagIds[0] ?? null;
      setInstruction(initialInstruction);
      setTagId(initialTagId);
      loaded.current = { instruction: initialInstruction, tagId: initialTagId };
    }
  }, [visible, group?.id]);

  // Auto-save: no "Valider" button needed, matches the rest of the app.
  useEffect(() => {
    if (!group) return;
    if (loaded.current && loaded.current.instruction === instruction && loaded.current.tagId === tagId) {
      return; // rien de réellement changé par rapport à ce qui vient d'être chargé
    }
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      const tag = processActions.find((a) => a.id === tagId);
      onSave(group.id, {
        name: tag?.name ?? t('Étape'),
        instruction: instruction.trim() || null,
        tagIds: tagId ? [tagId] : [],
      });
    }, 400);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [instruction, tagId]);

  function selectTag(id: string) {
    setTagId((prev) => (prev === id ? null : id));
  }

  function handleLongPressAction(action: ProcessAction) {
    Alert.alert(action.name, undefined, [
      { text: t('Renommer'), onPress: () => setRenamingAction(action) },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: () =>
          Alert.alert(t('Supprimer "{label}" ?', { label: action.name }), t('Cette action est irréversible.'), [
            { text: t('Annuler'), style: 'cancel' },
            { text: t('Supprimer'), style: 'destructive', onPress: () => onDeleteAction(action.id) },
          ]),
      },
      { text: t('Annuler'), style: 'cancel' },
    ]);
  }

  if (!group) return null;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.card}>
          <KeyboardAwareScrollView>
            <Text style={styles.title}>{t("Groupe d'ingrédients")}</Text>
            <Text style={styles.helperText}>{t('Tout se sauvegarde automatiquement, tu peux fermer à tout moment.')}</Text>

            <FieldLabel>{t('Action de cette étape')}</FieldLabel>
            <Text style={styles.helperText}>
              {t('Choisis un mot (ex: Mélanger) — il devient le nom de l\'étape. Tape à nouveau pour le retirer. Appui long pour la renommer ou la supprimer.')}
            </Text>
            <View style={styles.chipWrap}>
              {processActions.map((action) => {
                const active = tagId === action.id;
                return (
                  <Pressable
                    key={action.id}
                    onPress={() => selectTag(action.id)}
                    onLongPress={() => handleLongPressAction(action)}
                    style={[
                      styles.chip,
                      { borderColor: action.color },
                      active && { backgroundColor: action.color },
                    ]}
                  >
                    <Text style={[styles.chipText, { color: active ? '#fff' : action.color }]}>{action.name}</Text>
                  </Pressable>
                );
              })}
              <Pressable style={styles.addChip} onPress={() => setAddActionVisible(true)}>
                <Ionicons name="add" size={16} color={colors.textMuted} />
                <Text style={styles.addChipText}>{t('Action perso')}</Text>
              </Pressable>
            </View>

            <FieldLabel>{t('Instruction (apparaît sur la fiche imprimée)')}</FieldLabel>
            <TextInput
              style={[inputStyles.input, inputStyles.multiline]}
              value={instruction}
              onChangeText={setInstruction}
              placeholder={t('ex: Chauffer à 85°C sans bouillir, puis verser sur le chocolat en 3 fois')}
              multiline
            />

            <View style={styles.row}>
              <PrimaryButton
                label={t('Supprimer ce groupe')}
                variant="danger"
                onPress={() => onDelete(group.id)}
                style={styles.flexBtn}
              />
              <PrimaryButton label={t('Fermer')} onPress={onClose} style={styles.flexBtn} />
            </View>
          </KeyboardAwareScrollView>
        </View>
      </KeyboardAvoidingView>

      <PromptModal
        visible={addActionVisible}
        title={t('Nouvelle action de process')}
        placeholder={t('ex: Glacer')}
        onSubmit={async (value) => {
          setAddActionVisible(false);
          await onAddCustomAction(value);
        }}
        onCancel={() => setAddActionVisible(false)}
      />
      <PromptModal
        visible={!!renamingAction}
        title={t("Renommer l'action")}
        initialValue={renamingAction?.name}
        onSubmit={async (value) => {
          if (renamingAction) await onRenameAction(renamingAction.id, value);
          setRenamingAction(null);
        }}
        onCancel={() => setRenamingAction(null)}
      />
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'flex-end',
  },
  card: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '88%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.xs,
  },
  helperText: {
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: spacing.sm,
  },
  chipWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  chip: {
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
  },
  chipText: {
    fontSize: 13,
    fontWeight: '700',
  },
  addChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderStyle: 'dashed',
    marginBottom: spacing.xs,
  },
  addChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textMuted,
    marginLeft: 2,
  },
  row: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
    marginBottom: spacing.md,
  },
  flexBtn: {
    flex: 1,
  },
});
