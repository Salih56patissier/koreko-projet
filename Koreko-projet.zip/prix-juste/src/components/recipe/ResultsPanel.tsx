import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { RecipeCostSummary } from '../../types/models';
import { formatMoney } from '../../utils/format';

export default function ResultsPanel({
  summary,
  missingPriceCount = 0,
}: {
  summary: RecipeCostSummary;
  // Nombre de lignes dont le prix est inconnu (comptées pour 0) : le coût affiché est sous-estimé.
  missingPriceCount?: number;
}) {
  const { t } = useI18n();
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{t('Résultats')}</Text>

      {missingPriceCount > 0 && (
        <View style={styles.alertBox}>
          <Text style={styles.alertText}>
            {t('⚠️ {count} ligne(s) sans prix connu : elles comptent pour 0, le coût est sous-estimé.', {
              count: missingPriceCount,
            })}
          </Text>
        </View>
      )}

      <Row label={t('Coût ingrédients')} value={formatMoney(summary.ingredientsCost)} />
      <Row label={t('Coût temps de travail')} value={formatMoney(summary.laborCost)} />
      <Row label={t('Frais annexes')} value={formatMoney(summary.extraCostsTotal)} />
      <Row label={t('Coût total réel')} value={formatMoney(summary.totalRealCost)} bold />

      <View style={styles.divider} />

      <Row label={t('Prix juste')} value={formatMoney(summary.fairPrice)} bold accent />
      <Row label={t('Prix par part')} value={formatMoney(summary.pricePerServing)} accent />

      {summary.isSellingAtLoss && summary.lossAmount != null && (
        <View style={styles.alertBox}>
          <Text style={styles.alertText}>
            {t('⚠️ Vente à perte : tu perds {loss} par pièce au prix actuellement facturé.', {
              loss: formatMoney(summary.lossAmount),
            })}
          </Text>
        </View>
      )}

      {!summary.isSellingAtLoss && summary.effectiveHourlyEarnings != null && (
        <View style={styles.infoBox}>
          <Text style={styles.infoText}>
            {t('Au prix facturé, ton heure de travail te rapporte réellement {amount}.', {
              amount: formatMoney(summary.effectiveHourlyEarnings),
            })}
          </Text>
        </View>
      )}

      {summary.realMarginPercent != null && summary.realMarginAmount != null && (
        <View style={summary.isSellingAtLoss ? styles.alertBox : styles.infoBox}>
          <Text style={summary.isSellingAtLoss ? styles.alertText : styles.infoText}>
            {t('Marge réelle au prix facturé : {percent}% ({amount})', {
              percent: summary.realMarginPercent.toLocaleString('fr-FR', { maximumFractionDigits: 1 }),
              amount: formatMoney(summary.realMarginAmount),
            })}
          </Text>
        </View>
      )}
    </View>
  );
}

function Row({ label, value, bold, accent }: { label: string; value: string; bold?: boolean; accent?: boolean }) {
  const { accentDark } = useTheme();
  return (
    <View style={styles.row}>
      <Text style={[styles.label, bold && styles.bold]}>{label}</Text>
      <Text style={[styles.value, bold && styles.bold, accent && styles.accentValue, accent && { color: accentDark }]}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  label: {
    fontSize: 14,
    color: colors.textMuted,
  },
  value: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '600',
  },
  bold: {
    fontWeight: '800',
    color: colors.text,
  },
  accentValue: {
    fontSize: 16,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.sm,
  },
  alertBox: {
    backgroundColor: colors.dangerBg,
    borderRadius: radius.sm,
    padding: spacing.sm,
    marginTop: spacing.sm,
  },
  alertText: {
    color: colors.danger,
    fontWeight: '600',
    fontSize: 13,
  },
  infoBox: {
    backgroundColor: colors.successBg,
    borderRadius: radius.sm,
    padding: spacing.sm,
    marginTop: spacing.sm,
  },
  infoText: {
    color: colors.success,
    fontWeight: '600',
    fontSize: 13,
  },
});
