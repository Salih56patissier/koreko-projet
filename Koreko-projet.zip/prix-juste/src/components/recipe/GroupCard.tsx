import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { RecipeGroupWithItems, RecipeGroupItemWithIngredient, ProcessAction } from '../../types/models';
import ProcessTagBadge from './ProcessTagBadge';
import { formatMoney, formatQuantity, unitLabel } from '../../utils/format';

interface Props {
  group: RecipeGroupWithItems;
  processActions: ProcessAction[];
  onEditGroup: (groupId: string) => void;
  onDeleteGroup: (groupId: string) => void;
  onAddItem: (groupId: string) => void;
  onEditItem: (groupId: string, itemId: string) => void;
  onDeleteItem: (itemId: string) => void;
  // Ouvre l'écran « Ranger les ingrédients » de cette étape.
  onReorderItems: (groupId: string) => void;
}

function GroupCard({
  group,
  processActions,
  onEditGroup,
  onDeleteGroup,
  onAddItem,
  onEditItem,
  onDeleteItem,
  onReorderItems,
}: Props) {
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();
  // Une seule action par étape — c'est elle qui donne son nom au groupe (voir
  // GroupFormModal), donc son badge coloré remplace le titre en texte simple plutôt que de le
  // répéter en dessous.
  const tag = group.processTagIds.map((id) => processActions.find((a) => a.id === id)).find((a): a is ProcessAction => !!a);

  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <Pressable style={styles.titleCol} onPress={() => onEditGroup(group.id)}>
          {tag ? (
            <ProcessTagBadge name={tag.name} color={tag.color} />
          ) : (
            <View style={[styles.noActionBadge, { borderColor: accent }]}>
              <Ionicons name="add" size={14} color={accentDark} />
              <Text style={[styles.noActionText, { color: accentDark }]}>{t('Choisir une action')}</Text>
            </View>
          )}
        </Pressable>
        {group.items.length > 1 && (
          <Pressable onPress={() => onReorderItems(group.id)} hitSlop={8} style={styles.deleteBtn}>
            <Ionicons name="swap-vertical" size={20} color={accentDark} />
          </Pressable>
        )}
        <Pressable onPress={() => onDeleteGroup(group.id)} hitSlop={8} style={styles.deleteBtn}>
          <Ionicons name="trash-outline" size={18} color={colors.danger} />
        </Pressable>
      </View>

      <View>
        {group.instruction ? <Text style={styles.instruction}>{group.instruction}</Text> : null}

        {group.items.length === 0 && (
          <Text style={styles.emptyItemsText}>{t("Ce groupe n'a pas encore d'ingrédient.")}</Text>
        )}

        {group.items.map((item: RecipeGroupItemWithIngredient) => (
          <View key={item.id} style={styles.itemRow}>
            <Pressable style={{ flex: 1 }} onPress={() => onEditItem(group.id, item.id)}>
              <View style={styles.itemNameRow}>
                {item.isComponent && <Ionicons name="restaurant-outline" size={13} color={accentDark} />}
                <Text style={styles.itemName}>{item.name}</Text>
              </View>
              <Text style={styles.itemQty}>
                {formatQuantity(item.quantity)} {unitLabel(item.unit, t)}
                {item.unit === 'unite' && item.avgPieceWeightG
                  ? ` (≈ ${formatQuantity(item.quantity * item.avgPieceWeightG)} g)`
                  : ''}
              </Text>
              {item.unitPrice === 0 && item.quantity > 0 ? (
                <Text style={styles.itemWarning}>
                  {item.isComponent
                    ? t("⚠️ Cette recette de base n'a pas de poids : elle compte pour 0.")
                    : t('⚠️ Prix inconnu : cette ligne compte pour 0.')}
                </Text>
              ) : null}
              {item.note ? <Text style={styles.itemNote}>{item.note}</Text> : null}
            </Pressable>
            <View style={[styles.itemCostBadge, { backgroundColor: accent + '22' }]}>
              <Text style={[styles.itemCostText, { color: accentDark }]}>{formatMoney(item.lineCost)}</Text>
            </View>
            <Pressable onPress={() => onDeleteItem(item.id)} hitSlop={8} style={styles.deleteBtn}>
              <Ionicons name="close" size={16} color={colors.textMuted} />
            </Pressable>
          </View>
        ))}

        <Pressable style={styles.addItemBtn} onPress={() => onAddItem(group.id)} hitSlop={6}>
          <Ionicons name="add" size={14} color={accentDark} />
          <Text style={[styles.addItemText, { color: accentDark }]}>{t('Ajouter un ingrédient')}</Text>
        </Pressable>
      </View>
    </View>
  );
}

export default React.memo(GroupCard);

const styles = StyleSheet.create({
  itemWarning: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.danger,
    marginTop: 2,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  titleCol: {
    flex: 1,
    alignItems: 'flex-start',
  },
  noActionBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 5,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderStyle: 'dashed',
  },
  noActionText: {
    fontSize: 13,
    fontWeight: '700',
    marginLeft: 2,
  },
  deleteBtn: {
    padding: 4,
  },
  instruction: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: spacing.xs,
    fontStyle: 'italic',
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.sm,
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  itemNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  itemName: {
    flexShrink: 1,
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  itemQty: {
    fontSize: 12.5,
    color: colors.textMuted,
    marginTop: 1,
  },
  itemNote: {
    fontSize: 12,
    color: colors.textMuted,
    fontStyle: 'italic',
  },
  itemCostBadge: {
    flexShrink: 0,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.xs + 2,
    paddingVertical: 3,
    marginLeft: spacing.xs,
    marginRight: spacing.xs,
  },
  itemCostText: {
    fontSize: 11.5,
    fontWeight: '700',
  },
  emptyItemsText: {
    fontSize: 13,
    color: colors.textMuted,
    fontStyle: 'italic',
    marginTop: spacing.sm,
  },
  addItemBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    marginTop: spacing.sm,
    paddingVertical: 2,
  },
  addItemText: {
    fontWeight: '600',
    fontSize: 12,
    marginLeft: 3,
  },
});
