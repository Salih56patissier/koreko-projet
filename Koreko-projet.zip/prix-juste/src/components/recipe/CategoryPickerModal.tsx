import React from 'react';
import { Modal, View, Text, FlatList, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { useI18n } from '../../i18n/I18nContext';
import { CategoryWithCount } from '../../types/models';

interface Props {
  visible: boolean;
  title: string;
  categories: CategoryWithCount[];
  currentCategoryId: string;
  onSelect: (categoryId: string) => void;
  onCancel: () => void;
}

export default function CategoryPickerModal({
  visible,
  title,
  categories,
  currentCategoryId,
  onSelect,
  onCancel,
}: Props) {
  const { t } = useI18n();
  const options = categories.filter((c) => c.id !== currentCategoryId);

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onCancel}>
      <View style={styles.overlay}>
        <View style={styles.card}>
          <Text style={styles.title}>{title}</Text>
          <FlatList
            data={options}
            keyExtractor={(item) => item.id}
            style={styles.list}
            ListEmptyComponent={
              <Text style={styles.emptyText}>{t("Aucune autre catégorie — crée-en une d'abord.")}</Text>
            }
            renderItem={({ item }) => (
              <Pressable style={styles.row} onPress={() => onSelect(item.id)}>
                <Text style={styles.rowText}>{item.name}</Text>
                <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
              </Pressable>
            )}
          />
          <Pressable style={styles.cancelBtn} onPress={onCancel}>
            <Text style={styles.cancelText}>{t('Annuler')}</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'flex-end',
  },
  card: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '75%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  list: {
    marginBottom: spacing.sm,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.sm + 4,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  rowText: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.text,
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginVertical: spacing.lg,
  },
  cancelBtn: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  cancelText: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textMuted,
  },
});
