import React, { useEffect, useMemo, useState } from 'react';
import { Modal, View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import KeyboardAwareScrollView from '../common/KeyboardAwareScrollView';
import FieldLabel from '../common/FieldLabel';
import PrimaryButton from '../common/PrimaryButton';
import { ComponentCandidateRecipe, Ingredient, IngredientCategory, BaseUnit, PurchaseUnit } from '../../types/models';
import { formatQuantity, getCurrencySymbol, unitLabel } from '../../utils/format';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { EGG_WEIGHT_G, looksLikeEgg, normalizeSearch } from '../../utils/normalize';

interface Entry {
  kind: 'ingredient' | 'component';
  id: string;
  name: string;
  subtitle: string;
  unitPrice: number;
  baseUnit: BaseUnit;
  purchaseUnit?: PurchaseUnit;
  avgPieceWeightG?: number | null;
  color?: string;
}

interface Props {
  visible: boolean;
  ingredients: Ingredient[];
  ingredientCategories: IngredientCategory[];
  componentCandidates: ComponentCandidateRecipe[];
  initialIngredientId?: string | null;
  initialComponentRecipeId?: string | null;
  initialQuantity?: number;
  initialNote?: string | null;
  initialUnit?: BaseUnit;
  onSubmit: (data: {
    ingredientId: string | null;
    componentRecipeId: string | null;
    quantity: number;
    unit: BaseUnit;
    // Poids d'une pièce saisi ici pour un ingrédient acheté à la pièce qui n'en avait pas : à
    // enregistrer sur l'ingrédient (ses recettes passent alors au gramme).
    newPieceWeightG?: number;
    note: string | null;
  }) => void;
  onCancel: () => void;
}

export default function IngredientPickerModal({
  visible,
  ingredients,
  ingredientCategories,
  componentCandidates,
  initialIngredientId,
  initialComponentRecipeId,
  initialQuantity,
  initialNote,
  initialUnit,
  onSubmit,
  onCancel,
}: Props) {
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();
  const [tab, setTab] = useState<'ingredient' | 'component'>('ingredient');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Entry | undefined>(undefined);
  const [quantity, setQuantity] = useState('');
  const [note, setNote] = useState('');
  // Dans les recettes, tout se saisit au poids. Pour un ingrédient acheté à la pièce sans poids
  // connu, on demande une fois le poids d'une pièce (pré-rempli à 50 g pour des œufs).
  const [pieceWeight, setPieceWeight] = useState('');

  useEffect(() => {
    if (!visible) return;
    setSearch('');
    setQuantity(initialQuantity != null ? String(initialQuantity) : '');
    setNote(initialNote ?? '');
    setPieceWeight('');
    if (initialIngredientId) {
      const ing = ingredients.find((i) => i.id === initialIngredientId);
      // Ancienne ligne enregistrée en pièces pour un ingrédient dont on connaît le poids : on
      // l'affiche en grammes, elle sera enregistrée en grammes.
      if (ing?.avgPieceWeightG && initialUnit === 'unite' && initialQuantity != null) {
        setQuantity(formatQuantity(initialQuantity * ing.avgPieceWeightG).replace(/\s/g, ''));
      }
      setTab('ingredient');
      setSelected(
        ing
          ? {
              kind: 'ingredient',
              id: ing.id,
              name: ing.name,
              subtitle: '',
              unitPrice: ing.unitPrice,
              baseUnit: ing.baseUnit,
              purchaseUnit: ing.purchaseUnit,
              avgPieceWeightG: ing.avgPieceWeightG,
            }
          : undefined
      );
    } else if (initialComponentRecipeId) {
      const comp = componentCandidates.find((c) => c.id === initialComponentRecipeId);
      setTab('component');
      setSelected(
        comp
          ? { kind: 'component', id: comp.id, name: comp.name, subtitle: comp.categoryName, unitPrice: comp.unitPrice, baseUnit: 'g' }
          : undefined
      );
    } else {
      setTab('ingredient');
      setSelected(undefined);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, initialIngredientId, initialComponentRecipeId, initialQuantity, initialNote]);

  const entries: Entry[] = useMemo(() => {
    if (tab === 'ingredient') {
      return ingredients.map((i) => ({
        kind: 'ingredient' as const,
        id: i.id,
        name: i.name,
        subtitle: '',
        unitPrice: i.unitPrice,
        baseUnit: i.baseUnit,
        purchaseUnit: i.purchaseUnit,
        avgPieceWeightG: i.avgPieceWeightG,
        color: ingredientCategories.find((c) => c.id === i.categoryId)?.color,
      }));
    }
    return componentCandidates.map((c) => ({
      kind: 'component' as const,
      id: c.id,
      name: c.name,
      subtitle: c.categoryName,
      unitPrice: c.unitPrice,
      baseUnit: 'g' as const,
    }));
  }, [tab, ingredients, ingredientCategories, componentCandidates]);

  const filtered = useMemo(
    () => entries.filter((e) => normalizeSearch(e.name).includes(normalizeSearch(search))),
    [entries, search]
  );

  const enteredPieceWeight = parseFloat(pieceWeight.replace(',', '.')) > 0 ? parseFloat(pieceWeight.replace(',', '.')) : null;
  // Acheté à la pièce, poids pas encore connu : on le demande ici.
  // (pièce, paquet ou carton : « unite » en base = le prix est par unité, sans poids connu)
  const needsPieceWeight = selected?.kind === 'ingredient' && selected.baseUnit === 'unite';
  const effectivePieceWeight = needsPieceWeight
    ? enteredPieceWeight
    : selected?.purchaseUnit === 'unite'
      ? selected.avgPieceWeightG ?? null
      : null;
  const weightLabel =
    selected?.purchaseUnit === 'paquet'
      ? t("Poids d'un paquet (g)")
      : selected?.purchaseUnit === 'carton'
        ? t("Poids d'un carton (g)")
        : t("Poids d'une pièce (g)");
  // Toujours au poids dès qu'on connaît le poids d'une pièce ; à la pièce seulement sinon.
  const quantityUnit: BaseUnit = selected
    ? selected.kind === 'ingredient' && (selected.baseUnit !== 'unite' || effectivePieceWeight)
      ? selected.baseUnit === 'unite'
        ? 'g'
        : selected.baseUnit
      : selected.baseUnit
    : 'g';

  const canSubmit = !!selected && parseFloat(quantity.replace(',', '.')) > 0;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onCancel}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.card}>
          {!selected ? (
            <>
              <Text style={styles.title}>{t('Choisir une ligne')}</Text>

              <View style={styles.tabRow}>
                <Pressable
                  style={[styles.tabBtn, tab === 'ingredient' && { backgroundColor: accent }]}
                  onPress={() => setTab('ingredient')}
                >
                  <Text style={[styles.tabText, tab === 'ingredient' && styles.tabTextActive]}>{t('Ingrédients')}</Text>
                </Pressable>
                <Pressable
                  style={[styles.tabBtn, tab === 'component' && { backgroundColor: accent }]}
                  onPress={() => setTab('component')}
                >
                  <Text style={[styles.tabText, tab === 'component' && styles.tabTextActive]}>
                    {t('Recettes (composants)')}
                  </Text>
                </Pressable>
              </View>

              <TextInput
                style={inputStyles.input}
                value={search}
                onChangeText={setSearch}
                placeholder={t('Rechercher...')}
                placeholderTextColor={colors.textMuted}
                autoFocus
              />
              <KeyboardAwareScrollView style={styles.list}>
                {filtered.length === 0 && (
                  <Text style={styles.emptyText}>
                    {tab === 'ingredient'
                      ? ingredients.length === 0
                        ? t('Ta base d\'ingrédients est vide. Ajoute d\'abord tes ingrédients depuis l\'onglet "Ingrédients", puis reviens ici.')
                        : t('Aucun ingrédient trouvé.')
                      : componentCandidates.length === 0
                        ? t("Aucune recette disponible comme composant pour l'instant.")
                        : t('Aucune recette trouvée.')}
                  </Text>
                )}
                {filtered.map((item) => (
                  <Pressable
                    key={item.id}
                    style={styles.ingredientRow}
                    onPress={() => {
                      setSelected(item);
                      setPieceWeight(item.baseUnit === 'unite' && !item.avgPieceWeightG && looksLikeEgg(item.name) ? String(EGG_WEIGHT_G) : '');
                    }}
                  >
                    {item.color && <View style={[styles.colorDot, { backgroundColor: item.color }]} />}
                    <View style={{ flex: 1 }}>
                      <Text style={styles.ingredientName}>{item.name}</Text>
                      {item.subtitle ? <Text style={styles.ingredientSubtitle}>{item.subtitle}</Text> : null}
                    </View>
                    <Text style={styles.ingredientPrice}>
                      {item.unitPrice.toLocaleString('fr-FR', { maximumFractionDigits: 4 })} {getCurrencySymbol()}/{unitLabel(item.baseUnit, t)}
                    </Text>
                  </Pressable>
                ))}
                <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={{ marginTop: spacing.md }} />
              </KeyboardAwareScrollView>
            </>
          ) : (
            <KeyboardAwareScrollView>
              <Pressable style={styles.backRow} onPress={() => setSelected(undefined)}>
                <Ionicons name="chevron-back" size={18} color={accentDark} />
                <Text style={[styles.backText, { color: accentDark }]}>{t('Changer')}</Text>
              </Pressable>
              <Text style={styles.title}>{selected.name}</Text>

              {needsPieceWeight ? (
                <>
                  <FieldLabel>{weightLabel}</FieldLabel>
                  <TextInput
                    style={inputStyles.input}
                    value={pieceWeight}
                    onChangeText={setPieceWeight}
                    keyboardType="decimal-pad"
                    placeholder={selected?.purchaseUnit === 'unite' ? t('ex: 50') : t('ex: 1500')}
                  />
                  <Text style={styles.pieceHint}>
                    {t('Indique-le une fois : le prix sera calculé au gramme et tes recettes seront en grammes.')}
                  </Text>
                </>
              ) : null}

              <FieldLabel>{t('Quantité utilisée ({unit})', { unit: unitLabel(quantityUnit, t) })}</FieldLabel>
              <TextInput
                style={inputStyles.input}
                value={quantity}
                onChangeText={setQuantity}
                keyboardType="decimal-pad"
                placeholder={quantityUnit === 'unite' ? t('ex: 2') : t('ex: 250')}
                autoFocus={!needsPieceWeight}
              />
              {effectivePieceWeight && selected?.purchaseUnit === 'unite' ? (
                <Text style={styles.pieceHint}>
                  {t('1 pièce ≈ {weight} g', { weight: formatQuantity(effectivePieceWeight) })}
                </Text>
              ) : null}

              <FieldLabel>{t('Note (optionnel)')}</FieldLabel>
              <TextInput
                style={inputStyles.input}
                value={note}
                onChangeText={setNote}
                placeholder={t('ex: à température ambiante')}
              />

              <View style={styles.row}>
                <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={styles.flexBtn} />
                <PrimaryButton
                  label={t('Valider')}
                  disabled={!canSubmit}
                  onPress={() =>
                    onSubmit({
                      ingredientId: selected.kind === 'ingredient' ? selected.id : null,
                      componentRecipeId: selected.kind === 'component' ? selected.id : null,
                      quantity: parseFloat(quantity.replace(',', '.')),
                      unit: quantityUnit,
                      newPieceWeightG: needsPieceWeight && enteredPieceWeight ? enteredPieceWeight : undefined,
                      note: note.trim() || null,
                    })
                  }
                  style={styles.flexBtn}
                />
              </View>
            </KeyboardAwareScrollView>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  unitRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  unitBtn: {
    flex: 1,
    paddingVertical: spacing.sm,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  unitBtnText: {
    color: colors.text,
    fontWeight: '600',
  },
  unitBtnTextActive: {
    color: '#fff',
  },
  pieceHint: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 4,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'flex-end',
  },
  card: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '85%',
    minHeight: '50%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  tabRow: {
    flexDirection: 'row',
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.sm,
    padding: 3,
    marginBottom: spacing.sm,
  },
  tabBtn: {
    flex: 1,
    paddingVertical: spacing.xs + 2,
    borderRadius: radius.sm - 2,
    alignItems: 'center',
  },
  tabText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.textMuted,
  },
  tabTextActive: {
    color: '#fff',
  },
  list: {
    marginTop: spacing.sm,
  },
  ingredientRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.sm + 2,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  colorDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: spacing.sm,
  },
  ingredientName: {
    fontSize: 15,
    color: colors.text,
    fontWeight: '600',
  },
  ingredientSubtitle: {
    fontSize: 12,
    color: colors.textMuted,
  },
  ingredientPrice: {
    fontSize: 13,
    color: colors.textMuted,
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginTop: spacing.lg,
  },
  backRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  backText: {
    fontWeight: '600',
    marginLeft: 2,
  },
  row: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  flexBtn: {
    flex: 1,
  },
});
