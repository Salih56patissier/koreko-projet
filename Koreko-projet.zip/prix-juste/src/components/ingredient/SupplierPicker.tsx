import React, { useState } from 'react';
import { View, Text, Pressable, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import PromptModal from '../common/PromptModal';
import { Supplier } from '../../types/models';
import {
  createSupplier,
  deleteSupplier,
  listSuppliers,
  SupplierInUseError,
  updateSupplier,
} from '../../db/repositories/suppliersRepo';
import { useSQLiteContext } from 'expo-sqlite';

interface Props {
  suppliers: Supplier[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onSuppliersChanged: (suppliers: Supplier[]) => void;
}

export default function SupplierPicker({ suppliers, selectedId, onSelect, onSuppliersChanged }: Props) {
  const db = useSQLiteContext();
  const { accent } = useTheme();
  const { t } = useI18n();
  const [addVisible, setAddVisible] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);

  async function refresh() {
    onSuppliersChanged(await listSuppliers(db));
  }

  async function handleCreate(name: string) {
    setAddVisible(false);
    const id = await createSupplier(db, name);
    await refresh();
    onSelect(id);
  }

  async function handleRename(newName: string) {
    if (!editing) return;
    setEditing(null);
    await updateSupplier(db, editing.id, newName);
    await refresh();
  }

  function handleLongPress(supplier: Supplier) {
    Alert.alert(supplier.name, undefined, [
      { text: t('Renommer'), onPress: () => setEditing(supplier) },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: () =>
          Alert.alert(t('Supprimer ce fournisseur ?'), t('Cette action est irréversible.'), [
            { text: t('Annuler'), style: 'cancel' },
            {
              text: t('Supprimer'),
              style: 'destructive',
              onPress: async () => {
                try {
                  await deleteSupplier(db, supplier.id);
                  await refresh();
                } catch (e) {
                  if (e instanceof SupplierInUseError) {
                    Alert.alert(t('Impossible'), t(e.message));
                  }
                }
              },
            },
          ]),
      },
      { text: t('Annuler'), style: 'cancel' },
    ]);
  }

  return (
    <View>
      {suppliers.length > 0 && (
        <Text style={styles.hint}>{t('Appui long sur un fournisseur pour le renommer ou le supprimer.')}</Text>
      )}
      <View style={styles.chipWrap}>
        {suppliers.map((s) => {
          const active = selectedId === s.id;
          return (
            <Pressable
              key={s.id}
              onPress={() => onSelect(s.id)}
              onLongPress={() => handleLongPress(s)}
              style={[styles.chip, active && { backgroundColor: accent, borderColor: accent }]}
            >
              <Text style={[styles.chipText, active && styles.chipTextActive]}>{s.name}</Text>
            </Pressable>
          );
        })}
        <Pressable style={styles.addChip} onPress={() => setAddVisible(true)}>
          <Ionicons name="add" size={16} color={colors.textMuted} />
          <Text style={styles.addChipText}>{t('Nouveau fournisseur')}</Text>
        </Pressable>
      </View>

      <PromptModal
        visible={addVisible}
        title={t('Nouveau fournisseur')}
        placeholder={t('ex: Mon grossiste')}
        onSubmit={handleCreate}
        onCancel={() => setAddVisible(false)}
      />
      <PromptModal
        visible={!!editing}
        title={t('Renommer le fournisseur')}
        initialValue={editing?.name}
        onSubmit={handleRename}
        onCancel={() => setEditing(null)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  hint: {
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: spacing.xs,
  },
  chipWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  chip: {
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
    backgroundColor: colors.surface,
  },
  chipText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.text,
  },
  chipTextActive: {
    color: '#fff',
  },
  addChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderStyle: 'dashed',
    marginBottom: spacing.xs,
  },
  addChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textMuted,
    marginLeft: 2,
  },
});
