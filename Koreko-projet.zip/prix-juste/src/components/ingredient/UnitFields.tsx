import React from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { PurchaseUnit } from '../../types/models';
import { purchaseUnitLabel } from '../../utils/format';
import { isCountUnit } from '../../utils/priceCalc';
import FieldLabel from '../common/FieldLabel';

// Toutes les façons d'acheter : au poids (g, kg), au litre, ou « à compter » (pièce, paquet, carton).
export const PURCHASE_UNITS: PurchaseUnit[] = ['g', 'kg', 'l', 'unite', 'paquet', 'carton'];

// Nombre saisi (virgule ou point) → poids en grammes, ou null si vide / invalide.
export function parseWeight(text: string): number | null {
  const value = parseFloat(text.replace(',', '.'));
  return value > 0 ? value : null;
}

// Faut-il demander le poids d'une unité ? Oui pour pièce / paquet / carton ; facultatif pour le litre.
export function asksUnitWeight(unit: PurchaseUnit): boolean {
  return isCountUnit(unit) || unit === 'l';
}

interface PickerProps {
  value: PurchaseUnit;
  onChange: (unit: PurchaseUnit) => void;
}

export function PurchaseUnitPicker({ value, onChange }: PickerProps) {
  const { accent } = useTheme();
  const { t } = useI18n();
  return (
    <View style={styles.unitWrap}>
      {PURCHASE_UNITS.map((u) => (
        <Pressable
          key={u}
          onPress={() => onChange(u)}
          style={[styles.unitBtn, value === u && { backgroundColor: accent, borderColor: accent }]}
        >
          <Text style={[styles.unitBtnText, value === u && styles.unitBtnTextActive]}>{purchaseUnitLabel(u, t)}</Text>
        </Pressable>
      ))}
    </View>
  );
}

interface WeightProps {
  unit: PurchaseUnit;
  value: string;
  onChange: (text: string) => void;
  // true = on ne peut pas enregistrer sans le poids (ingrédient déjà utilisé au gramme dans des recettes).
  required?: boolean;
}

// « Poids d'un paquet (g) » etc. : demandé juste sous le choix de l'unité, pour que le prix soit
// ramené au gramme et que les recettes restent toujours au poids.
export function UnitWeightField({ unit, value, onChange, required }: WeightProps) {
  const { t } = useI18n();
  if (!asksUnitWeight(unit)) return null;
  const label =
    unit === 'unite'
      ? t("Poids d'une pièce (g)")
      : unit === 'paquet'
        ? t("Poids d'un paquet (g)")
        : unit === 'carton'
          ? t("Poids d'un carton (g)")
          : t("Poids d'un litre (g), optionnel");
  const hint =
    unit === 'l'
      ? t("Laisse vide si c'est comme l'eau (1 litre = 1 000 g). Sinon indique ce que pèse 1 litre.")
      : required
        ? t('Obligatoire : cet ingrédient est utilisé au gramme dans tes recettes.')
        : t('Indique-le une fois : le prix sera calculé au gramme et tes recettes seront en grammes.');
  return (
    <View>
      <FieldLabel>{label}</FieldLabel>
      <Text style={styles.hint}>{hint}</Text>
      <TextInput
        style={inputStyles.input}
        value={value}
        onChangeText={onChange}
        keyboardType="decimal-pad"
        placeholder={unit === 'unite' ? t('ex: 50') : unit === 'l' ? t('ex: 1030') : t('ex: 1500')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  unitWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  unitBtn: {
    minWidth: '30%',
    flexGrow: 1,
    paddingVertical: spacing.sm + 2,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  unitBtnText: {
    color: colors.text,
    fontWeight: '600',
  },
  unitBtnTextActive: {
    color: '#fff',
  },
  hint: {
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: spacing.xs,
  },
});
