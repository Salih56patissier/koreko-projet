import React, { useEffect, useState } from 'react';
import { Modal, View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import KeyboardAwareScrollView from '../common/KeyboardAwareScrollView';
import FieldLabel from '../common/FieldLabel';
import PrimaryButton from '../common/PrimaryButton';
import { PurchaseUnit } from '../../types/models';
import { getCurrencySymbol } from '../../utils/format';
import { PurchaseUnitPicker, UnitWeightField, asksUnitWeight, parseWeight } from './UnitFields';
import { isCountUnit } from '../../utils/priceCalc';

const VAT_RATES = [0, 10, 20];

interface Props {
  visible: boolean;
  initialPrice: number;
  initialQuantity: number;
  initialUnit: PurchaseUnit;
  initialUnitWeightG?: number | null;
  // Taux de TVA du dernier achat (ou de l'ingrédient) : proposé d'office, modifiable.
  initialVatRate: number;
  requireWeight?: boolean;
  onSubmit: (data: {
    price: number;
    quantity: number;
    unit: PurchaseUnit;
    unitWeightG: number | null;
    vatRate: number;
  }) => void;
  onCancel: () => void;
}

export default function PriceCorrectionModal({
  visible,
  initialPrice,
  initialQuantity,
  initialUnit,
  initialUnitWeightG,
  initialVatRate,
  requireWeight,
  onSubmit,
  onCancel,
}: Props) {
  const { accent } = useTheme();
  const { t } = useI18n();
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState<PurchaseUnit>('kg');
  const [unitWeight, setUnitWeight] = useState('');
  const [vatRate, setVatRate] = useState(0);

  function handleUnitChange(next: PurchaseUnit) {
    setUnit(next);
    setUnitWeight(next === initialUnit && initialUnitWeightG ? String(initialUnitWeightG) : '');
  }

  useEffect(() => {
    if (visible) {
      setPrice(String(initialPrice));
      setQuantity(String(initialQuantity));
      setUnit(initialUnit);
      setUnitWeight(initialUnitWeightG ? String(initialUnitWeightG) : '');
      setVatRate(initialVatRate);
    }
  }, [visible, initialPrice, initialQuantity, initialUnit, initialUnitWeightG, initialVatRate]);

  const canSubmit =
    parseFloat(price.replace(',', '.')) > 0 &&
    parseFloat(quantity.replace(',', '.')) > 0 &&
    !(requireWeight && isCountUnit(unit) && !parseWeight(unitWeight));

  function handleSubmit() {
    onSubmit({
      price: parseFloat(price.replace(',', '.')),
      quantity: parseFloat(quantity.replace(',', '.')),
      unit,
      unitWeightG: asksUnitWeight(unit) ? parseWeight(unitWeight) : null,
      vatRate,
    });
  }

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.card}>
          <KeyboardAwareScrollView>
          <Text style={styles.title}>{t('Corriger le prix')}</Text>
          <Text style={styles.helperText}>
            {t("Change le prix utilisé par tes recettes sans enregistrer un nouvel achat — utile si tu sais qu'un prix a changé avant même d'avoir racheté.")}
          </Text>

          <FieldLabel>{t('Prix ({currency})', { currency: getCurrencySymbol() })}</FieldLabel>
          <TextInput
            style={inputStyles.input}
            value={price}
            onChangeText={setPrice}
            keyboardType="decimal-pad"
            placeholder={t('ex: 45')}
            autoFocus
          />

          <FieldLabel>{t('Quantité correspondante')}</FieldLabel>
          <TextInput
            style={inputStyles.input}
            value={quantity}
            onChangeText={setQuantity}
            keyboardType="decimal-pad"
            placeholder={t('ex: 500')}
          />

          <FieldLabel>{t('Unité')}</FieldLabel>
          <PurchaseUnitPicker value={unit} onChange={handleUnitChange} />
          <UnitWeightField unit={unit} value={unitWeight} onChange={setUnitWeight} required={requireWeight} />

          <FieldLabel>{t('Taux de TVA')}</FieldLabel>
          <Text style={styles.vatHint}>
            {t("Le prix que tu indiques est le prix payé (TTC). Choisis le taux de TVA qui s'y applique pour que le prix hors taxe soit juste.")}
          </Text>
          <View style={styles.unitRow}>
            {VAT_RATES.map((rate) => (
              <Pressable
                key={rate}
                onPress={() => setVatRate(rate)}
                style={[styles.unitBtn, vatRate === rate && { backgroundColor: accent, borderColor: accent }]}
              >
                <Text style={[styles.unitBtnText, vatRate === rate && styles.unitBtnTextActive]}>{rate}%</Text>
              </Pressable>
            ))}
          </View>

          <View style={styles.row}>
            <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={styles.flexBtn} />
            <PrimaryButton label={t('Valider')} disabled={!canSubmit} onPress={handleSubmit} style={styles.flexBtn} />
          </View>
          </KeyboardAwareScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '90%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.xs,
  },
  vatHint: {
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: spacing.xs,
  },
  helperText: {
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: spacing.md,
  },
  unitRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  unitBtn: {
    flex: 1,
    paddingVertical: spacing.sm + 2,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  unitBtnText: {
    color: colors.text,
    fontWeight: '600',
  },
  unitBtnTextActive: {
    color: '#fff',
  },
  row: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  flexBtn: {
    flex: 1,
  },
});
