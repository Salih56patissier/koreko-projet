import { Alert } from 'react-native';
import { type SQLiteDatabase } from 'expo-sqlite';
import { PurchaseUnit } from '../../types/models';
import { baseUnitForPurchaseUnit, purchaseWeightG } from '../../utils/priceCalc';
import { purchaseUnitLabel, unitLabel } from '../../utils/format';

type T = (key: string, vars?: Record<string, string | number>) => string;

// Le coût d'une ligne de recette = quantité × prix de l'ingrédient dans son unité de base (g, ml
// ou pièce). Un achat qui changerait cette unité de base (ex: un ingrédient utilisé en grammes,
// acheté « en carton » sans poids) rendrait faux le coût des recettes qui l'utilisent : on prévient
// avant d'enregistrer. Renvoie true si on peut enregistrer.
export async function confirmPurchaseUnit(
  db: SQLiteDatabase,
  ingredientId: string,
  unit: PurchaseUnit,
  unitWeightG: number | null,
  t: T
): Promise<boolean> {
  const ingredient = await db.getFirstAsync<{ purchase_unit: PurchaseUnit; avg_piece_weight_g: number | null }>(
    'SELECT purchase_unit, avg_piece_weight_g FROM ingredients WHERE id = ?',
    [ingredientId]
  );
  if (!ingredient) return true;
  const weight = purchaseWeightG(unit, unitWeightG, ingredient.avg_piece_weight_g);
  const newBase = baseUnitForPurchaseUnit(unit, weight);
  const lines = await db.getAllAsync<{ unit: 'g' | 'ml' | 'unite' }>(
    'SELECT DISTINCT unit FROM recipe_group_items WHERE ingredient_id = ?',
    [ingredientId]
  );
  // g et ml se valent ; « pièces » se convertit en grammes dès qu'on connaît le poids d'une pièce.
  const incompatible = lines.find((l) => {
    if (l.unit === newBase) return false;
    if (l.unit !== 'unite' && newBase !== 'unite') return false;
    if (l.unit === 'unite' && ingredient.avg_piece_weight_g && newBase !== 'unite') return false;
    return true;
  });
  if (!incompatible) return true;

  return new Promise((resolve) => {
    Alert.alert(
      t("Attention à l'unité"),
      t(
        'Tes recettes utilisent cet ingrédient en « {used} », mais cet achat est en « {unit} » : le coût de ces recettes deviendrait faux. Garde plutôt ton unité habituelle (« {usual} »), par exemple un paquet de 250 g = 0,25 kg.',
        {
          used: unitLabel(incompatible.unit, t),
          unit: purchaseUnitLabel(unit, t),
          usual: purchaseUnitLabel(ingredient.purchase_unit, t),
        }
      ),
      [
        { text: t("Changer l'unité"), style: 'cancel', onPress: () => resolve(false) },
        { text: t('Enregistrer quand même'), style: 'destructive', onPress: () => resolve(true) },
      ],
      { cancelable: true, onDismiss: () => resolve(false) }
    );
  });
}
