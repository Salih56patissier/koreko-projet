import React, { useEffect, useState } from 'react';
import { Modal, View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import KeyboardAwareScrollView from '../common/KeyboardAwareScrollView';
import FieldLabel from '../common/FieldLabel';
import PrimaryButton from '../common/PrimaryButton';
import SupplierPicker from './SupplierPicker';
import { PurchaseUnit, Supplier } from '../../types/models';
import { getCurrencySymbol } from '../../utils/format';
import { PurchaseUnitPicker, UnitWeightField, asksUnitWeight, parseWeight } from './UnitFields';
import { isCountUnit } from '../../utils/priceCalc';
import DateField from '../common/DateField';
import { todayIso } from '../../utils/date';

const VAT_RATES = [0, 10, 20];

interface EditingPurchase {
  supplierId: string;
  purchaseDate: string;
  price: number;
  quantity: number;
  unit: PurchaseUnit;
  note: string | null;
  vatRate: number;
  unitWeightG: number | null;
}

interface Props {
  visible: boolean;
  suppliers: Supplier[];
  onSuppliersChanged: (suppliers: Supplier[]) => void;
  // Présent = on modifie un achat existant (préremplit les champs, change le titre) ;
  // absent = on en enregistre un nouveau.
  editingPurchase?: EditingPurchase;
  // Taux de TVA proposé par défaut pour un NOUVEL achat (le taux actuel de l'ingrédient) —
  // ignoré en modification, où le taux déjà enregistré sur l'achat est repris.
  defaultVatRate: number;
  // Unité proposée pour un NOUVEL achat : celle du dernier achat de l'ingrédient.
  defaultUnit: PurchaseUnit;
  // Poids de l'unité habituelle (ex: 1500 g le carton), préremplit le champ poids.
  defaultUnitWeightG?: number | null;
  // true = l'ingrédient est déjà utilisé au gramme dans des recettes : le poids est obligatoire
  // pour une unité « à compter » (sinon le coût de ces recettes serait faux).
  requireWeight?: boolean;
  onSubmit: (data: {
    supplierId: string;
    purchaseDate: string;
    price: number;
    quantity: number;
    unit: PurchaseUnit;
    note: string | null;
    vatRate: number;
    unitWeightG: number | null;
  }) => void;
  onCancel: () => void;
}

export default function PurchaseFormModal({
  visible,
  suppliers,
  onSuppliersChanged,
  editingPurchase,
  defaultVatRate,
  defaultUnit,
  defaultUnitWeightG,
  requireWeight,
  onSubmit,
  onCancel,
}: Props) {
  const { accent } = useTheme();
  const { t } = useI18n();
  const [supplierId, setSupplierId] = useState<string | null>(null);
  const [date, setDate] = useState(todayIso());
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState<PurchaseUnit>('kg');
  const [note, setNote] = useState('');
  const [vatRate, setVatRate] = useState(0);
  const [unitWeight, setUnitWeight] = useState('');

  // Changer d'unité : on reprend le poids habituel seulement si c'est l'unité habituelle.
  function handleUnitChange(next: PurchaseUnit) {
    setUnit(next);
    setUnitWeight(next === defaultUnit && defaultUnitWeightG ? String(defaultUnitWeightG) : '');
  }

  useEffect(() => {
    if (!visible) return;
    if (editingPurchase) {
      setSupplierId(editingPurchase.supplierId);
      setDate(editingPurchase.purchaseDate);
      setPrice(String(editingPurchase.price));
      setQuantity(String(editingPurchase.quantity));
      setUnit(editingPurchase.unit);
      setNote(editingPurchase.note ?? '');
      setVatRate(editingPurchase.vatRate);
      setUnitWeight(editingPurchase.unitWeightG ? String(editingPurchase.unitWeightG) : '');
    } else {
      setSupplierId(suppliers[0]?.id ?? null);
      setDate(todayIso());
      setPrice('');
      setQuantity('');
      setUnit(defaultUnit);
      setNote('');
      setVatRate(defaultVatRate);
      setUnitWeight(defaultUnitWeightG ? String(defaultUnitWeightG) : '');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, editingPurchase]);

  const canSubmit =
    !!supplierId &&
    date.trim().length > 0 &&
    parseFloat(price.replace(',', '.')) > 0 &&
    parseFloat(quantity.replace(',', '.')) > 0 &&
    !(requireWeight && isCountUnit(unit) && !parseWeight(unitWeight));

  function handleSubmit() {
    if (!supplierId) return;
    onSubmit({
      supplierId,
      purchaseDate: date.trim(),
      price: parseFloat(price.replace(',', '.')),
      quantity: parseFloat(quantity.replace(',', '.')),
      unit,
      note: note.trim() || null,
      vatRate,
      unitWeightG: asksUnitWeight(unit) ? parseWeight(unitWeight) : null,
    });
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onCancel}>
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.card}>
          <KeyboardAwareScrollView>
            <Text style={styles.title}>{editingPurchase ? t('Modifier cet achat') : t('Enregistrer un achat')}</Text>

            <FieldLabel>{t('Fournisseur')}</FieldLabel>
            <SupplierPicker
              suppliers={suppliers}
              selectedId={supplierId}
              onSelect={setSupplierId}
              onSuppliersChanged={onSuppliersChanged}
            />

            <FieldLabel>{t('Date d\'achat')}</FieldLabel>
            <DateField value={date} onChange={setDate} />

            <FieldLabel>{t('Prix payé ({currency})', { currency: getCurrencySymbol() })}</FieldLabel>
            <TextInput
              style={inputStyles.input}
              value={price}
              onChangeText={setPrice}
              keyboardType="decimal-pad"
              placeholder={t('ex: 45')}
            />

            <FieldLabel>{t('Quantité correspondante')}</FieldLabel>
            <TextInput
              style={inputStyles.input}
              value={quantity}
              onChangeText={setQuantity}
              keyboardType="decimal-pad"
              placeholder={t('ex: 500')}
            />

            <FieldLabel>{t('Unité')}</FieldLabel>
            <PurchaseUnitPicker value={unit} onChange={handleUnitChange} />
            <UnitWeightField unit={unit} value={unitWeight} onChange={setUnitWeight} required={requireWeight} />

            <FieldLabel>{t('Taux de TVA')}</FieldLabel>
            <View style={styles.unitRow}>
              {VAT_RATES.map((rate) => (
                <Pressable
                  key={rate}
                  onPress={() => setVatRate(rate)}
                  style={[styles.unitBtn, vatRate === rate && { backgroundColor: accent, borderColor: accent }]}
                >
                  <Text style={[styles.unitBtnText, vatRate === rate && styles.unitBtnTextActive]}>{rate}%</Text>
                </Pressable>
              ))}
            </View>

            <FieldLabel>{t('Note (optionnel)')}</FieldLabel>
            <TextInput style={inputStyles.input} value={note} onChangeText={setNote} placeholder={t('ex: promotion')} />

            <View style={styles.row}>
              <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={styles.flexBtn} />
              <PrimaryButton label={t('Valider')} disabled={!canSubmit} onPress={handleSubmit} style={styles.flexBtn} />
            </View>
          </KeyboardAwareScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'flex-end',
  },
  card: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '90%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.sm,
  },
  unitRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  unitBtn: {
    flex: 1,
    paddingVertical: spacing.sm + 2,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  unitBtnText: {
    color: colors.text,
    fontWeight: '600',
  },
  unitBtnTextActive: {
    color: '#fff',
  },
  row: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
    marginBottom: spacing.md,
  },
  flexBtn: {
    flex: 1,
  },
});
