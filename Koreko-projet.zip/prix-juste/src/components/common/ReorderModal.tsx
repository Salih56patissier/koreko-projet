import React, { useEffect, useState } from 'react';
import { Modal, View, Text, Pressable, StyleSheet } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import DraggableFlatList, { RenderItemParams, ScaleDecorator } from 'react-native-draggable-flatlist';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import PrimaryButton from './PrimaryButton';

export interface ReorderEntry {
  id: string;
  label: string;
  sublabel?: string;
}

interface Props {
  visible: boolean;
  title: string;
  entries: ReorderEntry[];
  onDone: (orderedIds: string[]) => void;
  onCancel: () => void;
}

// Écran de rangement par glisser-déposer : UNE seule liste, en plein écran, sans liste imbriquée
// ni défilement concurrent — c'est ce qui la rend stable (les listes glissables imbriquées dans
// la fiche recette se disputaient le geste et tremblaient). Le geste démarre après un appui très
// court sur la poignée ≡ (un appui long ailleurs sur la ligne), pour pouvoir faire défiler la
// liste. Démarrer dès le toucher (onPressIn) laissait la ligne « coincée » sur Android.
export default function ReorderModal({ visible, title, entries, onDone, onCancel }: Props) {
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();
  const [data, setData] = useState<ReorderEntry[]>(entries);

  useEffect(() => {
    if (visible) setData(entries);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  function sortAlphabetically() {
    setData((prev) => [...prev].sort((a, b) => a.label.localeCompare(b.label, undefined, { sensitivity: 'base', numeric: true })));
  }

  const renderItem = ({ item, drag, isActive }: RenderItemParams<ReorderEntry>) => (
    <ScaleDecorator activeScale={1.03}>
      <Pressable
        onLongPress={drag}
        delayLongPress={250}
        disabled={isActive}
        style={[styles.row, isActive && { borderColor: accent, backgroundColor: colors.surfaceAlt }]}
      >
        <View style={{ flex: 1 }}>
          <Text style={styles.label}>{item.label}</Text>
          {item.sublabel ? <Text style={styles.sublabel}>{item.sublabel}</Text> : null}
        </View>
        <Pressable onLongPress={drag} delayLongPress={120} disabled={isActive} hitSlop={12} style={styles.handle}>
          <Ionicons name="reorder-three" size={30} color={isActive ? accentDark : colors.textMuted} />
        </Pressable>
      </Pressable>
    </ScaleDecorator>
  );

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onCancel}>
      {/* Une Modal Android est une fenêtre à part : elle a besoin de sa propre racine de gestes. */}
      <GestureHandlerRootView style={{ flex: 1 }}>
        {/* Fond clair : heure et batterie en foncé pour rester lisibles. */}
        <StatusBar style="dark" />
        <SafeAreaView style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.hint}>{t('Glisse la poignée ≡ pour monter ou descendre une ligne.')}</Text>
            <Pressable onPress={sortAlphabetically} hitSlop={8} style={styles.sortBtn}>
              <Ionicons name="text-outline" size={16} color={accentDark} />
              <Text style={[styles.sortText, { color: accentDark }]}>{t('Trier de A à Z')}</Text>
            </Pressable>
          </View>
          <DraggableFlatList
            data={data}
            keyExtractor={(item) => item.id}
            onDragEnd={({ data: next }) => setData(next)}
            renderItem={renderItem}
            containerStyle={{ flex: 1 }}
            contentContainerStyle={styles.listContent}
            activationDistance={8}
          />
          <View style={styles.footer}>
            <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={styles.flexBtn} />
            <PrimaryButton label={t('Terminé')} onPress={() => onDone(data.map((d) => d.id))} style={styles.flexBtn} />
          </View>
        </SafeAreaView>
      </GestureHandlerRootView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    padding: spacing.md,
    paddingBottom: spacing.sm,
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.text,
  },
  hint: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 4,
  },
  sortBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: spacing.sm,
    alignSelf: 'flex-start',
  },
  sortText: {
    fontSize: 14,
    fontWeight: '700',
  },
  listContent: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.lg,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: spacing.sm + 2,
    paddingLeft: spacing.md,
    paddingRight: spacing.xs,
    marginBottom: spacing.sm,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  sublabel: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  handle: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  footer: {
    flexDirection: 'row',
    gap: spacing.sm,
    padding: spacing.md,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  flexBtn: {
    flex: 1,
  },
});
