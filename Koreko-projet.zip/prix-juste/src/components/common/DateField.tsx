import React, { useState } from 'react';
import { Modal, View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { formatDate, todayIso } from '../../utils/date';
import PrimaryButton from './PrimaryButton';

interface Props {
  value: string; // 'AAAA-MM-JJ'
  onChange: (iso: string) => void;
}

function parseIso(value: string): { y: number; m: number } {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value) ?? /^(\d{4})-(\d{2})-(\d{2})/.exec(todayIso())!;
  return { y: Number(match[1]), m: Number(match[2]) - 1 };
}

function isoFor(y: number, m: number, d: number): string {
  return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

// Case de date : on la touche et un petit calendrier s'ouvre, pas besoin de taper la date.
export default function DateField({ value, onChange }: Props) {
  const { accent, accentDark } = useTheme();
  const { t, locale } = useI18n();
  const [open, setOpen] = useState(false);
  const [viewYear, setViewYear] = useState(() => parseIso(value).y);
  const [viewMonth, setViewMonth] = useState(() => parseIso(value).m);
  const today = todayIso();

  function openCalendar() {
    const selected = parseIso(value);
    setViewYear(selected.y);
    setViewMonth(selected.m);
    setOpen(true);
  }

  function shiftMonth(delta: number) {
    const d = new Date(viewYear, viewMonth + delta, 1);
    setViewYear(d.getFullYear());
    setViewMonth(d.getMonth());
  }

  function pick(isoValue: string) {
    onChange(isoValue);
    setOpen(false);
  }

  const monthLabel = new Date(viewYear, viewMonth, 1).toLocaleDateString(locale, { month: 'long', year: 'numeric' });
  // Semaine commençant le lundi (le 1er janvier 2024 était un lundi).
  const weekdays = Array.from({ length: 7 }, (_, i) =>
    new Date(2024, 0, 1 + i).toLocaleDateString(locale, { weekday: 'narrow' })
  );
  const firstWeekday = (new Date(viewYear, viewMonth, 1).getDay() + 6) % 7;
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const cells: (number | null)[] = [
    ...Array<null>(firstWeekday).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  return (
    <>
      <Pressable style={[inputStyles.input, styles.field]} onPress={openCalendar}>
        <Text style={styles.fieldText}>{formatDate(value)}</Text>
        <Ionicons name="calendar-outline" size={20} color={accentDark} />
      </Pressable>

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.overlay} onPress={() => setOpen(false)}>
          <Pressable style={styles.card} onPress={() => {}}>
            <View style={styles.header}>
              <Pressable onPress={() => shiftMonth(-1)} hitSlop={10} style={styles.arrow}>
                <Ionicons name="chevron-back" size={22} color={accentDark} />
              </Pressable>
              <Text style={[styles.monthLabel, { color: accentDark }]}>{monthLabel}</Text>
              <Pressable onPress={() => shiftMonth(1)} hitSlop={10} style={styles.arrow}>
                <Ionicons name="chevron-forward" size={22} color={accentDark} />
              </Pressable>
            </View>

            <View style={styles.week}>
              {weekdays.map((w, i) => (
                <Text key={i} style={styles.weekday}>
                  {w}
                </Text>
              ))}
            </View>

            {Array.from({ length: cells.length / 7 }, (_, row) => (
              <View key={row} style={styles.week}>
                {cells.slice(row * 7, row * 7 + 7).map((day, i) => {
                  if (day === null) return <View key={i} style={styles.day} />;
                  const cellIso = isoFor(viewYear, viewMonth, day);
                  const isSelected = cellIso === value;
                  const isToday = cellIso === today;
                  return (
                    <Pressable
                      key={i}
                      style={[
                        styles.day,
                        isToday && !isSelected && { borderWidth: 1, borderColor: accent },
                        isSelected && { backgroundColor: accent },
                      ]}
                      onPress={() => pick(cellIso)}
                    >
                      <Text style={[styles.dayText, isSelected && styles.dayTextSelected]}>{day}</Text>
                    </Pressable>
                  );
                })}
              </View>
            ))}

            <View style={styles.footer}>
              <PrimaryButton label={t("Aujourd'hui")} onPress={() => pick(today)} />
              <PrimaryButton label={t('Annuler')} variant="secondary" onPress={() => setOpen(false)} />
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  field: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  fieldText: {
    fontSize: 16,
    color: colors.text,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  arrow: {
    padding: 4,
  },
  monthLabel: {
    fontSize: 16,
    fontWeight: '700',
    textTransform: 'capitalize',
  },
  week: {
    flexDirection: 'row',
  },
  weekday: {
    flex: 1,
    textAlign: 'center',
    fontSize: 12,
    fontWeight: '700',
    color: colors.textMuted,
    paddingVertical: 4,
    textTransform: 'uppercase',
  },
  day: {
    flex: 1,
    aspectRatio: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 999,
    margin: 1,
  },
  dayText: {
    fontSize: 15,
    color: colors.text,
  },
  dayTextSelected: {
    color: '#fff',
    fontWeight: '700',
  },
  footer: {
    gap: spacing.sm,
    marginTop: spacing.md,
  },
});
