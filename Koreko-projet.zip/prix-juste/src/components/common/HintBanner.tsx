import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useHints } from '../../hints/HintsContext';

interface Props {
  id: string;
  text: string;
}

// Petite explication contextuelle, rappelée sur l'écran où elle est utile. Se ferme d'un tap et
// ne réapparaît plus ensuite (mémorisé en base) — sauf si l'utilisateur appuie sur "Revoir les
// astuces" dans Réglages, qui les fait toutes réapparaître.
export default function HintBanner({ id, text }: Props) {
  const { accent, accentDark } = useTheme();
  const { isDismissed, dismiss } = useHints();

  if (isDismissed(id)) return null;

  return (
    <View style={[styles.card, { backgroundColor: accent + '18', borderColor: accent + '40' }]}>
      <Ionicons name="bulb-outline" size={18} color={accentDark} style={styles.icon} />
      <Text style={[styles.text, { color: accentDark }]}>{text}</Text>
      <Pressable onPress={() => dismiss(id)} hitSlop={10} style={styles.closeBtn}>
        <Ionicons name="close" size={16} color={accentDark} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    borderRadius: radius.md,
    borderWidth: 1,
    padding: spacing.sm + 2,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
  },
  icon: {
    marginRight: spacing.xs,
    marginTop: 1,
  },
  text: {
    flex: 1,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
  },
  closeBtn: {
    marginLeft: spacing.xs,
    padding: 2,
  },
});
