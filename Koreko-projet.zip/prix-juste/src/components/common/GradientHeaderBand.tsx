import React, { useCallback } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { setStatusBarStyle } from 'expo-status-bar';
import { useFocusEffect } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { spacing } from '../../theme/colors';

// Rendu à la main (plutôt que via headerBackground du stack natif) car ce dernier s'est révélé
// peu fiable sur Android avec ce dégradé : le fond restait invisible et le titre blanc
// disparaissait dessus. Un simple View + LinearGradient ne dépend d'aucun comportement natif
// capricieux. Utilisé sur tous les écrans de l'appli (headerShown: false sur chaque Stack.Screen)
// pour que la couleur reste présente à toute la navigation, pas seulement sur les 4 onglets.
const HEADER_ORANGE = '#e8792a';
const HEADER_TEAL = '#17a3a8';

interface Props {
  title: string;
  right?: React.ReactNode;
  onBack?: () => void;
}

export default function GradientHeaderBand({ title, right, onBack }: Props) {
  const insets = useSafeAreaInsets();

  useFocusEffect(
    useCallback(() => {
      setStatusBarStyle('light');
      return () => setStatusBarStyle('dark');
    }, [])
  );

  return (
    <LinearGradient
      colors={[HEADER_ORANGE, '#c98a56', HEADER_TEAL]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0.3 }}
      style={[styles.band, { paddingTop: insets.top + spacing.sm }]}
    >
      <View style={styles.left}>
        {onBack && (
          <Pressable onPress={onBack} hitSlop={10} style={styles.backBtn}>
            <Ionicons name="chevron-back" size={24} color="#ffffff" />
          </Pressable>
        )}
        <Text style={styles.title} numberOfLines={1}>
          {title}
        </Text>
      </View>
      {right ? <View style={styles.right}>{right}</View> : null}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  band: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
  },
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    flexShrink: 1,
  },
  backBtn: {
    marginRight: spacing.xs,
  },
  title: {
    color: '#ffffff',
    fontSize: 20,
    fontWeight: '800',
    flexShrink: 1,
  },
  right: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
});
