import React from 'react';
import { ScrollView, ScrollViewProps, Platform, StyleProp, ViewStyle } from 'react-native';
import { useKeyboardHeight } from '../../hooks/useKeyboardHeight';

// A drop-in replacement for ScrollView on forms with fields near the bottom. Android's native
// window resize/pan behavior for the keyboard is unreliable with edge-to-edge enabled (see
// AGENTS.md), so instead of fighting it, this just adds enough real bottom padding — sized to
// the keyboard's actual reported height — that any field can always be scrolled fully above it.
export default function KeyboardAwareScrollView({ contentContainerStyle, children, ...props }: ScrollViewProps) {
  const keyboardHeight = useKeyboardHeight();
  const extraPadding = Platform.OS === 'android' && keyboardHeight > 0 ? keyboardHeight + 24 : 0;

  const mergedStyle: StyleProp<ViewStyle> = [contentContainerStyle, extraPadding > 0 && { paddingBottom: extraPadding }];

  return (
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={mergedStyle} {...props}>
      {children}
    </ScrollView>
  );
}
