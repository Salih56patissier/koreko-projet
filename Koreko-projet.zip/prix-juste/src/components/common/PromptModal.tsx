import React, { useEffect, useState } from 'react';
import { Modal, View, Text, TextInput, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import PrimaryButton from './PrimaryButton';
import KeyboardAwareScrollView from './KeyboardAwareScrollView';
import { useI18n } from '../../i18n/I18nContext';

interface Props {
  visible: boolean;
  title: string;
  placeholder?: string;
  initialValue?: string;
  onSubmit: (value: string) => void;
  onCancel: () => void;
}

export default function PromptModal({ visible, title, placeholder, initialValue, onSubmit, onCancel }: Props) {
  const { t } = useI18n();
  const [value, setValue] = useState(initialValue ?? '');

  useEffect(() => {
    if (visible) setValue(initialValue ?? '');
  }, [visible, initialValue]);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.card}>
          <KeyboardAwareScrollView>
            <Text style={styles.title}>{title}</Text>
            <TextInput
              style={inputStyles.input}
              value={value}
              onChangeText={setValue}
              placeholder={placeholder}
              placeholderTextColor={colors.textMuted}
              autoFocus
            />
            <View style={styles.row}>
              <PrimaryButton label={t('Annuler')} variant="secondary" onPress={onCancel} style={styles.flexBtn} />
              <PrimaryButton
                label={t('Valider')}
                disabled={value.trim().length === 0}
                onPress={() => onSubmit(value.trim())}
                style={styles.flexBtn}
              />
            </View>
          </KeyboardAwareScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(58, 46, 34, 0.4)',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    maxHeight: '90%',
  },
  title: {
    fontSize: 17,
    fontWeight: '700',
    color: colors.text,
    marginBottom: spacing.md,
  },
  row: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  flexBtn: {
    flex: 1,
  },
});
