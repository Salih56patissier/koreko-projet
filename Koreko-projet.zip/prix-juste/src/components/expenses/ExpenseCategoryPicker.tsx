import React, { useState } from 'react';
import { View, Text, Pressable, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSQLiteContext } from 'expo-sqlite';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import PromptModal from '../common/PromptModal';
import { ExpenseCategory } from '../../types/models';
import {
  createExpenseCategory,
  deleteExpenseCategory,
  listExpenseCategories,
  updateExpenseCategory,
} from '../../db/repositories/expenseCategoriesRepo';

interface Props {
  categories: ExpenseCategory[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onCategoriesChanged: (categories: ExpenseCategory[]) => void;
  allowNone?: boolean;
}

export default function ExpenseCategoryPicker({
  categories,
  selectedId,
  onSelect,
  onCategoriesChanged,
  allowNone,
}: Props) {
  const db = useSQLiteContext();
  const { accent } = useTheme();
  const { t } = useI18n();
  const [addVisible, setAddVisible] = useState(false);
  const [editing, setEditing] = useState<ExpenseCategory | null>(null);

  async function refresh() {
    onCategoriesChanged(await listExpenseCategories(db));
  }

  async function handleCreate(name: string) {
    setAddVisible(false);
    const id = await createExpenseCategory(db, name);
    await refresh();
    onSelect(id);
  }

  async function handleRename(newName: string) {
    if (!editing) return;
    setEditing(null);
    await updateExpenseCategory(db, editing.id, newName);
    await refresh();
  }

  function handleLongPress(category: ExpenseCategory) {
    Alert.alert(category.name, undefined, [
      { text: t('Renommer'), onPress: () => setEditing(category) },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: () =>
          Alert.alert(
            t('Supprimer cette catégorie ?'),
            t('Les dépenses de cette catégorie sont gardées, elles passent simplement « Sans catégorie ».'),
            [
              { text: t('Annuler'), style: 'cancel' },
              {
                text: t('Supprimer'),
                style: 'destructive',
                onPress: async () => {
                  await deleteExpenseCategory(db, category.id);
                  if (selectedId === category.id) onSelect(null);
                  await refresh();
                },
              },
            ]
          ),
      },
      { text: t('Annuler'), style: 'cancel' },
    ]);
  }

  return (
    <View>
      {categories.length > 0 && (
        <Text style={styles.hint}>{t('Appui long sur une catégorie pour la renommer ou la supprimer.')}</Text>
      )}
      <View style={styles.chipWrap}>
        {allowNone && (
          <Pressable
            onPress={() => onSelect(null)}
            style={[styles.chip, { borderColor: colors.border }, selectedId === null && styles.chipNoneActive]}
          >
            <Text style={[styles.chipText, { color: selectedId === null ? colors.text : colors.textMuted }]}>
              {t('Aucune')}
            </Text>
          </Pressable>
        )}
        {categories.map((c) => {
          const active = selectedId === c.id;
          return (
            <Pressable
              key={c.id}
              onPress={() => onSelect(c.id)}
              onLongPress={() => handleLongPress(c)}
              style={[styles.chip, active && { backgroundColor: accent, borderColor: accent }]}
            >
              <Text style={[styles.chipText, active && styles.chipTextActive]}>{c.name}</Text>
            </Pressable>
          );
        })}
        <Pressable style={styles.addChip} onPress={() => setAddVisible(true)}>
          <Ionicons name="add" size={16} color={colors.textMuted} />
          <Text style={styles.addChipText}>{t('Nouvelle catégorie')}</Text>
        </Pressable>
      </View>

      <PromptModal
        visible={addVisible}
        title={t('Nouvelle catégorie de dépense')}
        placeholder={t('ex: Fournitures')}
        onSubmit={handleCreate}
        onCancel={() => setAddVisible(false)}
      />
      <PromptModal
        visible={!!editing}
        title={t('Renommer la catégorie')}
        initialValue={editing?.name}
        onSubmit={handleRename}
        onCancel={() => setEditing(null)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  hint: {
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: spacing.xs,
  },
  chipWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  chip: {
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
    backgroundColor: colors.surface,
  },
  chipNoneActive: {
    backgroundColor: colors.surfaceAlt,
  },
  chipText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.text,
  },
  chipTextActive: {
    color: '#fff',
  },
  addChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderStyle: 'dashed',
    marginBottom: spacing.xs,
  },
  addChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textMuted,
    marginLeft: 2,
  },
});
