import * as ImagePicker from 'expo-image-picker';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import { Directory, File, Paths } from 'expo-file-system';
import { newId } from './uuid';

const PHOTOS_DIR_NAME = 'recipe-photos';
// Largeur maximale gardée : largement assez pour l'écran et la fiche PDF, et ça garde la
// sauvegarde (qui contient les photos) légère.
const MAX_PHOTO_WIDTH = 1200;

export function getPhotosDirectory(): Directory {
  const dir = new Directory(Paths.document, PHOTOS_DIR_NAME);
  if (!dir.exists) dir.create();
  return dir;
}

export async function pickAndStoreRecipePhoto(): Promise<string | null> {
  const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permission.granted) return null;

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsEditing: true,
    aspect: [4, 3],
    quality: 0.8,
  });
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];

  let sourceUri = asset.uri;
  try {
    const context = ImageManipulator.manipulate(asset.uri);
    if (asset.width > MAX_PHOTO_WIDTH) context.resize({ width: MAX_PHOTO_WIDTH });
    const image = await context.renderAsync();
    const saved = await image.saveAsync({ compress: 0.7, format: SaveFormat.JPEG });
    sourceUri = saved.uri;
  } catch {
    // Réduction impossible : on garde la photo d'origine.
  }

  const sourceFile = new File(sourceUri);
  const extension = sourceFile.extension || '.jpg';
  const destDir = getPhotosDirectory();
  const destFile = new File(destDir, `${newId()}${extension}`);
  sourceFile.copy(destFile);
  return destFile.uri;
}

// Copie le fichier photo vers un nouveau fichier indépendant (nouvel id) — utilisé pour la
// duplication de recette : chaque recette a son propre fichier, jamais partagé, pour que la
// suppression de l'une n'efface pas la photo de l'autre.
export function duplicateRecipePhoto(uri: string | null): string | null {
  if (!uri) return null;
  try {
    const sourceFile = new File(uri);
    if (!sourceFile.exists) return null;
    const extension = sourceFile.extension || '.jpg';
    const destDir = getPhotosDirectory();
    const destFile = new File(destDir, `${newId()}${extension}`);
    sourceFile.copy(destFile);
    return destFile.uri;
  } catch {
    return null;
  }
}

// Une sauvegarde garde l'adresse de la photo mais pas le fichier : après une restauration (ou un
// changement de téléphone), la photo peut ne plus exister. On la traite alors comme absente pour
// afficher « Ajouter une photo » au lieu d'un cadre vide.
export function photoFileExists(uri: string | null): uri is string {
  if (!uri) return false;
  try {
    return new File(uri).exists;
  } catch {
    return false;
  }
}

export function deleteRecipePhoto(uri: string | null): void {
  if (!uri) return;
  try {
    const file = new File(uri);
    if (file.exists) file.delete();
  } catch {
    // photo already gone or inaccessible — nothing to clean up
  }
}
