// Utilisé pour comparer des noms d'ingrédients tapés au clavier téléphone : les accents et les
// espaces en trop (notamment celui que le clavier ajoute après un mot suggéré) ne doivent jamais
// empêcher de retrouver un ingrédient déjà enregistré.
export function normalizeSearch(text: string): string {
  return (
    text
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      // Arabe : voyelles brèves (tashkeel), allongement (tatweel) et variantes du alef, du yaa et
      // du taa marbouta ramenés à une forme unique — on écrit rarement tous ces signes pareil.
      .replace(/[\u064b-\u065f\u0670\u0640]/g, '')
      .replace(/[\u0622\u0623\u0625\u0671]/g, '\u0627')
      .replace(/\u0649/g, '\u064a')
      .replace(/\u0629/g, '\u0647')
      // Russe : « ё » et « е » s'écrivent indifféremment.
      .replace(/\u0451/g, '\u0435')
      .toLowerCase()
      .trim()
      .replace(/\s+/g, ' ')
  );
}

// Forme « tolérante » d'un texte pour la recherche de recettes : sans accents, sans majuscules,
// toute ponctuation remplacée par des espaces (« Crème d'Amande.. » → « creme d amande »).
function looseWords(text: string): string[] {
  return normalizeSearch(text)
    // On coupe sur les espaces et la ponctuation, SANS jeter les lettres des autres alphabets
    // (arabe, cyrillique…) : avant, un nom en arabe ou en russe devenait « vide » et rien ne se
    // trouvait.
    .split(/[\s.,;:!?'"’‘`´()\[\]{}\/\\|_+*&%$#@^~<>=\-–—…«»،؛؟·•]+/)
    .filter(Boolean);
}

// Nombre minimal de lettres à ajouter, enlever ou changer pour passer de `a` à `b`.
function editDistance(a: string, b: string): number {
  let prev = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    for (let j = 1; j <= b.length; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = cur;
  }
  return prev[b.length];
}

// Fautes tolérées pour un mot tapé : aucune pour les mots très courts, une à partir de 4 lettres,
// deux à partir de 8.
function allowedTypos(word: string): number {
  return word.length >= 8 ? 2 : word.length >= 4 ? 1 : 0;
}

// Un mot tapé correspond à un mot du nom s'il en est le début (« pati » → « patissiere »), ou s'il
// lui ressemble à quelques fautes près (« patisiere », « patissère »…).
function wordMatches(typed: string, word: string): number | null {
  if (word.startsWith(typed)) return 0;
  const typos = allowedTypos(typed);
  if (typos === 0) return null;
  const distance = Math.min(
    editDistance(typed, word),
    // mot tapé incomplet avec une faute : on compare au début du mot de même longueur
    editDistance(typed, word.slice(0, typed.length))
  );
  return distance <= typos ? distance : null;
}

// Recherche souple : accents, majuscules, espaces et ponctuation ignorés, petites fautes de
// frappe tolérées. Renvoie un score (0 = correspondance parfaite, plus petit = meilleur) ou null.
export function fuzzyMatchScore(query: string, name: string): number | null {
  const queryWords = looseWords(query);
  if (queryWords.length === 0) return null;
  const nameWords = looseWords(name);
  // Espaces ignorés : « mille feuille » trouve « Millefeuille » et inversement.
  if (nameWords.join('').includes(queryWords.join(''))) return 0;
  let score = 0;
  for (const typed of queryWords) {
    let best: number | null = null;
    for (const word of nameWords) {
      const s = wordMatches(typed, word);
      if (s !== null && (best === null || s < best)) best = s;
    }
    if (best === null) return null;
    score += best + 1;
  }
  return score;
}

// Un œuf pèse environ 50 g : sert à proposer ce poids d'office pour un ingrédient « œufs »
// acheté à la pièce (dans les langues de l'app).
export const EGG_WEIGHT_G = 50;

export function looksLikeEgg(name: string): boolean {
  return /(^|[^a-z])(oeufs?|œufs?|eggs?|huevos?|uova|uovo|eier?)([^a-z]|$)|я[йи]ц|بيض/.test(normalizeSearch(name));
}
