let currentCurrencySymbol = 'DH';

export function setCurrencySymbol(symbol: string): void {
  currentCurrencySymbol = symbol.trim() || 'DH';
}

export function getCurrencySymbol(): string {
  return currentCurrencySymbol;
}

export function formatMoney(amount: number): string {
  const rounded = Math.round(amount * 100) / 100;
  return `${rounded.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currentCurrencySymbol}`;
}

export function formatQuantity(value: number): string {
  if (Number.isInteger(value)) return String(value);
  return value.toLocaleString('fr-FR', { maximumFractionDigits: 2 });
}

export function formatWeight(grams: number): string {
  const rounded = Math.round(grams);
  if (rounded >= 1000) {
    const kg = rounded / 1000;
    return `${rounded.toLocaleString('fr-FR')} g (${kg.toLocaleString('fr-FR', { maximumFractionDigits: 2 })} kg)`;
  }
  return `${rounded.toLocaleString('fr-FR')} g`;
}

// `t` is optional so these keep working in the few places (e.g. the PDF
// generator) that don't have a React tree / translation context handy —
// they'll just fall back to French there.
export function unitLabel(unit: 'g' | 'ml' | 'unite', t?: (key: string) => string): string {
  if (unit === 'g') return 'g';
  if (unit === 'ml') return 'ml';
  const label = 'unité(s)';
  return t ? t(label) : label;
}

export function purchaseUnitLabel(
  unit: 'kg' | 'g' | 'l' | 'unite' | 'paquet' | 'carton',
  t?: (key: string) => string
): string {
  if (unit === 'kg') return 'kg';
  if (unit === 'g') return 'g';
  if (unit === 'l') return t ? t('litre') : 'litre';
  if (unit === 'paquet') return t ? t('paquet') : 'paquet';
  if (unit === 'carton') return t ? t('carton') : 'carton';
  const label = 'unité';
  return t ? t(label) : label;
}
