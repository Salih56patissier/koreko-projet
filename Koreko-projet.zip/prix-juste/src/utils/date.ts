// Les dates sont stockées en texte 'AAAA-MM-JJ' (tri et filtres par mois simples),
// mais affichées à l'utilisatrice en 'JJ/MM/AAAA'.

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

export function toIsoDate(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// Date du jour selon l'heure du téléphone (et non en UTC : juste après minuit,
// toISOString() donnerait encore la veille).
export function todayIso(): string {
  return toIsoDate(new Date());
}

// 'AAAA-MM-JJ' -> 'JJ/MM/AAAA'. Une valeur inattendue est rendue telle quelle.
export function formatDate(iso: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso;
}
