import {
  BaseUnit,
  PurchaseUnit,
  RecipeExtraCost,
  RecipeGroupItemWithIngredient,
  RecipeGroupWithItems,
  RecipeCostSummary,
} from '../types/models';

// Unités « à compter » : le prix est pour UNE pièce / UN paquet / UN carton. Pour s'en servir au
// gramme dans les recettes, il faut connaître le poids d'une unité.
export function isCountUnit(unit: PurchaseUnit): boolean {
  return unit === 'unite' || unit === 'paquet' || unit === 'carton';
}

// Poids (g) d'une unité d'achat à utiliser pour le calcul : celui enregistré sur l'achat, ou — pour
// les anciens achats à la pièce, faits avant que le poids soit gardé sur chaque achat — le poids
// d'une pièce de l'ingrédient. null = pas de conversion possible.
export function purchaseWeightG(
  unit: PurchaseUnit,
  unitWeightG: number | null | undefined,
  ingredientPieceWeightG?: number | null
): number | null {
  if (unit === 'kg' || unit === 'g') return null;
  if (unitWeightG && unitWeightG > 0) return unitWeightG;
  if (unit === 'unite' && ingredientPieceWeightG && ingredientPieceWeightG > 0) return ingredientPieceWeightG;
  return null;
}

// `weightG` : poids en grammes d'UNE unité d'achat (50 pour un œuf, 1500 pour un plateau, 1030
// pour un litre de lait si on le précise). Sans lui, une unité « à compter » reste 'unite' (usage
// à la pièce, ex: une boîte de décor) et un litre reste en 'ml'.
export function baseUnitForPurchaseUnit(unit: PurchaseUnit, weightG?: number | null): BaseUnit {
  if (unit === 'kg' || unit === 'g') return 'g';
  if (unit === 'l') return weightG ? 'g' : 'ml';
  return weightG ? 'g' : 'unite';
}

// Converts a purchase quantity (e.g. 500 g, or 1.5 kg, or 10 pièces à 50g) into the base unit
// quantity used for pricing (grams, millilitres, or units).
export function toBaseQuantity(purchaseQuantity: number, purchaseUnit: PurchaseUnit, weightG?: number | null): number {
  if (purchaseUnit === 'kg') return purchaseQuantity * 1000;
  if (purchaseUnit === 'g') return purchaseQuantity;
  if (weightG) return purchaseQuantity * weightG; // litre pesé, pièce, paquet, carton
  if (purchaseUnit === 'l') return purchaseQuantity * 1000;
  return purchaseQuantity;
}

// Quantité d'une ligne de recette exprimée dans l'unité de prix de l'ingrédient. Une ligne peut
// être en pièces alors que le prix est au gramme (ex: « 2 œufs » avec un œuf = 50 g → 100 g), ou
// l'inverse : grâce au poids d'une pièce, les deux se convertissent.
export function itemQuantityInBaseUnit(
  quantity: number,
  itemUnit: BaseUnit,
  ingredientBaseUnit: BaseUnit,
  avgPieceWeightG?: number | null
): number {
  if (itemUnit === ingredientBaseUnit || !avgPieceWeightG) return quantity;
  if (itemUnit === 'unite') return quantity * avgPieceWeightG;
  if (ingredientBaseUnit === 'unite') return quantity / avgPieceWeightG;
  return quantity; // g ↔ ml : même nombre (1 ml ≈ 1 g)
}

// Poids en grammes d'une ligne de recette (0 si on ne peut pas le savoir : pièce sans poids).
export function itemWeightGrams(quantity: number, itemUnit: BaseUnit, avgPieceWeightG?: number | null): number {
  if (itemUnit === 'g' || itemUnit === 'ml') return quantity;
  return avgPieceWeightG ? quantity * avgPieceWeightG : 0;
}

export function computeUnitPrice(
  purchasePrice: number,
  purchaseQuantity: number,
  purchaseUnit: PurchaseUnit,
  weightG?: number | null
): number {
  const baseQty = toBaseQuantity(purchaseQuantity, purchaseUnit, weightG);
  if (baseQty <= 0) return 0;
  return purchasePrice / baseQty;
}

// Extrait le prix HT à partir du prix réellement payé (TTC) et du taux de TVA de l'ingrédient
// (ex: achat au marché/grossiste sans facture détaillée). C'est ce HT qui doit toujours servir
// au calcul du coût de revient des recettes, jamais le prix payé brut.
export function priceExcludingVat(pricePaid: number, vatRatePercent: number): number {
  return pricePaid / (1 + vatRatePercent / 100);
}

export function lineCost(unitPrice: number, quantity: number): number {
  return unitPrice * quantity;
}

// Cost per gram of a finished recipe (used when that recipe is referenced as
// a component/sub-recipe inside another one). 0 when the recipe has no
// weighable ingredients yet, to avoid dividing by zero.
export function componentUnitPrice(totalRealCost: number, totalWeight: number): number {
  if (totalWeight <= 0) return 0;
  return totalRealCost / totalWeight;
}

export function groupCost(items: RecipeGroupItemWithIngredient[]): number {
  return items.reduce((sum, item) => sum + item.lineCost, 0);
}

export function ingredientsCostForRecipe(groups: RecipeGroupWithItems[]): number {
  return groups.reduce((sum, g) => sum + g.groupCost, 0);
}

// Total weight in grams, summing 'g' and 'ml' quantities (1 ml treated as 1 g,
// the usual baking approximation for water-based liquids). Items measured in
// 'unite' (eggs counted by piece, etc.) are not weighable and excluded.
export function totalWeightGrams(groups: RecipeGroupWithItems[]): number {
  return groups.reduce(
    (sum, g) => sum + g.items.reduce((s, item) => s + itemWeightGrams(item.quantity, item.unit, item.avgPieceWeightG), 0),
    0
  );
}

export function extraCostsTotal(extraCosts: Pick<RecipeExtraCost, 'cost'>[]): number {
  return extraCosts.reduce((sum, e) => sum + e.cost, 0);
}

export interface RecipeCostInput {
  groups: RecipeGroupWithItems[];
  extraCosts: RecipeExtraCost[];
  laborHours: number;
  hourlyRate: number;
  marginPercent: number;
  servings: number;
  billedPrice: number | null;
}

export function computeRecipeCost(input: RecipeCostInput): RecipeCostSummary {
  const ingredientsCost = ingredientsCostForRecipe(input.groups);
  const laborCost = input.laborHours * input.hourlyRate;
  const extras = extraCostsTotal(input.extraCosts);
  const totalRealCost = ingredientsCost + laborCost + extras;
  const fairPrice = totalRealCost * (1 + input.marginPercent / 100);
  const servings = input.servings > 0 ? input.servings : 1;
  const pricePerServing = fairPrice / servings;
  const costPerServing = totalRealCost / servings;

  let isSellingAtLoss = false;
  let lossAmount: number | null = null;
  let effectiveHourlyEarnings: number | null = null;
  let realMarginAmount: number | null = null;
  let realMarginPercent: number | null = null;

  // input.billedPrice est le prix facturé pour UNE part/pièce (voir le champ "Prix
  // actuellement facturé" et le texte "tu perds X par pièce") — il doit donc être comparé
  // au coût par part, pas au coût total de la recette qui couvre toutes les parts produites.
  if (input.billedPrice != null) {
    realMarginAmount = input.billedPrice - costPerServing;
    realMarginPercent = costPerServing > 0 ? (realMarginAmount / costPerServing) * 100 : null;

    if (input.billedPrice < costPerServing) {
      isSellingAtLoss = true;
      lossAmount = costPerServing - input.billedPrice;
    } else if (input.laborHours > 0) {
      const totalRevenue = input.billedPrice * servings;
      const marginOverNonLaborCosts = totalRevenue - (ingredientsCost + extras);
      effectiveHourlyEarnings = marginOverNonLaborCosts / input.laborHours;
    }
  }

  return {
    ingredientsCost,
    laborCost,
    extraCostsTotal: extras,
    totalRealCost,
    fairPrice,
    pricePerServing,
    isSellingAtLoss,
    lossAmount,
    effectiveHourlyEarnings,
    realMarginAmount,
    realMarginPercent,
  };
}
