import React, { useCallback, useState } from 'react';
import { View, Text, FlatList, TextInput, Pressable, StyleSheet } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import HintBanner from '../../components/common/HintBanner';
import SettingsHeaderButton from '../../navigation/SettingsHeaderButton';
import AddShoppingListItemModal from '../../components/shoppingList/AddShoppingListItemModal';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { inputStyles } from '../../theme/inputStyle';
import { Ingredient, IngredientCategory, IngredientPriceInfo } from '../../types/models';
import { listIngredients } from '../../db/repositories/ingredientsRepo';
import { listIngredientCategories } from '../../db/repositories/ingredientCategoriesRepo';
import { getIngredientPriceInfoMap, hasAnyPurchases } from '../../db/repositories/ingredientPurchasesRepo';
import { addToShoppingList } from '../../db/repositories/shoppingListRepo';
import { formatMoney, getCurrencySymbol, purchaseUnitLabel, unitLabel } from '../../utils/format';
import { IngredientsStackParamList } from '../../navigation/types';

type Nav = NativeStackNavigationProp<IngredientsStackParamList, 'IngredientsList'>;

const CHEAPER_ELSEWHERE_THRESHOLD = 0.001; // ignore rounding-noise "differences"

export default function IngredientsListScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation<Nav>();
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();
  const [search, setSearch] = useState('');
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [categories, setCategories] = useState<IngredientCategory[]>([]);
  const [priceInfo, setPriceInfo] = useState<Map<string, IngredientPriceInfo>>(new Map());
  const [hasPurchases, setHasPurchases] = useState(true); // assume true until checked, to avoid a banner flash
  const [addToListIngredient, setAddToListIngredient] = useState<Ingredient | null>(null);

  const load = useCallback(async () => {
    const [rows, cats, info, anyPurchases] = await Promise.all([
      listIngredients(db, search || undefined),
      listIngredientCategories(db),
      getIngredientPriceInfoMap(db),
      hasAnyPurchases(db),
    ]);
    setIngredients(rows);
    setCategories(cats);
    setPriceInfo(info);
    setHasPurchases(anyPurchases);
  }, [db, search]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  return (
    <ScreenContainer>
      <GradientHeaderBand
        title={t('Ingrédients')}
        right={
          <>
            <Pressable onPress={() => navigation.navigate('ImportIngredients')} hitSlop={8}>
              <Ionicons name="download-outline" size={22} color="#ffffff" />
            </Pressable>
            <SettingsHeaderButton />
          </>
        }
      />
      <HintBanner
        id="ingredients-intro"
        text={t("Note ici le prix réel de chaque ingrédient : l'appli calcule seule le coût au gramme.")}
      />
      {!hasPurchases && ingredients.length > 0 && (
        <View style={styles.banner}>
          <Ionicons name="bulb-outline" size={18} color={accentDark} style={{ marginRight: spacing.sm }} />
          <Text style={[styles.bannerText, { color: accentDark }]}>
            {t(
              "Le comparateur de prix apparaît ici dès que tu enregistres un premier achat : ouvre un ingrédient, puis \"Enregistrer un achat\"."
            )}
          </Text>
        </View>
      )}

      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          placeholder={t('Rechercher un ingrédient...')}
          placeholderTextColor={colors.textMuted}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      <FlatList
        data={ingredients}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            {t('Aucun ingrédient. Ajoute ta base de prix avec le bouton +.')}
          </Text>
        }
        renderItem={({ item }) => {
          const category = categories.find((c) => c.id === item.categoryId);
          const info = priceInfo.get(item.id);
          const hasCheaper =
            info?.cheapestSupplierName != null &&
            info.cheapestUnitPrice != null &&
            info.cheapestUnitPrice < item.unitPrice - CHEAPER_ELSEWHERE_THRESHOLD;
          return (
            <Pressable
              style={[styles.row, category && { borderColor: category.color, borderWidth: 5 }]}
              onPress={() => navigation.navigate('IngredientForm', { ingredientId: item.id })}
            >
              <View style={styles.nameRow}>
                <Text style={[styles.name, { flex: 1 }]}>{item.name}</Text>
                <Pressable onPress={() => setAddToListIngredient(item)} hitSlop={8} style={{ padding: 2 }}>
                  <Ionicons name="cart-outline" size={20} color={accentDark} />
                </Pressable>
              </View>
              <View style={styles.subRow}>
                <Text style={styles.sub}>
                  {t('{price} pour {qty} {unit}', {
                    price: formatMoney(item.purchasePrice),
                    qty: item.purchaseQuantity,
                    unit: purchaseUnitLabel(item.purchaseUnit, t),
                  })}
                  {category ? ` · ${category.name}` : ''}
                </Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                  {info?.trend === 'up' && <Ionicons name="trending-up" size={14} color={colors.danger} />}
                  {info?.trend === 'down' && <Ionicons name="trending-down" size={14} color={colors.success} />}
                  <Text style={[styles.unitPrice, { color: accentDark }]}>
                    {item.unitPrice.toLocaleString('fr-FR', { maximumFractionDigits: 4 })} {getCurrencySymbol()}/{unitLabel(item.baseUnit, t)}
                  </Text>
                </View>
              </View>
              {hasCheaper && (
                <Text style={styles.cheaperText}>
                  {t('💡 Moins cher chez {supplier} : {price}', {
                    supplier: info!.cheapestSupplierName!,
                    price: `${info!.cheapestUnitPrice!.toLocaleString('fr-FR', { maximumFractionDigits: 4 })} ${getCurrencySymbol()}/${unitLabel(item.baseUnit, t)}`,
                  })}
                </Text>
              )}
            </Pressable>
          );
        }}
      />

      <Pressable style={[styles.fab, { backgroundColor: accent }]} onPress={() => navigation.navigate('IngredientForm', {})}>
        <Ionicons name="add" size={30} color="#fff" />
      </Pressable>

      <AddShoppingListItemModal
        visible={!!addToListIngredient}
        ingredients={ingredients}
        fixedIngredient={addToListIngredient ?? undefined}
        onSubmit={async (data) => {
          setAddToListIngredient(null);
          await addToShoppingList(db, data);
        }}
        onCancel={() => setAddToListIngredient(null)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surfaceAlt,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
  },
  bannerText: {
    flex: 1,
    fontSize: 13,
    fontWeight: '600',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  searchInput: {
    flex: 1,
    paddingVertical: spacing.sm + 4,
    fontSize: 16,
    color: colors.text,
  },
  listContent: {
    padding: spacing.md,
    paddingBottom: 100,
  },
  row: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  subRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 2,
    gap: spacing.sm,
  },
  sub: {
    flexShrink: 1,
    fontSize: 13,
    color: colors.textMuted,
  },
  cheaperText: {
    fontSize: 12,
    color: colors.success,
    marginTop: 2,
    fontWeight: '600',
  },
  unitPrice: {
    fontSize: 14,
    fontWeight: '700',
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginTop: spacing.xl,
    fontSize: 15,
  },
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: spacing.lg,
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
});
