import React, { useRef, useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, TextInput, StyleSheet, Pressable, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useFocusEffect, useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import KeyboardAwareScrollView from '../../components/common/KeyboardAwareScrollView';
import SectionCard from '../../components/common/SectionCard';
import FieldLabel from '../../components/common/FieldLabel';
import PrimaryButton from '../../components/common/PrimaryButton';
import PromptModal from '../../components/common/PromptModal';
import SupplierPicker from '../../components/ingredient/SupplierPicker';
import PurchaseFormModal from '../../components/ingredient/PurchaseFormModal';
import PriceCorrectionModal from '../../components/ingredient/PriceCorrectionModal';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { useEditGuard } from '../../access/AccessContext';
import { inputStyles } from '../../theme/inputStyle';
import { IngredientsStackParamList } from '../../navigation/types';
import {
  createIngredient,
  deleteIngredient,
  getIngredient,
  IngredientInUseError,
  updateIngredient,
  updateIngredientDetails,
  updateIngredientVatRate,
} from '../../db/repositories/ingredientsRepo';
import {
  createIngredientCategory,
  deleteIngredientCategory,
  listIngredientCategories,
  updateIngredientCategory,
} from '../../db/repositories/ingredientCategoriesRepo';
import { listSuppliers } from '../../db/repositories/suppliersRepo';
import {
  deletePurchase,
  getSupplierComparison,
  listPurchasesForIngredient,
  recordPurchase,
  updatePurchase,
} from '../../db/repositories/ingredientPurchasesRepo';
import { confirmPurchaseUnit } from '../../components/ingredient/confirmPurchaseUnit';
import { listRecipesUsingIngredient, RecipeUsingIngredient } from '../../db/repositories/recipesRepo';
import { computeUnitPrice, priceExcludingVat } from '../../utils/priceCalc';
import { Ingredient, IngredientCategory, IngredientPurchase, PurchaseUnit, Supplier, SupplierPriceRow } from '../../types/models';
import { formatMoney, formatQuantity, getCurrencySymbol, purchaseUnitLabel, unitLabel } from '../../utils/format';
import { PurchaseUnitPicker, UnitWeightField, asksUnitWeight, parseWeight } from '../../components/ingredient/UnitFields';
import { baseUnitForPurchaseUnit } from '../../utils/priceCalc';
import { formatDate, todayIso } from '../../utils/date';

type Route = RouteProp<IngredientsStackParamList, 'IngredientForm'>;

const VAT_RATES = [0, 10, 20];

export default function IngredientFormScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation();
  const route = useRoute<Route>();
  const ingredientId = route.params?.ingredientId;
  const { accent, accentDark } = useTheme();
  const { t, locale } = useI18n();
  const guard = useEditGuard();
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);

  const [name, setName] = useState('');
  // Only used when creating a new ingredient — once it exists, price is
  // driven entirely by recorded purchases (see below), never edited here.
  const [purchasePrice, setPurchasePrice] = useState('');
  const [purchaseQuantity, setPurchaseQuantity] = useState('');
  const [purchaseUnit, setPurchaseUnit] = useState<PurchaseUnit>('kg');
  const [vatRate, setVatRate] = useState(0);
  // Poids (g) d'UNE unité achetée (pièce, paquet, carton, litre) : à la création de l'ingrédient.
  const [unitWeight, setUnitWeight] = useState('');
  const [initialSupplierId, setInitialSupplierId] = useState<string | null>(null);

  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [categories, setCategories] = useState<IngredientCategory[]>([]);
  const [addCategoryVisible, setAddCategoryVisible] = useState(false);
  const [editingCategory, setEditingCategory] = useState<IngredientCategory | null>(null);
  const [loaded, setLoaded] = useState(!ingredientId);

  const [currentIngredient, setCurrentIngredient] = useState<Ingredient | null>(null);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchases, setPurchases] = useState<IngredientPurchase[]>([]);
  const [comparison, setComparison] = useState<SupplierPriceRow[]>([]);
  const [purchaseModalVisible, setPurchaseModalVisible] = useState(false);
  const [editingPurchase, setEditingPurchase] = useState<IngredientPurchase | null>(null);
  const [priceCorrectionVisible, setPriceCorrectionVisible] = useState(false);
  const [usedInRecipes, setUsedInRecipes] = useState<RecipeUsingIngredient[]>([]);
  const [showUsedIn, setShowUsedIn] = useState(false);
  const [historyMonth, setHistoryMonth] = useState(() => route.params?.month ?? todayIso().slice(0, 7));

  useEffect(() => {
    listIngredientCategories(db).then(setCategories);
    listSuppliers(db).then((s) => {
      setSuppliers(s);
      setInitialSupplierId((prev) => prev ?? s[0]?.id ?? null);
    });
  }, [db]);

  const loadPriceData = useCallback(async () => {
    if (!ingredientId) return;
    const [ing, purchaseRows, comparisonRows, recipeRows] = await Promise.all([
      getIngredient(db, ingredientId),
      listPurchasesForIngredient(db, ingredientId),
      getSupplierComparison(db, ingredientId),
      listRecipesUsingIngredient(db, ingredientId),
    ]);
    setUsedInRecipes(recipeRows);
    setCurrentIngredient(ing);
    setPurchases(purchaseRows);
    setComparison(comparisonRows);
  }, [db, ingredientId]);

  useEffect(() => {
    if (!ingredientId) return;
    getIngredient(db, ingredientId).then((ing) => {
      if (ing) {
        setName(ing.name);
        setCategoryId(ing.categoryId);
        setVatRate(ing.vatRate);
      }
      setLoaded(true);
    });
  }, [db, ingredientId]);

  useFocusEffect(
    useCallback(() => {
      loadPriceData();
    }, [loadPriceData])
  );

  const purchasesForMonth = useMemo(() => purchases.filter((p) => p.purchaseDate.startsWith(historyMonth)), [
    purchases,
    historyMonth,
  ]);

  // Additionner des kg et des paquets n'aurait pas de sens : la quantité totale n'est affichée
  // que si tous les achats du mois sont dans la même unité.
  const monthUnit = useMemo(
    () => (purchasesForMonth.every((p) => p.unit === purchasesForMonth[0]?.unit) ? purchasesForMonth[0]?.unit : null),
    [purchasesForMonth]
  );

  const monthTotals = useMemo(() => {
    return purchasesForMonth.reduce(
      (acc, p) => ({
        price: acc.price + p.price,
        priceHt: acc.priceHt + p.priceHt,
        quantity: acc.quantity + p.quantity,
      }),
      { price: 0, priceHt: 0, quantity: 0 }
    );
  }, [purchasesForMonth]);

  function shiftHistoryMonth(delta: number) {
    const [y, m] = historyMonth.split('-').map(Number);
    const d = new Date(Date.UTC(y, m - 1 + delta, 1));
    setHistoryMonth(d.toISOString().slice(0, 7));
  }

  const historyMonthLabel = useMemo(() => {
    const [y, m] = historyMonth.split('-').map(Number);
    const d = new Date(Date.UTC(y, m - 1, 1));
    return d.toLocaleDateString(locale, { month: 'long', year: 'numeric', timeZone: 'UTC' });
  }, [historyMonth, locale]);

  const defaultUnitWeightG = useMemo(() => {
    const unit = currentIngredient?.purchaseUnit;
    if (!unit) return null;
    const last = purchases.find((p) => p.unit === unit && p.unitWeightG);
    return last?.unitWeightG ?? (unit === 'unite' ? currentIngredient?.avgPieceWeightG ?? null : null);
  }, [purchases, currentIngredient]);
  const newUnitWeightG = asksUnitWeight(purchaseUnit) ? parseWeight(unitWeight) : null;
  // L'ingrédient est déjà utilisé au gramme dans des recettes : le poids d'une unité à compter
  // devient obligatoire pour ne pas fausser leur coût.
  const usedInGrams = usedInRecipes.some((r) => r.unit === 'g' || r.unit === 'ml');

  const computedUnitPrice = useMemo(() => {
    const price = parseFloat(purchasePrice.replace(',', '.'));
    const qty = parseFloat(purchaseQuantity.replace(',', '.'));
    if (!price || !qty) return null;
    return computeUnitPrice(priceExcludingVat(price, vatRate), qty, purchaseUnit, newUnitWeightG);
  }, [purchasePrice, purchaseQuantity, purchaseUnit, vatRate, newUnitWeightG]);

  const canSave = ingredientId
    ? name.trim().length > 0
    : name.trim().length > 0 &&
      parseFloat(purchasePrice.replace(',', '.')) > 0 &&
      parseFloat(purchaseQuantity.replace(',', '.')) > 0;

  async function handleSave() {
    if (savingRef.current) return; // double appui = un seul enregistrement
    if (!guard()) return;
    savingRef.current = true;
    setSaving(true);
    try {
      await saveIngredient();
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  }

  async function saveIngredient() {
    if (ingredientId) {
      // Price fields aren't editable here anymore once purchases exist, so
      // only name/category can change through this button.
      await updateIngredientDetails(db, ingredientId, { name: name.trim(), categoryId, vatRate });
      navigation.goBack();
      return;
    }
    const input = {
      name: name.trim(),
      purchasePrice: parseFloat(purchasePrice.replace(',', '.')),
      purchaseQuantity: parseFloat(purchaseQuantity.replace(',', '.')),
      purchaseUnit,
      vatRate,
      categoryId,
      avgPieceWeightG: newUnitWeightG,
    };
    // Prix de renseignement seulement : aucun achat n'est enregistré, la Caisse ne bouge pas.
    await createIngredient(db, input);
    navigation.goBack();
  }

  async function handlePurchaseSubmit(data: {
    supplierId: string;
    purchaseDate: string;
    price: number;
    quantity: number;
    unit: PurchaseUnit;
    note: string | null;
    vatRate: number;
    unitWeightG: number | null;
  }) {
    if (!ingredientId) return;
    // Pas de garde d'essai ici : un achat est une écriture de la Caisse, qui reste utilisable.
    if (!(await confirmPurchaseUnit(db, ingredientId, data.unit, data.unitWeightG, t))) return;
    setPurchaseModalVisible(false);
    if (editingPurchase) {
      await updatePurchase(db, editingPurchase.id, data);
      setEditingPurchase(null);
    } else {
      await recordPurchase(db, { ingredientId, ...data });
    }
    await loadPriceData();
  }

  function handleEditPurchase(purchase: IngredientPurchase) {
    setEditingPurchase(purchase);
    setPurchaseModalVisible(true);
  }

  // Corrige le prix directement (sans créer d'achat) — utile quand tu sais qu'un prix a
  // changé avant même d'avoir racheté. Le prochain achat réel enregistré reprendra le dessus
  // normalement (resyncIngredientCurrentPrice se base sur les achats, pas sur cette correction).
  async function handlePriceCorrection(data: {
    price: number;
    quantity: number;
    unit: PurchaseUnit;
    unitWeightG: number | null;
    vatRate: number;
  }) {
    if (!guard()) return;
    if (!ingredientId || !currentIngredient) return;
    if (!(await confirmPurchaseUnit(db, ingredientId, data.unit, data.unitWeightG, t))) return;
    setPriceCorrectionVisible(false);
    setVatRate(data.vatRate);
    await updateIngredient(db, ingredientId, {
      name: name.trim(),
      purchasePrice: data.price,
      purchaseQuantity: data.quantity,
      purchaseUnit: data.unit,
      vatRate: data.vatRate,
      categoryId,
      avgPieceWeightG: data.unitWeightG,
    });
    await loadPriceData();
  }

  function handleDeletePurchase(purchase: IngredientPurchase) {
    Alert.alert(t('Supprimer cet achat ?'), t('Cette action est irréversible.'), [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: async () => {
          await deletePurchase(db, purchase.id);
          await loadPriceData();
        },
      },
    ]);
  }

  // La recette s'ouvre dans l'onglet « Mes recettes » (retour = liste des catégories).
  function openRecipe(r: RecipeUsingIngredient) {
    navigation.getParent()?.navigate('CategoriesTab', {
      screen: 'RecipeForm',
      params: { recipeId: r.recipeId, categoryId: r.categoryId, categoryName: r.categoryName },
      initial: false,
    } as never);
  }

  async function handleCreateCategory(categoryName: string) {
    setAddCategoryVisible(false);
    const id = await createIngredientCategory(db, categoryName);
    setCategories(await listIngredientCategories(db));
    setCategoryId(id);
  }

  async function handleRenameCategory(newName: string) {
    if (!editingCategory) return;
    setEditingCategory(null);
    await updateIngredientCategory(db, editingCategory.id, newName);
    setCategories(await listIngredientCategories(db));
  }

  function handleLongPressCategory(cat: IngredientCategory) {
    Alert.alert(cat.name, undefined, [
      { text: t('Renommer'), onPress: () => setEditingCategory(cat) },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: () => {
          Alert.alert(
            t('Supprimer cette catégorie ?'),
            t('Les ingrédients qui l\'utilisent perdront simplement ce repère couleur, ils ne seront pas supprimés.'),
            [
              { text: t('Annuler'), style: 'cancel' },
              {
                text: t('Supprimer'),
                style: 'destructive',
                onPress: async () => {
                  await deleteIngredientCategory(db, cat.id);
                  if (categoryId === cat.id) setCategoryId(null);
                  setCategories(await listIngredientCategories(db));
                },
              },
            ]
          );
        },
      },
      { text: t('Annuler'), style: 'cancel' },
    ]);
  }

  function handleDelete() {
    if (!ingredientId) return;
    Alert.alert(
      t('Supprimer cet ingrédient ?'),
      purchases.length > 0
        ? t('Ses {count} achat(s) restent dans la Caisse : tes dépenses et ton solde ne changent pas.', {
            count: purchases.length,
          })
        : t('Cette action est irréversible.'),
      [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteIngredient(db, ingredientId);
            navigation.goBack();
          } catch (e) {
            if (e instanceof IngredientInUseError) {
              Alert.alert(t('Impossible'), t(e.message));
            }
          }
        },
      },
      ]
    );
  }

  // Un prix peut être connu sans achat enregistré (prix saisi à la création, ou corrigé à la main).
  const priceKnown = purchases.length > 0 || (currentIngredient?.unitPrice ?? 0) > 0;

  if (!loaded) return <ScreenContainer />;

  return (
    <ScreenContainer>
      <GradientHeaderBand title={name || t('Ingrédient')} onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <KeyboardAwareScrollView contentContainerStyle={styles.content}>
        <FieldLabel>{t("Nom de l'ingrédient")}</FieldLabel>
        <TextInput style={inputStyles.input} value={name} onChangeText={setName} placeholder={t('ex: Beurre')} />

        {!ingredientId && (
          <>
            <FieldLabel>{t('Prix payé ({currency})', { currency: getCurrencySymbol() })}</FieldLabel>
            <TextInput
              style={inputStyles.input}
              value={purchasePrice}
              onChangeText={setPurchasePrice}
              keyboardType="decimal-pad"
              placeholder={t('ex: 45')}
            />

            <FieldLabel>{t('Quantité correspondante')}</FieldLabel>
            <TextInput
              style={inputStyles.input}
              value={purchaseQuantity}
              onChangeText={setPurchaseQuantity}
              keyboardType="decimal-pad"
              placeholder={t('ex: 500')}
            />

            <FieldLabel>{t('Unité')}</FieldLabel>
            <PurchaseUnitPicker value={purchaseUnit} onChange={setPurchaseUnit} />
            <UnitWeightField unit={purchaseUnit} value={unitWeight} onChange={setUnitWeight} />

            <FieldLabel>{t('Taux de TVA')}</FieldLabel>
            <View style={styles.unitRow}>
              {VAT_RATES.map((rate) => (
                <Pressable
                  key={rate}
                  onPress={() => setVatRate(rate)}
                  style={[styles.unitBtn, vatRate === rate && { backgroundColor: accent, borderColor: accent }]}
                >
                  <Text style={[styles.unitBtnText, vatRate === rate && styles.unitBtnTextActive]}>{rate}%</Text>
                </Pressable>
              ))}
            </View>

            {computedUnitPrice !== null && (
              <View style={styles.computedBox}>
                <Text style={[styles.computedText, { color: accentDark }]}>
                  {t('Prix ramené (HT) : {price} {currency}/{unit}', {
                    price: computedUnitPrice.toLocaleString('fr-FR', { maximumFractionDigits: 4 }),
                    currency: getCurrencySymbol(),
                    unit: unitLabel(baseUnitForPurchaseUnit(purchaseUnit, newUnitWeightG), t),
                  })}
                </Text>
              </View>
            )}

            <Text style={styles.computedText}>
              {t("Ce prix sert juste d'information : rien n'est ajouté à la caisse. Tu enregistres un achat quand tu achètes vraiment.")}
            </Text>
          </>
        )}

        {ingredientId && currentIngredient && (
          <>
            <View style={styles.computedBox}>
              <Text style={[styles.computedText, { color: accentDark }]}>
                {!priceKnown
                  ? t("Prix pas encore connu.")
                  : t('Prix actuel (HT) : {price} {currency}/{unit}', {
                      price: currentIngredient.unitPrice.toLocaleString('fr-FR', { maximumFractionDigits: 4 }),
                      currency: getCurrencySymbol(),
                      unit: unitLabel(currentIngredient.baseUnit, t),
                    })}
              </Text>
              <Pressable onPress={() => setPriceCorrectionVisible(true)} hitSlop={8} style={{ marginTop: spacing.xs }}>
                <Text style={[styles.correctPriceLink, { color: accentDark }]}>
                  {!priceKnown ? t('Indiquer un prix connu') : t('Corriger le prix')}
                </Text>
              </Pressable>
              {!priceKnown && (
                <Text style={styles.hint}>
                  {t("Utile si tu connais déjà le prix sans avoir encore acheté — enregistrer un vrai achat plus tard le remplacera.")}
                </Text>
              )}
            </View>

            <View style={styles.usedInBox}>
              <Pressable
                style={styles.usedInHeader}
                onPress={() => setShowUsedIn((v) => !v)}
                disabled={usedInRecipes.length === 0}
              >
                <Ionicons name="book-outline" size={18} color={accentDark} />
                <Text style={[styles.usedInTitle, { color: accentDark }]}>
                  {usedInRecipes.length === 0
                    ? t('Utilisé dans aucune recette')
                    : t('Utilisé dans {count} recette(s)', {
                        count: new Set(usedInRecipes.map((r) => r.recipeId)).size,
                      })}
                </Text>
                {usedInRecipes.length > 0 && (
                  <Ionicons name={showUsedIn ? 'chevron-up' : 'chevron-down'} size={18} color={accentDark} />
                )}
              </Pressable>
              {showUsedIn &&
                usedInRecipes.map((r) => (
                  <Pressable key={`${r.recipeId}-${r.unit}`} style={styles.usedInRow} onPress={() => openRecipe(r)}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.usedInName}>{r.recipeName}</Text>
                      <Text style={styles.usedInSub}>{r.categoryName}</Text>
                    </View>
                    <Text style={styles.usedInQty}>
                      {formatQuantity(r.quantity)} {unitLabel(r.unit, t)}
                    </Text>
                    <Ionicons name="chevron-forward" size={16} color={colors.textMuted} />
                  </Pressable>
                ))}
            </View>

            <FieldLabel>{t('Taux de TVA')}</FieldLabel>
            <Text style={styles.hint}>
              {t("S'applique aux prochains achats — l'historique déjà enregistré ne change pas.")}
            </Text>
            <View style={styles.unitRow}>
              {VAT_RATES.map((rate) => (
                <Pressable
                  key={rate}
                  onPress={async () => {
                    setVatRate(rate);
                    if (!ingredientId) return;
                    // Le nouveau taux ne vaut que pour les prochains achats : le prix actuel ne bouge pas.
                    await updateIngredientVatRate(db, ingredientId, rate);
                    await loadPriceData();
                  }}
                  style={[styles.unitBtn, vatRate === rate && { backgroundColor: accent, borderColor: accent }]}
                >
                  <Text style={[styles.unitBtnText, vatRate === rate && styles.unitBtnTextActive]}>{rate}%</Text>
                </Pressable>
              ))}
            </View>

            {comparison.length > 0 && (
              <SectionCard title={t('Comparaison fournisseurs (HT)')}>
                {comparison.map((row) => (
                  <View key={row.supplierId} style={styles.comparisonRow}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
                      {row.isCheapest && <Ionicons name="star" size={14} color={colors.success} style={{ marginRight: 4 }} />}
                      <Text style={styles.comparisonSupplier}>{row.supplierName}</Text>
                    </View>
                    <Text style={[styles.comparisonPrice, row.isCheapest && { color: colors.success }]}>
                      {row.unitPrice.toLocaleString('fr-FR', { maximumFractionDigits: 4 })} {getCurrencySymbol()}/
                      {unitLabel(currentIngredient.baseUnit, t)}
                    </Text>
                  </View>
                ))}
              </SectionCard>
            )}

            <SectionCard title={t('Historique des achats')}>
              <View style={styles.monthNavRow}>
                <Pressable onPress={() => shiftHistoryMonth(-1)} hitSlop={8} style={styles.monthNavBtn}>
                  <Ionicons name="chevron-back" size={18} color={accentDark} />
                </Pressable>
                <Text style={styles.monthNavLabel}>{historyMonthLabel}</Text>
                <Pressable onPress={() => shiftHistoryMonth(1)} hitSlop={8} style={styles.monthNavBtn}>
                  <Ionicons name="chevron-forward" size={18} color={accentDark} />
                </Pressable>
              </View>

              {purchasesForMonth.length > 0 && (
                <View style={styles.monthTotalBox}>
                  <Text style={[styles.monthTotalText, { color: accentDark }]}>
                    {t(
                      // Sans TVA (achat au marché sans facture, taux à 0%), TTC et HT sont le même
                      // nombre — les afficher tous les deux ("30 DH TTC (30 DH HT)") est confusant,
                      // on n'affiche alors qu'un seul prix.
                      Math.abs(monthTotals.price - monthTotals.priceHt) < 0.005
                        ? monthUnit
                          ? 'Total du mois : {price} pour {qty} {unit}'
                          : 'Total du mois : {price}'
                        : monthUnit
                          ? 'Total du mois : {price} TTC ({priceHt} HT) pour {qty} {unit}'
                          : 'Total du mois : {price} TTC ({priceHt} HT)',
                      {
                        price: formatMoney(monthTotals.price),
                        priceHt: formatMoney(monthTotals.priceHt),
                        qty: formatQuantity(monthTotals.quantity),
                        unit: monthUnit ? purchaseUnitLabel(monthUnit, t) : '',
                      }
                    )}
                  </Text>
                </View>
              )}

              {purchases.length === 0 ? (
                <Text style={styles.emptyHistoryText}>{t("Aucun achat enregistré pour l'instant.")}</Text>
              ) : purchasesForMonth.length === 0 ? (
                <Text style={styles.emptyHistoryText}>{t('Aucun achat ce mois-ci.')}</Text>
              ) : (
                purchasesForMonth.map((p) => (
                  <Pressable key={p.id} style={styles.purchaseRow} onPress={() => handleEditPurchase(p)}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.purchaseSupplier}>
                        {p.supplierName} · {formatDate(p.purchaseDate)}
                      </Text>
                      <Text style={styles.purchaseDetail}>
                        {t(
                          Math.abs(p.price - p.priceHt) < 0.005
                            ? '{price} pour {qty} {unit}'
                            : '{price} TTC ({priceHt} HT) pour {qty} {unit}',
                          {
                            price: formatMoney(p.price),
                            priceHt: formatMoney(p.priceHt),
                            qty: p.quantity,
                            unit: purchaseUnitLabel(p.unit, t),
                          }
                        )}
                        {p.note ? ` · ${p.note}` : ''}
                      </Text>
                    </View>
                    <Pressable onPress={() => handleDeletePurchase(p)} hitSlop={8} style={{ marginLeft: spacing.sm }}>
                      <Ionicons name="close" size={16} color={colors.textMuted} />
                    </Pressable>
                  </Pressable>
                ))
              )}
              <PrimaryButton
                label={t('Enregistrer un achat')}
                variant="secondary"
                onPress={() => {
                  setEditingPurchase(null);
                  setPurchaseModalVisible(true);
                }}
                style={{ marginTop: spacing.md }}
              />
            </SectionCard>
          </>
        )}

        <FieldLabel>{t('Catégorie (repère couleur, optionnel)')}</FieldLabel>
        {categories.length > 0 && (
          <Text style={styles.hint}>{t('Appui long sur une catégorie pour la renommer ou la supprimer.')}</Text>
        )}
        <View style={styles.chipWrap}>
          <Pressable
            onPress={() => setCategoryId(null)}
            style={[styles.chip, { borderColor: colors.border }, categoryId === null && styles.chipNoneActive]}
          >
            <Text style={[styles.chipText, { color: categoryId === null ? colors.text : colors.textMuted }]}>
              {t('Aucune')}
            </Text>
          </Pressable>
          {categories.map((cat) => {
            const active = categoryId === cat.id;
            return (
              <Pressable
                key={cat.id}
                onPress={() => setCategoryId(cat.id)}
                onLongPress={() => handleLongPressCategory(cat)}
                style={[styles.chip, { borderColor: cat.color }, active && { backgroundColor: cat.color }]}
              >
                <Text style={[styles.chipText, { color: active ? '#fff' : cat.color }]}>{cat.name}</Text>
              </Pressable>
            );
          })}
          <Pressable style={styles.addChip} onPress={() => setAddCategoryVisible(true)}>
            <Ionicons name="add" size={16} color={colors.textMuted} />
            <Text style={styles.addChipText}>{t('Nouvelle catégorie')}</Text>
          </Pressable>
        </View>

        <PrimaryButton label={t('Enregistrer')} onPress={handleSave} disabled={!canSave || saving} style={styles.saveBtn} />
        {ingredientId && (
          <PrimaryButton
            label={t("Supprimer l'ingrédient")}
            variant="danger"
            onPress={handleDelete}
            style={styles.saveBtn}
          />
        )}
      </KeyboardAwareScrollView>
      </KeyboardAvoidingView>

      <PromptModal
        visible={addCategoryVisible}
        title={t("Nouvelle catégorie d'ingrédients")}
        placeholder={t('ex: Frais, Sec, Fruits secs')}
        onSubmit={handleCreateCategory}
        onCancel={() => setAddCategoryVisible(false)}
      />
      <PromptModal
        visible={!!editingCategory}
        title={t('Renommer la catégorie')}
        initialValue={editingCategory?.name}
        onSubmit={handleRenameCategory}
        onCancel={() => setEditingCategory(null)}
      />
      <PurchaseFormModal
        visible={purchaseModalVisible}
        suppliers={suppliers}
        onSuppliersChanged={setSuppliers}
        editingPurchase={
          editingPurchase
            ? {
                supplierId: editingPurchase.supplierId,
                purchaseDate: editingPurchase.purchaseDate,
                price: editingPurchase.price,
                quantity: editingPurchase.quantity,
                unit: editingPurchase.unit,
                note: editingPurchase.note,
                vatRate: editingPurchase.vatRate,
                unitWeightG: editingPurchase.unitWeightG,
              }
            : undefined
        }
        defaultVatRate={vatRate}
        defaultUnit={currentIngredient?.purchaseUnit ?? 'kg'}
        defaultUnitWeightG={defaultUnitWeightG}
        requireWeight={usedInGrams}
        onSubmit={handlePurchaseSubmit}
        onCancel={() => {
          setPurchaseModalVisible(false);
          setEditingPurchase(null);
        }}
      />
      {currentIngredient && (
        <PriceCorrectionModal
          visible={priceCorrectionVisible}
          initialPrice={currentIngredient.purchasePrice}
          initialQuantity={currentIngredient.purchaseQuantity}
          initialUnit={currentIngredient.purchaseUnit}
          initialUnitWeightG={defaultUnitWeightG}
          initialVatRate={purchases[0]?.vatRate ?? vatRate}
          requireWeight={usedInGrams}
          onSubmit={handlePriceCorrection}
          onCancel={() => setPriceCorrectionVisible(false)}
        />
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  usedInBox: {
    marginTop: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
  },
  usedInHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  usedInTitle: {
    flex: 1,
    fontSize: 15,
    fontWeight: '700',
  },
  usedInRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  usedInName: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.text,
  },
  usedInSub: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 1,
  },
  usedInQty: {
    fontSize: 14,
    color: colors.text,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xl,
  },
  unitRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  unitBtn: {
    flex: 1,
    paddingVertical: spacing.sm + 2,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  unitBtnText: {
    color: colors.text,
    fontWeight: '600',
  },
  unitBtnTextActive: {
    color: '#fff',
  },
  computedBox: {
    marginTop: spacing.md,
    marginBottom: spacing.md,
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.sm,
    padding: spacing.md,
  },
  computedText: {
    fontWeight: '700',
    textAlign: 'center',
  },
  correctPriceLink: {
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
  comparisonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.xs + 2,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  comparisonSupplier: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '600',
  },
  comparisonPrice: {
    fontSize: 13,
    color: colors.textMuted,
    fontWeight: '700',
  },
  emptyHistoryText: {
    fontSize: 13,
    color: colors.textMuted,
    fontStyle: 'italic',
  },
  monthNavRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  monthNavBtn: {
    padding: spacing.xs,
  },
  monthNavLabel: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
    marginHorizontal: spacing.md,
    textTransform: 'capitalize',
  },
  monthTotalBox: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.sm,
    padding: spacing.sm,
    marginBottom: spacing.sm,
  },
  monthTotalText: {
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'center',
  },
  purchaseRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  purchaseSupplier: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '600',
  },
  purchaseDetail: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  hint: {
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: spacing.xs,
  },
  chipWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  chip: {
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
  },
  chipNoneActive: {
    backgroundColor: colors.surfaceAlt,
  },
  chipText: {
    fontSize: 13,
    fontWeight: '700',
  },
  addChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderStyle: 'dashed',
    marginBottom: spacing.xs,
  },
  addChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textMuted,
    marginLeft: 2,
  },
  saveBtn: {
    marginTop: spacing.lg,
  },
});
