import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, FlatList, Pressable, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import PrimaryButton from '../../components/common/PrimaryButton';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { useEditGuard } from '../../access/AccessContext';
import { inputStyles } from '../../theme/inputStyle';
import { createIngredient, listIngredients } from '../../db/repositories/ingredientsRepo';
import { formatMoney } from '../../utils/format';
import { normalizeSearch } from '../../utils/normalize';
import {
  IngredientImportCandidate,
  IngredientImportParseError,
  parseIngredientImportFile,
  pickIngredientImportFile,
} from '../../backup/ingredientImport';

interface RowState extends IngredientImportCandidate {
  included: boolean;
  alreadyExists: boolean;
}

export default function ImportIngredientsScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation();
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();
  const guard = useEditGuard();
  const [rows, setRows] = useState<RowState[] | null>(null);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);

  async function handlePickFile() {
    setLoading(true);
    try {
      const content = await pickIngredientImportFile();
      if (!content) {
        setLoading(false);
        return;
      }
      const file = parseIngredientImportFile(content);
      const existing = await listIngredients(db);
      const existingNames = new Set(existing.map((i) => normalizeSearch(i.name)));
      setRows(
        file.items.map((item) => {
          const alreadyExists = existingNames.has(normalizeSearch(item.name));
          return { ...item, included: item.suggestedInclude && !alreadyExists, alreadyExists };
        })
      );
    } catch (e) {
      Alert.alert(t('Erreur'), e instanceof IngredientImportParseError ? t(e.message) : t('Ce fichier ne peut pas être lu.'));
    } finally {
      setLoading(false);
    }
  }

  const filtered = useMemo(() => {
    if (!rows) return [];
    if (!search.trim()) return rows;
    const q = normalizeSearch(search);
    return rows.filter((r) => normalizeSearch(r.name).includes(q));
  }, [rows, search]);

  const selectedCount = rows?.filter((r) => r.included).length ?? 0;

  function toggleRow(name: string) {
    setRows((prev) => prev?.map((r) => (r.name === name ? { ...r, included: !r.included } : r)) ?? null);
  }

  async function handleImport() {
    if (!guard()) return;
    if (!rows) return;
    if (importing) return; // double appui = un seul import
    setImporting(true);
    const toImport = rows.filter((r) => r.included && !r.alreadyExists);
    try {
      for (const item of toImport) {
        await createIngredient(db, {
          name: item.name,
          purchasePrice: item.lastPrice,
          purchaseQuantity: 1,
          purchaseUnit: 'unite',
          vatRate: 0,
          categoryId: null,
        });
      }
    } finally {
      setImporting(false);
    }
    Alert.alert(
      t('Import terminé'),
      t(
        '{count} ingrédient(s) importé(s) avec le dernier prix payé. Va dans chacun pour corriger la quantité (kg/g/unité), le prix affiché est pour l\'instant "par unité".',
        { count: toImport.length }
      ),
      [{ text: t('OK'), onPress: () => navigation.goBack() }]
    );
  }

  if (!rows) {
    return (
      <ScreenContainer>
        <GradientHeaderBand title={t('Importer des ingrédients')} onBack={() => navigation.goBack()} />
        <View style={styles.emptyState}>
          <Ionicons name="download-outline" size={40} color={colors.textMuted} />
          <Text style={styles.emptyTitle}>{t('Importer des ingrédients')}</Text>
          <Text style={styles.emptyText}>
            {t(
              "Choisis un fichier d'import JSON (généré à partir de ton historique d'achats, par exemple). Tu pourras vérifier et décocher les lignes avant de les ajouter à ta base."
            )}
          </Text>
          <PrimaryButton
            label={t('Choisir le fichier')}
            onPress={handlePickFile}
            loading={loading}
            style={{ marginTop: spacing.lg }}
          />
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <GradientHeaderBand title={t('Importer des ingrédients')} onBack={() => navigation.goBack()} />
      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          placeholder={t('Filtrer...')}
          placeholderTextColor={colors.textMuted}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.name}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <Pressable
            style={[styles.row, item.alreadyExists && styles.rowDisabled]}
            onPress={() => !item.alreadyExists && toggleRow(item.name)}
            disabled={item.alreadyExists}
          >
            <Ionicons
              name={item.included ? 'checkbox' : 'square-outline'}
              size={22}
              color={item.alreadyExists ? colors.textMuted : accent}
            />
            <View style={{ flex: 1, marginLeft: spacing.sm }}>
              <Text style={styles.name}>{item.name}</Text>
              {item.alreadyExists ? (
                <Text style={styles.existsText}>{t('Déjà dans ta base — ignoré')}</Text>
              ) : item.hint ? (
                <Text style={styles.hint}>{item.hint}</Text>
              ) : null}
            </View>
            <Text style={[styles.price, { color: accentDark }]}>{formatMoney(item.lastPrice)}</Text>
          </Pressable>
        )}
      />

      <View style={styles.footer}>
        <PrimaryButton
          label={t('Importer ({count})', { count: selectedCount })}
          onPress={handleImport}
          disabled={selectedCount === 0}
          loading={importing}
        />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginTop: spacing.sm,
  },
  emptyText: {
    fontSize: 13,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: spacing.xs,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  searchInput: {
    flex: 1,
    paddingVertical: spacing.sm + 4,
    fontSize: 16,
    color: colors.text,
  },
  listContent: {
    padding: spacing.md,
    paddingBottom: 100,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rowDisabled: {
    opacity: 0.5,
  },
  name: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.text,
  },
  hint: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  existsText: {
    fontSize: 12,
    color: colors.textMuted,
    fontStyle: 'italic',
    marginTop: 2,
  },
  price: {
    fontSize: 14,
    fontWeight: '700',
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
});
