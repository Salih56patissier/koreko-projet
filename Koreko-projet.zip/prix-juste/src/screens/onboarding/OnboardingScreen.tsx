import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import ScreenContainer from '../../components/common/ScreenContainer';
import PrimaryButton from '../../components/common/PrimaryButton';
import { colors, spacing } from '../../theme/colors';
import { useI18n } from '../../i18n/I18nContext';

// Mêmes couleurs que la barre d'onglets/le bandeau (voir MainTabs.tsx, GradientHeaderBand.tsx) —
// orange pour tout ce qui touche aux ingrédients/recettes, turquoise pour l'argent (courses,
// caisse), pour que ce petit tuto se sente comme un prolongement naturel de l'appli.
const KOREKO_ORANGE = '#e8792a';
const KOREKO_TEAL = '#17a3a8';

interface Props {
  // Présent = premier lancement (pas encore dans la navigation) : on marque le tuto comme vu et
  // on referme. Absent = ouvert depuis Réglages ("Revoir le tutoriel") : un simple retour suffit.
  onDone?: () => void;
}

export default function OnboardingScreen({ onDone }: Props) {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const { t } = useI18n();

  function handleDone() {
    if (onDone) onDone();
    else navigation.goBack();
  }

  const steps: { icon: keyof typeof Ionicons.glyphMap; color: string; title: string; text: string }[] = [
    {
      icon: 'basket-outline',
      color: KOREKO_ORANGE,
      title: t('Ingrédients'),
      text: t("Note le prix que tu as réellement payé pour chaque ingrédient. L'appli calcule tout seul le coût au gramme."),
    },
    {
      icon: 'book-outline',
      color: KOREKO_ORANGE,
      title: t('Mes recettes'),
      text: t('Construis chaque recette étape par étape (ex: Mélanger, Cuire) en y mettant les ingrédients. Le prix juste se calcule automatiquement.'),
    },
    {
      icon: 'cart-outline',
      color: KOREKO_TEAL,
      title: t('Courses'),
      text: t('Ajoute ce qui te manque, rangé par fournisseur, avec le prix estimé pour ta prochaine tournée.'),
    },
    {
      icon: 'wallet-outline',
      color: KOREKO_TEAL,
      title: t('Caisse'),
      text: t('Suis tes dépenses et tes ventes, et vois ton solde du mois en un coup d\'œil.'),
    },
  ];

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + spacing.xl }]}>
        <Text style={styles.title}>{t('Bienvenue sur Koreko')}</Text>
        <Text style={styles.subtitle}>{t('4 écrans, 4 usages — voici comment ça marche.')}</Text>

        {steps.map((step, index) => (
          <View key={index} style={styles.stepRow}>
            <View style={[styles.iconCircle, { backgroundColor: step.color }]}>
              <Ionicons name={step.icon} size={26} color="#fff" />
            </View>
            <View style={styles.stepTextCol}>
              <Text style={styles.stepTitle}>{step.title}</Text>
              <Text style={styles.stepText}>{step.text}</Text>
            </View>
          </View>
        ))}

        <PrimaryButton label={t("Compris, c'est parti !")} onPress={handleDone} style={styles.doneBtn} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xl,
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    color: colors.text,
    textAlign: 'center',
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textMuted,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  stepRow: {
    flexDirection: 'row',
    marginBottom: spacing.lg,
  },
  iconCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
    flexShrink: 0,
  },
  stepTextCol: {
    flex: 1,
    justifyContent: 'center',
  },
  stepTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 2,
  },
  stepText: {
    fontSize: 13.5,
    lineHeight: 19,
    color: colors.textMuted,
  },
  doneBtn: {
    marginTop: spacing.md,
  },
});
