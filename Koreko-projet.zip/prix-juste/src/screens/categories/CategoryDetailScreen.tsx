import React, { useCallback, useState } from 'react';
import { View, Text, Image, Pressable, StyleSheet } from 'react-native';
import { photoFileExists } from '../../utils/photo';
import { useFocusEffect, useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import PromptModal from '../../components/common/PromptModal';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { useEditGuard } from '../../access/AccessContext';
import { RecipeSummary } from '../../types/models';
import { createRecipe, listRecipeSummariesByCategory, reorderRecipes } from '../../db/repositories/recipesRepo';
import ReorderModal from '../../components/common/ReorderModal';
import DraggableFlatList, { RenderItemParams, ScaleDecorator } from 'react-native-draggable-flatlist';
import { getSettings } from '../../db/repositories/settingsRepo';
import { formatMoney } from '../../utils/format';
import { CategoriesStackParamList } from '../../navigation/types';

type Nav = NativeStackNavigationProp<CategoriesStackParamList, 'CategoryDetail'>;
type Route = RouteProp<CategoriesStackParamList, 'CategoryDetail'>;

export default function CategoryDetailScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation<Nav>();
  const route = useRoute<Route>();
  const { categoryId, categoryName } = route.params;
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();
  const guard = useEditGuard();
  const [recipes, setRecipes] = useState<RecipeSummary[]>([]);
  const [addVisible, setAddVisible] = useState(false);
  const [reorderVisible, setReorderVisible] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setRecipes(await listRecipeSummariesByCategory(db, categoryId));
      setLoadError(null);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : String(e));
    }
  }, [db, categoryId]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  async function handleAdd(name: string) {
    setAddVisible(false);
    const settings = await getSettings(db);
    const id = await createRecipe(db, categoryId, name, settings.defaultHourlyRate);
    navigation.navigate('RecipeForm', { recipeId: id, categoryId, categoryName });
  }

  return (
    <ScreenContainer>
      <GradientHeaderBand
        title={categoryName}
        onBack={() => navigation.goBack()}
        right={
          recipes.length > 1 ? (
            <Pressable onPress={() => setReorderVisible(true)} hitSlop={8} accessibilityLabel={t('Réorganiser')}>
              <Ionicons name="swap-vertical" size={26} color="#fff" />
            </Pressable>
          ) : undefined
        }
      />
      <DraggableFlatList
        data={recipes}
        keyExtractor={(item) => item.id}
        containerStyle={{ flex: 1 }}
        activationDistance={8}
        onDragEnd={async ({ data }) => {
          setRecipes(data);
          await reorderRecipes(db, data.map((r) => r.id));
        }}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            {loadError
              ? t('Erreur de chargement : {error}', { error: loadError })
              : t("Aucune recette dans cette catégorie pour l'instant.")}
          </Text>
        }
        renderItem={({ item, drag, isActive }: RenderItemParams<RecipeSummary>) => (
          <ScaleDecorator activeScale={1.03}>
          <Pressable
            style={[styles.row, isActive && { borderColor: accent, backgroundColor: colors.surfaceAlt }]}
            onPress={() => navigation.navigate('RecipeForm', { recipeId: item.id, categoryId, categoryName })}
            disabled={isActive}
          >
            {/* Poignée : appui court puis glisser pour monter ou descendre la recette. */}
            <Pressable onLongPress={drag} delayLongPress={120} disabled={isActive} hitSlop={10} style={styles.dragHandle}>
              <Ionicons name="reorder-three" size={28} color={isActive ? accent : colors.textMuted} />
            </Pressable>
            {photoFileExists(item.photoUri) ? (
              <Image source={{ uri: item.photoUri }} style={styles.thumbnail} />
            ) : (
              <View style={styles.thumbnailPlaceholder}>
                <Ionicons name="image-outline" size={20} color={colors.textMuted} />
              </View>
            )}
            {/* Prix sous le nom : avec la poignée et la photo, le nom garde toute la largeur. */}
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={[styles.price, { color: accentDark }]}>{formatMoney(item.fairPrice)}</Text>
            </View>
          </Pressable>
          </ScaleDecorator>
        )}
      />

      <Pressable style={[styles.fab, { backgroundColor: accent }]} onPress={() => guard() && setAddVisible(true)}>
        <Ionicons name="add" size={22} color="#fff" />
        <Text style={styles.fabLabel}>{t('Nouvelle recette')}</Text>
      </Pressable>

      <ReorderModal
        visible={reorderVisible}
        title={t('Ranger les recettes')}
        entries={recipes.map((r) => ({ id: r.id, label: r.name }))}
        onCancel={() => setReorderVisible(false)}
        onDone={async (ids) => {
          setReorderVisible(false);
          await reorderRecipes(db, ids);
          load();
        }}
      />
      <PromptModal
        visible={addVisible}
        title={t('Nouvelle recette')}
        placeholder={t('ex: Fraisier')}
        onSubmit={handleAdd}
        onCancel={() => setAddVisible(false)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  dragHandle: {
    paddingRight: spacing.sm,
    marginLeft: -spacing.xs,
  },
  listContent: {
    padding: spacing.md,
    paddingBottom: 100,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  thumbnail: {
    width: 44,
    height: 44,
    borderRadius: radius.sm,
    marginRight: spacing.sm,
  },
  thumbnailPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: radius.sm,
    marginRight: spacing.sm,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  price: {
    fontSize: 15,
    fontWeight: '700',
    marginTop: 2,
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginTop: spacing.xl,
    fontSize: 15,
  },
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.lg,
    height: 56,
    borderRadius: 28,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  fabLabel: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 15,
  },
});
