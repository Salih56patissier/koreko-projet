import React, { useCallback, useMemo, useState } from 'react';
import { View, Text, TextInput, FlatList, Pressable, StyleSheet, Alert } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import HintBanner from '../../components/common/HintBanner';
import PromptModal from '../../components/common/PromptModal';
import SettingsHeaderButton from '../../navigation/SettingsHeaderButton';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { CategoryWithCount } from '../../types/models';
import {
  createCategory,
  deleteCategory,
  listCategories,
  reorderCategories,
  updateCategory,
} from '../../db/repositories/categoriesRepo';
import ReorderModal from '../../components/common/ReorderModal';
import DraggableFlatList, { RenderItemParams, ScaleDecorator } from 'react-native-draggable-flatlist';
import { CategoriesStackParamList } from '../../navigation/types';
import { listRecipesForSearch, RecipeSearchEntry } from '../../db/repositories/recipesRepo';
import { fuzzyMatchScore } from '../../utils/normalize';

type Nav = NativeStackNavigationProp<CategoriesStackParamList, 'CategoriesList'>;

export default function CategoriesListScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation<Nav>();
  const { accent } = useTheme();
  const { t } = useI18n();
  const [categories, setCategories] = useState<CategoryWithCount[]>([]);
  const [addVisible, setAddVisible] = useState(false);
  const [editing, setEditing] = useState<CategoryWithCount | null>(null);
  const [search, setSearch] = useState('');
  const [reorderVisible, setReorderVisible] = useState(false);
  const [allRecipes, setAllRecipes] = useState<RecipeSearchEntry[]>([]);

  const load = useCallback(async () => {
    const [cats, recipes] = await Promise.all([listCategories(db), listRecipesForSearch(db)]);
    setCategories(cats);
    setAllRecipes(recipes);
  }, [db]);

  // Recherche souple dans toutes les recettes, toutes catégories confondues (meilleures
  // correspondances en premier).
  const searchResults = useMemo(() => {
    if (!search.trim()) return null;
    return allRecipes
      .map((r) => ({ r, score: fuzzyMatchScore(search, r.recipeName) }))
      .filter((x): x is { r: RecipeSearchEntry; score: number } => x.score !== null)
      .sort((a, b) => a.score - b.score || a.r.recipeName.localeCompare(b.r.recipeName))
      .map((x) => x.r);
  }, [search, allRecipes]);

  // Ouvre la recette là où elle est rangée : retour = sa catégorie.
  function openRecipe(r: RecipeSearchEntry) {
    navigation.navigate('CategoryDetail', { categoryId: r.categoryId, categoryName: r.categoryName });
    navigation.navigate('RecipeForm', { recipeId: r.recipeId, categoryId: r.categoryId, categoryName: r.categoryName });
  }

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  async function handleAdd(name: string) {
    setAddVisible(false);
    await createCategory(db, name);
    load();
  }

  async function handleRename(name: string) {
    if (!editing) return;
    await updateCategory(db, editing.id, name);
    setEditing(null);
    load();
  }

  function handleLongPress(cat: CategoryWithCount) {
    Alert.alert(cat.name, undefined, [
      { text: t('Renommer'), onPress: () => setEditing(cat) },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: () => {
          const warning =
            cat.recipeCount > 0
              ? t('Cette catégorie contient {count} recette(s). Elles seront supprimées aussi.', {
                  count: cat.recipeCount,
                })
              : t('Cette action est irréversible.');
          Alert.alert(t('Supprimer cette catégorie ?'), warning, [
            { text: t('Annuler'), style: 'cancel' },
            {
              text: t('Supprimer'),
              style: 'destructive',
              onPress: async () => {
                try {
                  await deleteCategory(db, cat.id);
                } catch {
                  Alert.alert(
                    t('Impossible'),
                    t("Une recette de cette catégorie est utilisée comme composant dans une autre recette : retire-la de là d'abord.")
                  );
                }
                load();
              },
            },
          ]);
        },
      },
      { text: t('Annuler'), style: 'cancel' },
    ]);
  }

  return (
    <ScreenContainer>
      <GradientHeaderBand
        title={t('Catégories')}
        right={
          <View style={styles.headerButtons}>
            {categories.length > 1 && (
              <Pressable onPress={() => setReorderVisible(true)} hitSlop={8} accessibilityLabel={t('Réorganiser')}>
                <Ionicons name="swap-vertical" size={26} color="#fff" />
              </Pressable>
            )}
            <SettingsHeaderButton />
          </View>
        }
      />
      <HintBanner
        id="categories-intro"
        text={t('Crée une catégorie (ex: Gâteaux), puis range tes recettes dedans, étape par étape.')}
      />
      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          placeholder={t('Rechercher une recette...')}
          placeholderTextColor={colors.textMuted}
          value={search}
          onChangeText={setSearch}
          autoCorrect={false}
        />
        {search.length > 0 && (
          <Pressable onPress={() => setSearch('')} hitSlop={8}>
            <Ionicons name="close-circle" size={18} color={colors.textMuted} />
          </Pressable>
        )}
      </View>
      {searchResults ? (
        <FlatList
          data={searchResults}
          keyExtractor={(item) => item.recipeId}
          contentContainerStyle={styles.listContent}
          keyboardShouldPersistTaps="handled"
          ListEmptyComponent={<Text style={styles.emptyText}>{t('Aucune recette trouvée.')}</Text>}
          renderItem={({ item }) => (
            <Pressable style={styles.row} onPress={() => openRecipe(item)}>
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{item.recipeName}</Text>
                <Text style={styles.sub}>
                  <Ionicons name="folder-outline" size={12} color={colors.textMuted} /> {item.categoryName}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
            </Pressable>
          )}
        />
      ) : (
      <DraggableFlatList
        data={categories}
        containerStyle={{ flex: 1 }}
        activationDistance={8}
        onDragEnd={async ({ data }) => {
          setCategories(data);
          await reorderCategories(db, data.map((c) => c.id));
        }}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            {t('Crée ta première catégorie (Viennoiserie, Cakes...) avec le bouton +.')}
          </Text>
        }
        renderItem={({ item, drag, isActive }: RenderItemParams<CategoryWithCount>) => (
          <ScaleDecorator activeScale={1.03}>
          <Pressable
            style={[styles.row, isActive && { borderColor: accent, backgroundColor: colors.surfaceAlt }]}
            onPress={() => navigation.navigate('CategoryDetail', { categoryId: item.id, categoryName: item.name })}
            onLongPress={() => handleLongPress(item)}
            disabled={isActive}
          >
            {/* Poignée : appui court puis glisser pour monter ou descendre la catégorie. */}
            <Pressable onLongPress={drag} delayLongPress={120} disabled={isActive} hitSlop={10} style={styles.dragHandle}>
              <Ionicons name="reorder-three" size={28} color={isActive ? accent : colors.textMuted} />
            </Pressable>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.sub}>
                {t(item.recipeCount > 1 ? '{count} recettes' : '{count} recette', { count: item.recipeCount })}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
          </Pressable>
          </ScaleDecorator>
        )}
      />
      )}

      <Pressable style={[styles.fab, { backgroundColor: accent }]} onPress={() => setAddVisible(true)}>
        <Ionicons name="add" size={30} color="#fff" />
      </Pressable>

      <ReorderModal
        visible={reorderVisible}
        title={t('Ranger les catégories')}
        entries={categories.map((c) => ({ id: c.id, label: c.name }))}
        onCancel={() => setReorderVisible(false)}
        onDone={async (ids) => {
          setReorderVisible(false);
          await reorderCategories(db, ids);
          load();
        }}
      />
      <PromptModal
        visible={addVisible}
        title={t('Nouvelle catégorie')}
        placeholder={t('ex: Layer cakes')}
        onSubmit={handleAdd}
        onCancel={() => setAddVisible(false)}
      />
      <PromptModal
        visible={!!editing}
        title={t('Renommer la catégorie')}
        initialValue={editing?.name}
        onSubmit={handleRename}
        onCancel={() => setEditing(null)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  dragHandle: {
    paddingRight: spacing.sm,
    marginLeft: -spacing.xs,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    paddingHorizontal: spacing.sm + 2,
    gap: spacing.sm,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.text,
  },
  listContent: {
    padding: spacing.md,
    paddingBottom: 100,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  name: {
    fontSize: 17,
    fontWeight: '700',
    color: colors.text,
  },
  sub: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 2,
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginTop: spacing.xl,
    fontSize: 15,
  },
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: spacing.lg,
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
});
