import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  Image,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import ReorderModal from '../../components/common/ReorderModal';
import { StackActions, useFocusEffect, useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import * as Print from 'expo-print';
import { File } from 'expo-file-system';
import * as Sharing from 'expo-sharing';

import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import HintBanner from '../../components/common/HintBanner';
import SectionCard from '../../components/common/SectionCard';
import FieldLabel from '../../components/common/FieldLabel';
import PrimaryButton from '../../components/common/PrimaryButton';
import GroupCard from '../../components/recipe/GroupCard';
import GroupFormModal from '../../components/recipe/GroupFormModal';
import IngredientPickerModal from '../../components/recipe/IngredientPickerModal';
import CategoryPickerModal from '../../components/recipe/CategoryPickerModal';
import ResultsPanel from '../../components/recipe/ResultsPanel';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { inputStyles } from '../../theme/inputStyle';
import { CategoriesStackParamList } from '../../navigation/types';
import {
  addExtraCost,
  addGroup,
  addGroupItem,
  deleteExtraCost,
  deleteGroup,
  deleteGroupItem,
  deleteRecipe,
  duplicateRecipe,
  getRecipeFull,
  listComponentCandidateRecipes,
  moveRecipeToCategory,
  reorderGroupItems,
  reorderGroups,
  setGroupProcessTags,
  updateExtraCost,
  updateGroup,
  updateGroupItem,
  updateRecipeMeta,
  type RecipeMetaInput,
  listRecipesUsingComponent,
  type RecipeUsingIngredient,
} from '../../db/repositories/recipesRepo';
import { listCategories } from '../../db/repositories/categoriesRepo';
import {
  listProcessActions,
  createCustomProcessAction,
  updateProcessAction,
  deleteProcessAction,
  ProcessActionInUseError,
} from '../../db/repositories/processActionsRepo';
import { listIngredients, setIngredientUnitWeight } from '../../db/repositories/ingredientsRepo';
import { listIngredientCategories } from '../../db/repositories/ingredientCategoriesRepo';
import {
  BaseUnit,
  CategoryWithCount,
  ComponentCandidateRecipe,
  Ingredient,
  IngredientCategory,
  ProcessAction,
  RecipeFull,
  RecipeGroupWithItems,
} from '../../types/models';
import { computeRecipeCost, totalWeightGrams } from '../../utils/priceCalc';
import { formatMoney, formatQuantity, formatWeight, getCurrencySymbol, unitLabel } from '../../utils/format';
import { generateRecipeHtml } from '../../pdf/generateRecipeHtml';
import { useAccess, useEditGuard } from '../../access/AccessContext';
import { pickAndStoreRecipePhoto, deleteRecipePhoto, duplicateRecipePhoto, photoFileExists } from '../../utils/photo';
import { useKeyboardHeight } from '../../hooks/useKeyboardHeight';

type Nav = ReturnType<typeof useNavigation>;
type Route = RouteProp<CategoriesStackParamList, 'RecipeForm'>;

export default function RecipeFormScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation();
  const route = useRoute<Route>();
  const { recipeId, categoryId, categoryName } = route.params;
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();
  const keyboardHeight = useKeyboardHeight();

  const [recipe, setRecipe] = useState<RecipeFull | null>(null);
  const [processActions, setProcessActions] = useState<ProcessAction[]>([]);
  const [allIngredients, setAllIngredients] = useState<Ingredient[]>([]);
  const [ingredientCategories, setIngredientCategories] = useState<IngredientCategory[]>([]);
  const [componentCandidates, setComponentCandidates] = useState<ComponentCandidateRecipe[]>([]);

  const [name, setName] = useState('');
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  // Saisi en minutes (plus pratique pour des étapes de 15-45 min) — converti en heures
  // uniquement à la frontière DB/calcul, la colonne recipes.labor_hours reste en heures.
  const [laborMinutes, setLaborMinutes] = useState('0');
  const [hourlyRate, setHourlyRate] = useState('0');
  const [marginPercent, setMarginPercent] = useState('0');
  const [servings, setServings] = useState('1');
  const [yieldMode, setYieldMode] = useState<'weight' | 'pieces'>('weight');
  const [billedPrice, setBilledPrice] = useState('');

  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [itemModal, setItemModal] = useState<{ groupId: string; itemId?: string } | null>(null);
  const [newExtraLabel, setNewExtraLabel] = useState('');
  const [newExtraCost, setNewExtraCost] = useState('');
  const [categories, setCategories] = useState<CategoryWithCount[]>([]);
  const [categoryPickerMode, setCategoryPickerMode] = useState<'move' | 'copy' | null>(null);

  const guard = useEditGuard();
  const { canEdit } = useAccess();
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isFirstLoad = useRef(true);
  // Champs de la recette tels qu'ils sont en base (même format que les champs de saisie) : on
  // n'enregistre que ce qui a réellement changé.
  const savedFieldsKey = useRef('');
  // Modification pas encore écrite en base (enregistrement différé de 400 ms pendant la frappe).
  const pendingMeta = useRef<{ key: string; meta: RecipeMetaInput } | null>(null);

  const flushPendingMeta = useCallback(async () => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = null;
    const pending = pendingMeta.current;
    if (!pending) return;
    pendingMeta.current = null;
    await updateRecipeMeta(db, recipeId, pending.meta);
    savedFieldsKey.current = pending.key;
  }, [db, recipeId]);

  // En quittant l'écran, on écrit tout de suite ce qui était encore en attente — sinon une
  // modification faite juste avant de revenir en arrière serait perdue.
  useEffect(() => {
    return () => {
      flushPendingMeta();
    };
  }, [flushPendingMeta]);

  const [loadError, setLoadError] = useState<string | null>(null);
  // Recettes qui utilisent celle-ci comme recette de base (ex: une crème dans un entremets).
  const [usedInRecipes, setUsedInRecipes] = useState<RecipeUsingIngredient[]>([]);
  const [showUsedIn, setShowUsedIn] = useState(false);

  const loadAll = useCallback(async () => {
    try {
      // Une saisie en attente doit être écrite avant de recharger, sinon le rechargement
      // remettrait l'ancienne valeur dans le champ.
      await flushPendingMeta();
      const [full, actions, ingredients, ingCategories, candidates, cats, usedIn] = await Promise.all([
        getRecipeFull(db, recipeId),
        listProcessActions(db),
        listIngredients(db),
        listIngredientCategories(db),
        listComponentCandidateRecipes(db, recipeId),
        listCategories(db),
        listRecipesUsingComponent(db, recipeId),
      ]);
      setUsedInRecipes(usedIn);
      setProcessActions(actions);
      setAllIngredients(ingredients);
      setIngredientCategories(ingCategories);
      setComponentCandidates(candidates);
      setCategories(cats);
      if (full) {
        const fields = {
          name: full.name,
          photoUri: photoFileExists(full.photoUri) ? full.photoUri : null,
          laborMinutes: String(Math.round(full.laborHours * 60)),
          hourlyRate: String(full.hourlyRate),
          marginPercent: String(full.marginPercent),
          servings: String(full.servings),
          billedPrice: full.billedPrice != null ? String(full.billedPrice) : '',
        };
        savedFieldsKey.current = JSON.stringify(fields);
        setRecipe(full);
        setName(fields.name);
        setPhotoUri(fields.photoUri);
        setLaborMinutes(fields.laborMinutes);
        setHourlyRate(fields.hourlyRate);
        setMarginPercent(fields.marginPercent);
        setServings(fields.servings);
        setBilledPrice(fields.billedPrice);
        if (isFirstLoad.current) {
          isFirstLoad.current = false;
          if (totalWeightGrams(full.groups) === 0 && full.servings > 1) setYieldMode('pieces');
        }
      }
      setLoadError(null);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : String(e));
    }
  }, [db, recipeId, flushPendingMeta]);

  useFocusEffect(
    useCallback(() => {
      isFirstLoad.current = true;
      loadAll();
    }, [loadAll])
  );

  const laborHoursValue = (parseFloat(laborMinutes.replace(',', '.')) || 0) / 60;

  // Debounced persistence of the recipe's own fields (name, labor, margin, servings, billed price, photo).
  useEffect(() => {
    if (!recipe || !canEdit) return;
    const key = JSON.stringify({ name, photoUri, laborMinutes, hourlyRate, marginPercent, servings, billedPrice });
    if (key === savedFieldsKey.current) {
      pendingMeta.current = null;
      if (saveTimer.current) clearTimeout(saveTimer.current);
      return;
    }
    pendingMeta.current = {
      key,
      meta: {
        name: name.trim() || t('Sans nom'),
        photoUri,
        laborHours: laborHoursValue,
        hourlyRate: parseFloat(hourlyRate.replace(',', '.')) || 0,
        marginPercent: parseFloat(marginPercent.replace(',', '.')) || 0,
        servings: parseInt(servings, 10) || 1,
        billedPrice: billedPrice.trim() ? parseFloat(billedPrice.replace(',', '.')) : null,
      },
    };
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(flushPendingMeta, 400);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name, photoUri, laborMinutes, hourlyRate, marginPercent, servings, billedPrice]);

  const summary = useMemo(() => {
    if (!recipe) return null;
    return computeRecipeCost({
      groups: recipe.groups,
      extraCosts: recipe.extraCosts,
      laborHours: laborHoursValue,
      hourlyRate: parseFloat(hourlyRate.replace(',', '.')) || 0,
      marginPercent: parseFloat(marginPercent.replace(',', '.')) || 0,
      servings: parseInt(servings, 10) || 1,
      billedPrice: billedPrice.trim() ? parseFloat(billedPrice.replace(',', '.')) : null,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recipe, laborMinutes, hourlyRate, marginPercent, servings, billedPrice]);

  const totalWeight = useMemo(() => (recipe ? totalWeightGrams(recipe.groups) : 0), [recipe]);

  const editingItem = useMemo(() => {
    if (!itemModal?.itemId || !recipe) return undefined;
    return recipe.groups.find((g) => g.id === itemModal.groupId)?.items.find((i) => i.id === itemModal.itemId);
  }, [itemModal, recipe]);

  async function handlePickPhoto() {
    if (!guard()) return;
    const uri = await pickAndStoreRecipePhoto();
    if (uri) {
      const previous = photoUri;
      setPhotoUri(uri);
      if (previous) deleteRecipePhoto(previous);
    }
  }

  function handleRemovePhoto() {
    if (!guard()) return;
    Alert.alert(t('Supprimer la photo ?'), t('Cette action est irréversible.'), [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: () => {
          if (photoUri) deleteRecipePhoto(photoUri);
          setPhotoUri(null);
        },
      },
    ]);
  }

  async function handleSaveGroup(groupId: string, data: { name: string; instruction: string | null; tagIds: string[] }) {
    await updateGroup(db, groupId, { name: data.name, instruction: data.instruction });
    await setGroupProcessTags(db, groupId, data.tagIds);
    await loadAll();
  }

  const handleDeleteGroup = useCallback(
    (groupId: string) => {
      if (!guard()) return;
      Alert.alert(t('Supprimer ce groupe ?'), t('Ses ingrédients seront supprimés aussi.'), [
        { text: t('Annuler'), style: 'cancel' },
        {
          text: t('Supprimer'),
          style: 'destructive',
          onPress: async () => {
            await deleteGroup(db, groupId);
            setEditingGroupId((cur) => (cur === groupId ? null : cur));
            await loadAll();
          },
        },
      ]);
    },
    [db, t, loadAll, guard]
  );

  // Rangement par glisser-déposer dans l'écran dédié (ReorderModal) : les étapes, ou les
  // ingrédients d'une étape.
  const [reorderTarget, setReorderTarget] = useState<{ kind: 'groups' } | { kind: 'items'; groupId: string } | null>(null);

  async function handleReorderDone(orderedIds: string[]) {
    const target = reorderTarget;
    setReorderTarget(null);
    if (!target) return;
    if (target.kind === 'groups') await reorderGroups(db, orderedIds);
    else await reorderGroupItems(db, orderedIds);
    await loadAll();
  }

  const reorderEntries = useMemo(() => {
    if (!recipe || !reorderTarget) return [];
    if (reorderTarget.kind === 'groups') {
      return recipe.groups.map((g, index) => ({
        id: g.id,
        label: g.name || t('Étape {n}', { n: index + 1 }),
        sublabel: g.items.map((i) => i.name).join(', '),
      }));
    }
    const group = recipe.groups.find((g) => g.id === reorderTarget.groupId);
    return (group?.items ?? []).map((i) => ({
      id: i.id,
      label: i.name,
      sublabel: `${formatQuantity(i.quantity)} ${unitLabel(i.unit, t)}`,
    }));
  }, [recipe, reorderTarget, t]);

  const handleEditGroup = useCallback(
    (groupId: string) => {
      if (guard()) setEditingGroupId(groupId);
    },
    [guard]
  );
  const handleAddItemToGroup = useCallback(
    (groupId: string) => {
      if (guard()) setItemModal({ groupId });
    },
    [guard]
  );
  const handleEditItemInGroup = useCallback(
    (groupId: string, itemId: string) => {
      if (guard()) setItemModal({ groupId, itemId });
    },
    [guard]
  );

  // Quick-add : ajoute à la dernière étape existante sans rien redemander. S'il n'y a encore
  // aucune étape, on ne fonce pas direct sur le choix d'un ingrédient dans une étape sans nom —
  // on passe par handleAddNewGroup pour d'abord demander l'action (Mélanger, Cuire...), plus
  // clair pour quelqu'un qui découvre l'appli.
  async function handleQuickAddIngredient() {
    if (!guard()) return;
    if (!recipe) return;
    const targetGroupId = recipe.groups[recipe.groups.length - 1]?.id;
    if (!targetGroupId) {
      await handleAddNewGroup();
      return;
    }
    setItemModal({ groupId: targetGroupId });
  }

  async function handleAddNewGroup() {
    if (!guard()) return;
    const newGroupId = await addGroup(db, recipeId, t('Étape {n}', { n: (recipe?.groups.length ?? 0) + 1 }));
    await loadAll();
    setEditingGroupId(newGroupId);
  }

  async function handleItemSubmit(data: {
    ingredientId: string | null;
    componentRecipeId: string | null;
    quantity: number;
    unit: BaseUnit;
    newPieceWeightG?: number;
    note: string | null;
  }) {
    if (!itemModal) return;
    const unit = data.ingredientId ? data.unit : 'g';
    // Poids d'une pièce / d'un paquet / d'un carton indiqué à l'instant : enregistré sur l'ingrédient
    // et ses achats, dont le prix passe au gramme.
    if (data.ingredientId && data.newPieceWeightG) {
      await setIngredientUnitWeight(db, data.ingredientId, data.newPieceWeightG);
    }
    const input = {
      ingredientId: data.ingredientId,
      componentRecipeId: data.componentRecipeId,
      quantity: data.quantity,
      unit,
      note: data.note,
    };
    if (itemModal.itemId) {
      await updateGroupItem(db, itemModal.itemId, input);
    } else {
      await addGroupItem(db, itemModal.groupId, input);
    }
    setItemModal(null);
    await loadAll();
  }

  const handleDeleteItem = useCallback(
    (itemId: string) => {
      if (!guard()) return;
      Alert.alert(t('Retirer cet ingrédient ?'), t('Cette action est irréversible.'), [
        { text: t('Annuler'), style: 'cancel' },
        {
          text: t('Retirer'),
          style: 'destructive',
          onPress: () => {
            deleteGroupItem(db, itemId).then(loadAll);
          },
        },
      ]);
    },
    [db, t, loadAll, guard]
  );

  const handleReorderItems = useCallback(
    (groupId: string) => {
      if (guard()) setReorderTarget({ kind: 'items', groupId });
    },
    [guard]
  );

  async function handleAddCustomAction(actionName: string) {
    if (!guard()) return;
    await createCustomProcessAction(db, actionName);
    setProcessActions(await listProcessActions(db));
  }

  async function handleRenameAction(actionId: string, newName: string) {
    if (!guard()) return;
    await updateProcessAction(db, actionId, newName);
    setProcessActions(await listProcessActions(db));
    await loadAll();
  }

  async function handleDeleteAction(actionId: string) {
    if (!guard()) return;
    try {
      await deleteProcessAction(db, actionId);
      setProcessActions(await listProcessActions(db));
    } catch (e) {
      if (e instanceof ProcessActionInUseError) {
        Alert.alert(
          t('Impossible'),
          t('Cette action est utilisée dans : {names}. Change-la dans ces recettes si tu veux la supprimer.', {
            names: e.recipeNames.join(', '),
          })
        );
      }
    }
  }

  function handleDeleteExtraCost(id: string, label: string) {
    if (!guard()) return;
    Alert.alert(t('Supprimer "{label}" ?', { label }), t('Cette action est irréversible.'), [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: () => {
          deleteExtraCost(db, id).then(loadAll);
        },
      },
    ]);
  }

  async function handleAddExtraCost() {
    if (!guard()) return;
    const cost = parseFloat(newExtraCost.replace(',', '.'));
    if (!newExtraLabel.trim() || !(cost > 0)) return;
    await addExtraCost(db, recipeId, newExtraLabel.trim(), cost);
    setNewExtraLabel('');
    setNewExtraCost('');
    await loadAll();
  }

  function handleDeleteRecipe() {
    Alert.alert(t('Supprimer cette recette ?'), t('Cette action est irréversible.'), [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteRecipe(db, recipeId);
          } catch (e) {
            Alert.alert(
              t('Impossible'),
              t("Cette recette est utilisée comme composant dans une autre recette : retire-la de là d'abord.")
            );
            return;
          }
          if (photoUri) deleteRecipePhoto(photoUri);
          navigation.goBack();
        },
      },
    ]);
  }

  async function handleCategoryPicked(targetCategoryId: string) {
    const mode = categoryPickerMode;
    setCategoryPickerMode(null);
    if (mode === 'move') {
      await moveRecipeToCategory(db, recipeId, targetCategoryId);
      navigation.goBack();
    } else if (mode === 'copy') {
      const targetName = categories.find((c) => c.id === targetCategoryId)?.name ?? '';
      const copiedPhotoUri = duplicateRecipePhoto(photoUri);
      await duplicateRecipe(db, recipeId, targetCategoryId, copiedPhotoUri);
      Alert.alert(t('Recette dupliquée'), t('Une copie a été ajoutée dans "{category}".', { category: targetName }));
    }
  }

  async function handlePrint() {
    if (!recipe) return;
    // Le PDF ne sait pas lire un fichier du téléphone : on intègre la photo dans la page.
    let printPhoto: string | null = null;
    if (photoUri) {
      try {
        printPhoto = `data:image/jpeg;base64,${await new File(photoUri).base64()}`;
      } catch {
        printPhoto = null;
      }
    }
    const html = generateRecipeHtml({ ...recipe, name, photoUri: printPhoto }, categoryName, processActions, t);
    const { uri } = await Print.printToFileAsync({ html });
    await Sharing.shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });
  }

  if (loadError) {
    return (
      <ScreenContainer>
        <GradientHeaderBand title={t('Recette')} onBack={() => navigation.goBack()} />
        <View style={styles.errorContainer}>
          <Ionicons name="warning-outline" size={32} color={colors.danger} />
          <Text style={styles.errorTitle}>{t('Erreur de chargement')}</Text>
          <Text style={styles.errorText}>{loadError}</Text>
          <PrimaryButton label={t('Réessayer')} onPress={loadAll} style={{ marginTop: spacing.lg }} />
        </View>
      </ScreenContainer>
    );
  }

  if (!recipe || !summary) return <ScreenContainer />;

  return (
    <ScreenContainer>
      <GradientHeaderBand title={name || t('Recette')} onBack={() => navigation.goBack()} />
      <HintBanner
        id="recipe-form-intro"
        text={t('Ajoute une étape (ex: Mélanger), puis ses ingrédients — le prix se calcule tout seul.')}
      />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={
            Platform.OS === 'android' && keyboardHeight > 0 ? { paddingBottom: keyboardHeight + 24 } : undefined
          }
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.photoSection}>
            {photoUri ? (
              <View>
                {/* Toucher la photo la change ; seule la petite croix la supprime (avec confirmation). */}
                <Pressable onPress={handlePickPhoto}>
                  <Image source={{ uri: photoUri }} style={styles.photo} />
                </Pressable>
                <Pressable onPress={handleRemovePhoto} hitSlop={10} style={styles.photoRemoveBadge}>
                  <Ionicons name="close" size={14} color="#fff" />
                </Pressable>
              </View>
            ) : (
              <Pressable style={styles.photoPlaceholder} onPress={handlePickPhoto}>
                <Ionicons name="camera-outline" size={28} color={colors.textMuted} />
                <Text style={styles.photoPlaceholderText}>{t('Ajouter une photo')}</Text>
              </Pressable>
            )}
            <View style={{ flex: 1, marginLeft: spacing.md }}>
              <FieldLabel>{t('Nom de la recette')}</FieldLabel>
              <TextInput editable={canEdit} style={inputStyles.input} value={name} onChangeText={setName} placeholder={t('ex: Fraisier')} />
            </View>
          </View>
          <View style={styles.yieldBox}>
            <View style={styles.yieldTabRow}>
              <Pressable
                style={[styles.yieldTab, yieldMode === 'weight' && { backgroundColor: accent }]}
                onPress={() => setYieldMode('weight')}
              >
                <Text style={[styles.yieldTabText, yieldMode === 'weight' && styles.yieldTabTextActive]}>
                  {t('Poids')}
                </Text>
              </Pressable>
              <Pressable
                style={[styles.yieldTab, yieldMode === 'pieces' && { backgroundColor: accent }]}
                onPress={() => setYieldMode('pieces')}
              >
                <Text style={[styles.yieldTabText, yieldMode === 'pieces' && styles.yieldTabTextActive]}>
                  {t('Nombre de pièces')}
                </Text>
              </Pressable>
            </View>
            {yieldMode === 'weight' ? (
              <View style={styles.yieldRow}>
                <Ionicons name="scale-outline" size={18} color={accentDark} />
                <Text style={[styles.weightText, { color: accentDark }]}>
                  {t('Poids total : {weight}', {
                    weight: totalWeight > 0 ? formatWeight(totalWeight) : t('calculé depuis les ingrédients'),
                  })}
                </Text>
              </View>
            ) : (
              <View style={styles.yieldRow}>
                <Ionicons name="apps-outline" size={18} color={accentDark} />
                <TextInput editable={canEdit}
                  style={[inputStyles.input, styles.yieldInput]}
                  value={servings}
                  onChangeText={setServings}
                  keyboardType="number-pad"
                  placeholder={t('ex: 8')}
                />
                <Text style={[styles.weightText, { color: accentDark }]}>{t('pièce(s) produites')}</Text>
              </View>
            )}
          </View>
          {usedInRecipes.length > 0 && (
            <View style={styles.usedInBox}>
              <Pressable style={styles.usedInHeader} onPress={() => setShowUsedIn((v) => !v)}>
                <Ionicons name="git-branch-outline" size={18} color={accentDark} />
                <Text style={[styles.usedInTitle, { color: accentDark }]}>
                  {t('Utilisée dans {count} recette(s)', { count: usedInRecipes.length })}
                </Text>
                <Ionicons name={showUsedIn ? 'chevron-up' : 'chevron-down'} size={18} color={accentDark} />
              </Pressable>
              {showUsedIn &&
                usedInRecipes.map((r) => (
                  <Pressable
                    key={r.recipeId}
                    style={styles.usedInRow}
                    onPress={() =>
                      navigation.dispatch(
                        StackActions.push('RecipeForm', {
                          recipeId: r.recipeId,
                          categoryId: r.categoryId,
                          categoryName: r.categoryName,
                        })
                      )
                    }
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={styles.usedInName}>{r.recipeName}</Text>
                      <Text style={styles.usedInSub}>{r.categoryName}</Text>
                    </View>
                    <Text style={styles.usedInQty}>{formatQuantity(r.quantity)} g</Text>
                    <Ionicons name="chevron-forward" size={16} color={colors.textMuted} />
                  </Pressable>
                ))}
            </View>
          )}

          <Pressable style={[styles.addIngredientBtn, { backgroundColor: accent }]} onPress={handleQuickAddIngredient}>
            <Ionicons name="add-circle" size={22} color="#fff" />
            <Text style={styles.addIngredientText}>{t('Ajouter un ingrédient')}</Text>
          </Pressable>

          {recipe.groups.length > 1 && (
            <Pressable
              style={styles.reorderStepsBtn}
              onPress={() => guard() && setReorderTarget({ kind: 'groups' })}
              hitSlop={6}
            >
              <Ionicons name="swap-vertical" size={16} color={accentDark} />
              <Text style={[styles.reorderStepsText, { color: accentDark }]}>{t('Ranger les étapes')}</Text>
            </Pressable>
          )}
          {recipe.groups.map((group) => (
            <GroupCard
              key={group.id}
              group={group}
              processActions={processActions}
              onEditGroup={handleEditGroup}
              onDeleteGroup={handleDeleteGroup}
              onAddItem={handleAddItemToGroup}
              onEditItem={handleEditItemInGroup}
              onDeleteItem={handleDeleteItem}
              onReorderItems={handleReorderItems}
            />
          ))}

          <Pressable style={[styles.addStepBtn, { borderColor: accent }]} onPress={handleAddNewGroup}>
            <Ionicons name="add-circle-outline" size={22} color={accentDark} />
            <View style={{ marginLeft: spacing.xs, flexShrink: 1 }}>
              <Text style={[styles.addStepText, { color: accentDark }]}>{t('Nouvelle étape')}</Text>
              <Text style={styles.addStepSubtext}>
                {t('Optionnel — pour les recettes en plusieurs parties')}
              </Text>
            </View>
          </Pressable>

          <SectionCard title={t('Temps de travail')}>
            <FieldLabel>{t('Temps passé (minutes)')}</FieldLabel>
            <TextInput editable={canEdit}
              style={inputStyles.input}
              value={laborMinutes}
              onChangeText={setLaborMinutes}
              keyboardType="decimal-pad"
              placeholder={t('ex: 45')}
            />
            <FieldLabel>{t('Tarif horaire souhaité ({currency}/h)', { currency: getCurrencySymbol() })}</FieldLabel>
            <TextInput editable={canEdit}
              style={inputStyles.input}
              value={hourlyRate}
              onChangeText={setHourlyRate}
              keyboardType="decimal-pad"
            />
            <Text style={styles.hint}>
              {t('Repère : SMIG Maroc 2026 = 17,92 {currency}/h', { currency: getCurrencySymbol() })}
            </Text>
          </SectionCard>

          <SectionCard title={t('Frais annexes')}>
            {recipe.extraCosts.map((extra) => (
              <View key={extra.id} style={styles.extraRow}>
                <Text style={styles.extraLabel}>{extra.label}</Text>
                <Text style={styles.extraCost}>{formatMoney(extra.cost)}</Text>
                <Pressable
                  onPress={() => handleDeleteExtraCost(extra.id, extra.label)}
                  hitSlop={8}
                  style={{ marginLeft: spacing.sm }}
                >
                  <Ionicons name="close" size={16} color={colors.textMuted} />
                </Pressable>
              </View>
            ))}
            <View style={styles.addExtraRow}>
              <TextInput editable={canEdit}
                style={[inputStyles.input, { flex: 2 }]}
                placeholder={t('ex: Boîte')}
                value={newExtraLabel}
                onChangeText={setNewExtraLabel}
              />
              <TextInput editable={canEdit}
                style={[inputStyles.input, { flex: 1, marginLeft: spacing.sm }]}
                placeholder={getCurrencySymbol()}
                value={newExtraCost}
                onChangeText={setNewExtraCost}
                keyboardType="decimal-pad"
              />
              <Pressable style={[styles.addExtraBtn, { backgroundColor: accent }]} onPress={handleAddExtraCost}>
                <Ionicons name="add" size={20} color="#fff" />
              </Pressable>
            </View>
          </SectionCard>

          <SectionCard title={t('Marge et parts')}>
            <FieldLabel>{t('Marge souhaitée (%)')}</FieldLabel>
            <TextInput editable={canEdit}
              style={inputStyles.input}
              value={marginPercent}
              onChangeText={setMarginPercent}
              keyboardType="decimal-pad"
            />
            <FieldLabel>{t('Nombre de parts')}</FieldLabel>
            <TextInput editable={canEdit} style={inputStyles.input} value={servings} onChangeText={setServings} keyboardType="number-pad" />
            <FieldLabel>{t('Prix actuellement facturé — par part (optionnel)')}</FieldLabel>
            <TextInput editable={canEdit}
              style={inputStyles.input}
              value={billedPrice}
              onChangeText={setBilledPrice}
              keyboardType="decimal-pad"
              placeholder={getCurrencySymbol()}
            />
          </SectionCard>

          <ResultsPanel
            summary={summary}
            missingPriceCount={
              recipe.groups.reduce(
                (n, g) => n + g.items.filter((i) => i.unitPrice === 0 && i.quantity > 0).length,
                0
              )
            }
          />

          <PrimaryButton label={t('Imprimer la fiche')} onPress={handlePrint} style={styles.printBtn} />
          <Text style={styles.categoryActionsLabel}>{t('Catégorie : {category}', { category: categoryName })}</Text>
          <View style={styles.categoryActionsRow}>
            <PrimaryButton
              label={t('Déplacer')}
              variant="secondary"
              onPress={() => guard() && setCategoryPickerMode('move')}
              style={styles.flexBtn}
            />
            <PrimaryButton
              label={t('Dupliquer')}
              variant="secondary"
              onPress={() => guard() && setCategoryPickerMode('copy')}
              style={styles.flexBtn}
            />
          </View>
          <PrimaryButton
            label={t('Supprimer la recette')}
            variant="danger"
            onPress={handleDeleteRecipe}
            style={styles.deleteRecipeBtn}
          />
        </ScrollView>
      </KeyboardAvoidingView>

      <GroupFormModal
        visible={!!editingGroupId}
        group={recipe.groups.find((g) => g.id === editingGroupId) ?? null}
        processActions={processActions}
        onAddCustomAction={handleAddCustomAction}
        onRenameAction={handleRenameAction}
        onDeleteAction={handleDeleteAction}
        onSave={handleSaveGroup}
        onDelete={handleDeleteGroup}
        onClose={() => setEditingGroupId(null)}
      />

      <ReorderModal
        visible={!!reorderTarget}
        title={reorderTarget?.kind === 'groups' ? t('Ranger les étapes') : t('Ranger les ingrédients')}
        entries={reorderEntries}
        onCancel={() => setReorderTarget(null)}
        onDone={handleReorderDone}
      />
      <IngredientPickerModal
        visible={!!itemModal}
        ingredients={allIngredients}
        ingredientCategories={ingredientCategories}
        componentCandidates={componentCandidates}
        initialIngredientId={editingItem?.ingredientId}
        initialComponentRecipeId={editingItem?.componentRecipeId}
        initialQuantity={editingItem?.quantity}
        initialNote={editingItem?.note}
        initialUnit={editingItem?.unit}
        onSubmit={handleItemSubmit}
        onCancel={() => setItemModal(null)}
      />

      <CategoryPickerModal
        visible={!!categoryPickerMode}
        title={categoryPickerMode === 'move' ? t('Déplacer vers quelle catégorie ?') : t('Dupliquer dans quelle catégorie ?')}
        categories={categories}
        currentCategoryId={categoryId}
        onSelect={handleCategoryPicked}
        onCancel={() => setCategoryPickerMode(null)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  usedInBox: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
  },
  usedInHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  usedInTitle: {
    flex: 1,
    fontSize: 15,
    fontWeight: '700',
  },
  usedInRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  usedInName: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.text,
  },
  usedInSub: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 1,
  },
  usedInQty: {
    fontSize: 14,
    color: colors.text,
  },
  reorderStepsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-end',
    gap: 4,
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  reorderStepsText: {
    fontSize: 14,
    fontWeight: '700',
  },
  errorContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  errorTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: colors.text,
    marginTop: spacing.sm,
  },
  errorText: {
    fontSize: 13,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: spacing.xs,
  },
  photoSection: {
    flexDirection: 'row',
    padding: spacing.md,
  },
  photo: {
    width: 84,
    height: 84,
    borderRadius: radius.md,
  },
  photoRemoveBadge: {
    position: 'absolute',
    top: -6,
    right: -6,
    backgroundColor: colors.danger,
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoPlaceholder: {
    width: 84,
    height: 84,
    borderRadius: radius.md,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
  },
  photoPlaceholderText: {
    fontSize: 10,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: 2,
  },
  yieldBox: {
    backgroundColor: colors.surfaceAlt,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    padding: spacing.sm,
    borderRadius: radius.md,
  },
  yieldTabRow: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: radius.sm,
    padding: 3,
    marginBottom: spacing.sm,
  },
  yieldTab: {
    flex: 1,
    paddingVertical: spacing.xs + 2,
    borderRadius: radius.sm - 2,
    alignItems: 'center',
  },
  yieldTabText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.textMuted,
  },
  yieldTabTextActive: {
    color: '#fff',
  },
  yieldRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  yieldInput: {
    marginHorizontal: spacing.sm,
    width: 80,
    textAlign: 'center',
    paddingVertical: spacing.xs + 2,
  },
  weightText: {
    fontSize: 15,
    fontWeight: '700',
    marginLeft: spacing.xs,
  },
  addIngredientBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    borderRadius: radius.md,
  },
  addIngredientText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
    marginLeft: spacing.xs,
  },
  addStepBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    backgroundColor: colors.surfaceAlt,
  },
  addStepText: {
    fontWeight: '700',
    fontSize: 15,
    textAlign: 'center',
  },
  addStepSubtext: {
    color: colors.textMuted,
    fontWeight: '500',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 1,
  },
  hint: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: spacing.xs,
  },
  extraRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.xs,
  },
  extraLabel: {
    flex: 1,
    color: colors.text,
  },
  extraCost: {
    color: colors.text,
    fontWeight: '600',
  },
  addExtraRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  addExtraBtn: {
    marginLeft: spacing.sm,
    width: 44,
    height: 44,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  printBtn: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  categoryActionsLabel: {
    fontSize: 12,
    color: colors.textMuted,
    marginHorizontal: spacing.md,
    marginBottom: spacing.xs,
  },
  categoryActionsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
  },
  flexBtn: {
    flex: 1,
  },
  deleteRecipeBtn: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.xl,
  },
});
