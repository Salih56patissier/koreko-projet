import React from 'react';
import { ScrollView, Text, StyleSheet, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import SectionCard from '../../components/common/SectionCard';
import PrimaryButton from '../../components/common/PrimaryButton';
import { colors, spacing } from '../../theme/colors';
import { useI18n } from '../../i18n/I18nContext';
import { useAccess } from '../../access/AccessContext';

export default function PremiumScreen() {
  const navigation = useNavigation();
  const { t } = useI18n();
  const { isPremium, trialDaysLeft, canEdit } = useAccess();

  const status = isPremium
    ? t('Version premium active. Merci !')
    : canEdit
      ? t('Essai gratuit : {days} jour(s) restant(s).', { days: trialDaysLeft })
      : t('Ton essai gratuit est terminé. Tes données restent consultables.');

  return (
    <ScreenContainer>
      <GradientHeaderBand title={t('Version premium')} onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ paddingBottom: spacing.xl }}>
        <SectionCard title={t('Ton essai')}>
          <Text style={styles.text}>{status}</Text>
        </SectionCard>
        <SectionCard title={t('Les formules')}>
          <View style={styles.plan}>
            <Text style={styles.planName}>{t('Mensuel')}</Text>
            <Text style={styles.textMuted}>{t('Sans engagement.')}</Text>
          </View>
          <View style={styles.plan}>
            <Text style={styles.planName}>{t('Annuel')}</Text>
            <Text style={styles.textMuted}>{t('Le plus avantageux au mois.')}</Text>
          </View>
          <View style={styles.plan}>
            <Text style={styles.planName}>{t('À vie')}</Text>
            <Text style={styles.textMuted}>{t('Un seul paiement, pour toujours.')}</Text>
          </View>
          <PrimaryButton label={t('Bientôt disponible.')} onPress={() => {}} disabled />
        </SectionCard>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  text: { fontSize: 15, color: colors.text },
  textMuted: { fontSize: 13, color: colors.textMuted, marginTop: 2 },
  plan: { marginBottom: spacing.md },
  planName: { fontSize: 16, fontWeight: '700', color: colors.text },
});
