import React, { useCallback, useState } from 'react';
import { Text, TextInput, View, Pressable, StyleSheet, Alert } from 'react-native';
import KeyboardAwareScrollView from '../../components/common/KeyboardAwareScrollView';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import Constants from 'expo-constants';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import SectionCard from '../../components/common/SectionCard';
import FieldLabel from '../../components/common/FieldLabel';
import PrimaryButton from '../../components/common/PrimaryButton';
import { colors, radius, spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import { useTheme } from '../../theme/ThemeContext';
import {
  useI18n,
  SUPPORTED_LOCALES,
  LOCALE_LABELS,
  RTL_LOCALES,
  detectDeviceLocale,
  type LocaleCode,
} from '../../i18n/I18nContext';
import { getSettings, updateSettings } from '../../db/repositories/settingsRepo';
import { exportBackupAndShare, pickBackupFileContent, saveSafetyCopyBeforeRestore } from '../../backup/backupFile';
import { BackupRestoreError, restoreBackupData } from '../../backup/backupRepo';
import { restorePhotosFromBackup } from '../../backup/backupPhotos';
import { disableAutoBackup, requestAutoBackupFolder, runAutoBackup } from '../../backup/autoBackup';
import { setCurrencySymbol } from '../../utils/format';
import { formatDate, toIsoDate } from '../../utils/date';
import { RootStackParamList } from '../../navigation/types';
import { useAccess } from '../../access/AccessContext';
import { useHints } from '../../hints/HintsContext';

type Nav = NativeStackNavigationProp<RootStackParamList, 'Settings'>;

export default function SettingsScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation<Nav>();
  const { isPremium, canEdit, trialDaysLeft } = useAccess();
  const { resetAll: resetAllHints } = useHints();
  const theme = useTheme();
  const { t, locale, isSystemLocale, setLocale } = useI18n();

  function formatBackupDate(iso: string | null): string {
    if (!iso) return t('jamais');
    const d = new Date(iso);
    return `${formatDate(toIsoDate(d))} · ${d.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })}`;
  }

  const [defaultHourlyRate, setDefaultHourlyRate] = useState('17.92');
  const [currencySymbol, setCurrencySymbolField] = useState('DH');
  const [saved, setSaved] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [autoBackupFolderUri, setAutoBackupFolderUri] = useState<string | null>(null);
  const [lastAutoBackupAt, setLastAutoBackupAt] = useState<string | null>(null);
  const [autoBackupBusy, setAutoBackupBusy] = useState(false);

  useFocusEffect(
    useCallback(() => {
      getSettings(db).then((s) => {
        setDefaultHourlyRate(String(s.defaultHourlyRate));
        setCurrencySymbolField(s.currencySymbol);
        setAutoBackupFolderUri(s.autoBackupFolderUri);
        setLastAutoBackupAt(s.lastAutoBackupAt);
      });
    }, [db])
  );

  function handleSelectLocale(next: LocaleCode | null) {
    const wasRTL = RTL_LOCALES.includes(locale);
    const willBeRTL = RTL_LOCALES.includes(next ?? detectDeviceLocale());
    setLocale(next);
    if (wasRTL !== willBeRTL) {
      Alert.alert(
        t('Redémarre l\'application'),
        t("Le sens d'écriture a changé — ferme complètement l'application et rouvre-la pour que tout s'affiche correctement.")
      );
    }
  }

  async function handleEnableAutoBackup() {
    Alert.alert(
      t('Sauvegarde automatique'),
      t(
        "Choisis un dossier dans Google Drive ou OneDrive (ou « Documents » sur le téléphone). L'app y écrira automatiquement une copie de tes données à chaque utilisation : si tu perds ou changes de téléphone, tu la retrouves."
      
      ),
      [
        { text: t('Annuler'), style: 'cancel' },
        {
          text: t('Choisir le dossier'),
          onPress: async () => {
            setAutoBackupBusy(true);
            try {
              const result = await requestAutoBackupFolder(db);
              if (!result.granted) {
                setAutoBackupBusy(false);
                return;
              }
              await runAutoBackup(db);
              const s = await getSettings(db);
              setAutoBackupFolderUri(s.autoBackupFolderUri);
              setLastAutoBackupAt(s.lastAutoBackupAt);
            } catch (e) {
              Alert.alert(t('Erreur'), t("Impossible d'activer la sauvegarde automatique."));
            } finally {
              setAutoBackupBusy(false);
            }
          },
        },
      ]
    );
  }

  async function handleTestAutoBackupNow() {
    setAutoBackupBusy(true);
    try {
      const result = await runAutoBackup(db);
      const s = await getSettings(db);
      setAutoBackupFolderUri(s.autoBackupFolderUri);
      setLastAutoBackupAt(s.lastAutoBackupAt);
      if (result === 'error') {
        Alert.alert(
          t('Dossier inaccessible'),
          t("L'accès au dossier a été perdu (stockage effacé, dossier supprimé…). Choisis-en un nouveau.")
        );
      }
    } finally {
      setAutoBackupBusy(false);
    }
  }

  function handleDisableAutoBackup() {
    Alert.alert(t('Désactiver la sauvegarde automatique ?'), '', [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Désactiver'),
        style: 'destructive',
        onPress: async () => {
          await disableAutoBackup(db);
          setAutoBackupFolderUri(null);
        },
      },
    ]);
  }

  async function handleSave() {
    const rate = parseFloat(defaultHourlyRate.replace(',', '.'));
    const symbol = currencySymbol.trim() || 'DH';
    await updateSettings(db, { defaultHourlyRate: rate > 0 ? rate : 17.92, currencySymbol: symbol });
    setCurrencySymbol(symbol);
    setCurrencySymbolField(symbol);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  }

  async function handleExport() {
    setExporting(true);
    try {
      await exportBackupAndShare(db);
    } catch (e) {
      Alert.alert(t('Erreur'), t("La sauvegarde n'a pas pu être créée."));
    } finally {
      setExporting(false);
    }
  }

  async function handleImport() {
    setImporting(true);
    try {
      const content = await pickBackupFileContent();
      if (!content) {
        setImporting(false);
        return;
      }
      const data = JSON.parse(content);
      Alert.alert(
        t('Restaurer cette sauvegarde ?'),
        t(
          'Tout ce qui est sur ce téléphone (ingrédients, recettes, Caisse, courses) sera remplacé par le contenu du fichier. Une copie de sécurité de tes données actuelles est faite juste avant. Cette action est irréversible.'
        ),
        [
          { text: t('Annuler'), style: 'cancel', onPress: () => setImporting(false) },
          {
            text: t('Restaurer'),
            style: 'destructive',
            onPress: async () => {
              try {
                try {
                  await saveSafetyCopyBeforeRestore(db);
                  await runAutoBackup(db);
                } catch {
                  // La copie de sécurité est un plus : on ne bloque pas la restauration pour ça.
                }
                await restoreBackupData(db, data);
                await restorePhotosFromBackup(db, data);
                const s = await getSettings(db);
                setDefaultHourlyRate(String(s.defaultHourlyRate));
                // La devise de la sauvegarde s'applique tout de suite à tous les montants affichés.
                setCurrencySymbol(s.currencySymbol);
                setCurrencySymbolField(s.currencySymbol);
                Alert.alert(
                  t('Terminé'),
                  t('La sauvegarde a été restaurée. Retourne dans les autres onglets pour voir tes données.')
                );
              } catch (e) {
                Alert.alert(
                  t('Erreur'),
                  e instanceof BackupRestoreError ? t(e.message) : t("La restauration a échoué, aucune donnée n'a été modifiée.")
                );
              } finally {
                setImporting(false);
              }
            },
          },
        ]
      );
    } catch (e) {
      Alert.alert(t('Erreur'), t('Ce fichier ne peut pas être lu.'));
      setImporting(false);
    }
  }

  return (
    <ScreenContainer>
      <GradientHeaderBand title={t('Réglages')} onBack={() => navigation.goBack()} />
      <KeyboardAwareScrollView contentContainerStyle={{ paddingTop: spacing.md, paddingBottom: spacing.xl }}>
        <SectionCard title={t("Couleur de l'application")}>
          <Text style={styles.textMuted}>{t("Choisis l'ambiance qui te plaît, ça change partout instantanément.")}</Text>
          <View style={styles.swatchRow}>
            {theme.themes.map((themeOption) => {
              const active = themeOption.id === theme.themeId;
              return (
                <Pressable
                  key={themeOption.id}
                  onPress={() => theme.setAccentThemeId(themeOption.id)}
                  style={[styles.swatch, { backgroundColor: themeOption.accent }, active && styles.swatchActive]}
                >
                  {active && <Ionicons name="checkmark" size={20} color="#fff" />}
                </Pressable>
              );
            })}
          </View>
        </SectionCard>

        <SectionCard title={t('Langue')}>
          <Text style={styles.textMuted}>{t("Change la langue de l'application.")}</Text>
          <View style={styles.langRow}>
            <Pressable
              onPress={() => handleSelectLocale(null)}
              style={[styles.langChip, isSystemLocale && { backgroundColor: theme.accent, borderColor: theme.accent }]}
            >
              <Text style={[styles.langChipText, isSystemLocale && styles.langChipTextActive]}>{t('Système')}</Text>
            </Pressable>
            {SUPPORTED_LOCALES.map((code) => {
              const active = !isSystemLocale && code === locale;
              return (
                <Pressable
                  key={code}
                  onPress={() => handleSelectLocale(code)}
                  style={[styles.langChip, active && { backgroundColor: theme.accent, borderColor: theme.accent }]}
                >
                  <Text style={[styles.langChipText, active && styles.langChipTextActive]}>{LOCALE_LABELS[code]}</Text>
                </Pressable>
              );
            })}
          </View>
        </SectionCard>

        <SectionCard title={t('Devise')}>
          <FieldLabel>{t('Symbole affiché dans toute l\'app (ex: DH, €, $, MAD)')}</FieldLabel>
          <TextInput
            style={inputStyles.input}
            value={currencySymbol}
            onChangeText={setCurrencySymbolField}
            placeholder="DH"
            autoCapitalize="characters"
          />
        </SectionCard>

        <SectionCard title={t('Tarif horaire par défaut')}>
          <FieldLabel>
            {t('Utilisé automatiquement pour chaque nouvelle recette ({currency}/h)', {
              currency: currencySymbol || 'DH',
            })}
          </FieldLabel>
          <TextInput
            style={inputStyles.input}
            value={defaultHourlyRate}
            onChangeText={setDefaultHourlyRate}
            keyboardType="decimal-pad"
          />
          <Text style={styles.hint}>
            {t('Repère : SMIG Maroc 2026 = 17,92 {currency}/h', { currency: currencySymbol || 'DH' })}
          </Text>
        </SectionCard>

        <PrimaryButton
          label={saved ? t('Enregistré ✓') : t('Enregistrer la devise et le tarif horaire')}
          onPress={handleSave}
          style={{ marginHorizontal: spacing.md, marginTop: -spacing.sm, marginBottom: spacing.md }}
        />

        <SectionCard title={t('Sauvegarde')}>
          <Text style={styles.textMuted}>
            {t(
              'Toutes tes données sont stockées uniquement sur ce téléphone. Exporte une sauvegarde régulièrement pour ne rien perdre, et pouvoir la restaurer sur ce téléphone ou un autre.'
            )}
          </Text>
          <PrimaryButton
            label={t('Exporter une sauvegarde')}
            onPress={handleExport}
            loading={exporting}
            style={{ marginTop: spacing.md }}
          />
          <PrimaryButton
            label={t('Restaurer depuis un fichier')}
            variant="secondary"
            onPress={handleImport}
            loading={importing}
            style={{ marginTop: spacing.sm }}
          />
        </SectionCard>

        <SectionCard title={t('Sauvegarde automatique')}>
          {autoBackupFolderUri ? (
            <>
              <Text style={styles.textMuted}>
                {t(
                  "Activée ✓ — une copie de tes données est écrite automatiquement dans le dossier choisi à chaque utilisation de l'app."
                )}
              </Text>
              <Text style={styles.hint}>
                {t('Dernière sauvegarde auto : {date}', { date: formatBackupDate(lastAutoBackupAt) })}
              </Text>
              <PrimaryButton
                label={t('Tester maintenant')}
                variant="secondary"
                onPress={handleTestAutoBackupNow}
                loading={autoBackupBusy}
                style={{ marginTop: spacing.md }}
              />
              <PrimaryButton
                label={t('Désactiver')}
                variant="secondary"
                onPress={handleDisableAutoBackup}
                style={{ marginTop: spacing.sm }}
              />
            </>
          ) : (
            <>
              <Text style={styles.textMuted}>
                {t(
                  "Choisis un dossier une seule fois, de préférence dans Google Drive ou OneDrive : l'app y écrira automatiquement une sauvegarde à chaque utilisation, sans rien te demander ensuite. Elle survit même si l'app est désinstallée ou si tu changes de téléphone." 
                )}
              </Text>
              <PrimaryButton
                label={t('Activer la sauvegarde automatique')}
                onPress={handleEnableAutoBackup}
                loading={autoBackupBusy}
                style={{ marginTop: spacing.md }}
              />
            </>
          )}
        </SectionCard>

        <SectionCard title={t('Aide')}>
          <PrimaryButton
            label={t('Revoir le tutoriel')}
            variant="secondary"
            onPress={() => navigation.navigate('Onboarding')}
          />
          <PrimaryButton
            label={t('Revoir les astuces')}
            variant="secondary"
            style={{ marginTop: spacing.sm }}
            onPress={async () => {
              await resetAllHints();
              Alert.alert(t('Astuces réaffichées'), t('Les petites explications sont de retour sur les écrans.'));
            }}
          />
        </SectionCard>

        <SectionCard title={t('Passer à la version premium')}>
          <Text style={styles.text}>
            {isPremium
              ? t('Version premium active. Merci !')
              : canEdit
                ? t('Essai gratuit : {days} jour(s) restant(s).', { days: trialDaysLeft })
                : t('Ton essai gratuit est terminé. Tes données restent consultables.')}
          </Text>
          <PrimaryButton label={t('Voir les formules')} variant="secondary" onPress={() => navigation.navigate('Premium')} />
        </SectionCard>

        <SectionCard title={t('À propos')}>
          <Text style={styles.text}>{t('Koreko — v{version}', { version: Constants.expoConfig?.version ?? '1.0.0' })}</Text>
          <Text style={styles.textMuted}>{t('Outil de calcul de prix de revient pour pâtissiers indépendants.')}</Text>
        </SectionCard>
      </KeyboardAwareScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  swatchRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: spacing.md,
    gap: spacing.sm,
  },
  swatch: {
    width: 44,
    height: 44,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  swatchActive: {
    borderWidth: 3,
    borderColor: colors.text,
  },
  langRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: spacing.md,
    gap: spacing.sm,
  },
  langChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  langChipText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
  },
  langChipTextActive: {
    color: '#fff',
  },
  hint: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: spacing.xs,
  },
  text: {
    fontSize: 15,
    color: colors.text,
  },
  textMuted: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: spacing.xs,
  },
});
