import React, { useRef, useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { useSQLiteContext } from 'expo-sqlite';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import KeyboardAwareScrollView from '../../components/common/KeyboardAwareScrollView';
import FieldLabel from '../../components/common/FieldLabel';
import PrimaryButton from '../../components/common/PrimaryButton';
import ExpenseCategoryPicker from '../../components/expenses/ExpenseCategoryPicker';
import { spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import { useI18n } from '../../i18n/I18nContext';
import { ExpensesStackParamList } from '../../navigation/types';
import { listExpenseCategories } from '../../db/repositories/expenseCategoriesRepo';
import { createExpense, deleteExpense, getExpense, updateExpense } from '../../db/repositories/expensesRepo';
import { ExpenseCategory } from '../../types/models';
import { getCurrencySymbol } from '../../utils/format';
import DateField from '../../components/common/DateField';
import { todayIso } from '../../utils/date';

type Route = RouteProp<ExpensesStackParamList, 'ExpenseForm'>;

export default function ExpenseFormScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation();
  const route = useRoute<Route>();
  const expenseId = route.params?.expenseId;
  const { t } = useI18n();

  const [date, setDate] = useState(todayIso());
  const [amount, setAmount] = useState('');
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [categories, setCategories] = useState<ExpenseCategory[]>([]);
  const [payee, setPayee] = useState('');
  const [note, setNote] = useState('');
  const [loaded, setLoaded] = useState(!expenseId);
  const savingRef = useRef(false); // double appui sur Enregistrer = un seul enregistrement

  useEffect(() => {
    listExpenseCategories(db).then(setCategories);
  }, [db]);

  useEffect(() => {
    if (!expenseId) return;
    getExpense(db, expenseId).then((exp) => {
      if (exp) {
        setDate(exp.expenseDate);
        setAmount(String(exp.amount));
        setCategoryId(exp.categoryId);
        setPayee(exp.payee ?? '');
        setNote(exp.note ?? '');
      }
      setLoaded(true);
    });
  }, [db, expenseId]);

  const canSave = date.trim().length > 0 && parseFloat(amount.replace(',', '.')) > 0;

  async function handleSave() {
    if (savingRef.current) return;
    savingRef.current = true;
    const input = {
      categoryId,
      expenseDate: date.trim(),
      amount: parseFloat(amount.replace(',', '.')),
      payee: payee.trim() || null,
      note: note.trim() || null,
    };
    if (expenseId) {
      await updateExpense(db, expenseId, input);
    } else {
      await createExpense(db, input);
    }
    navigation.goBack();
  }

  function handleDelete() {
    if (!expenseId) return;
    Alert.alert(t('Supprimer cette dépense ?'), t('Cette action est irréversible.'), [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: async () => {
          await deleteExpense(db, expenseId);
          navigation.goBack();
        },
      },
    ]);
  }

  if (!loaded) return <ScreenContainer />;

  return (
    <ScreenContainer>
      <GradientHeaderBand title={t('Dépense')} onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <KeyboardAwareScrollView contentContainerStyle={styles.content}>
        <FieldLabel>{t("Date d'achat")}</FieldLabel>
        <DateField value={date} onChange={setDate} />

        <FieldLabel>{t('Montant ({currency})', { currency: getCurrencySymbol() })}</FieldLabel>
        <TextInput
          style={inputStyles.input}
          value={amount}
          onChangeText={setAmount}
          keyboardType="decimal-pad"
          placeholder={t('ex: 500')}
        />

        <FieldLabel>{t('Catégorie')}</FieldLabel>
        <ExpenseCategoryPicker
          categories={categories}
          selectedId={categoryId}
          onSelect={setCategoryId}
          onCategoriesChanged={setCategories}
          allowNone
        />

        <View style={{ marginTop: spacing.md }}>
          <FieldLabel>{t('Payé à (optionnel)')}</FieldLabel>
          <TextInput style={inputStyles.input} value={payee} onChangeText={setPayee} placeholder={t('ex: Régie électricité')} />
        </View>

        <FieldLabel>{t('Note (optionnel)')}</FieldLabel>
        <TextInput style={inputStyles.input} value={note} onChangeText={setNote} placeholder={t('ex: promotion')} />

        <PrimaryButton label={t('Enregistrer')} onPress={handleSave} disabled={!canSave} style={styles.saveBtn} />
        {expenseId && (
          <PrimaryButton label={t('Supprimer')} variant="danger" onPress={handleDelete} style={styles.saveBtn} />
        )}
      </KeyboardAwareScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xl,
  },
  saveBtn: {
    marginTop: spacing.lg,
  },
});
