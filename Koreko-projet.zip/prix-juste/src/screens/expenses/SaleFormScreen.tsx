import React, { useRef, useEffect, useState } from 'react';
import { View, TextInput, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { useSQLiteContext } from 'expo-sqlite';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import KeyboardAwareScrollView from '../../components/common/KeyboardAwareScrollView';
import FieldLabel from '../../components/common/FieldLabel';
import PrimaryButton from '../../components/common/PrimaryButton';
import SaleCategoryPicker from '../../components/expenses/SaleCategoryPicker';
import { spacing } from '../../theme/colors';
import { inputStyles } from '../../theme/inputStyle';
import { useI18n } from '../../i18n/I18nContext';
import { ExpensesStackParamList } from '../../navigation/types';
import { listSaleCategories } from '../../db/repositories/saleCategoriesRepo';
import { createSale, deleteSale, getSale, updateSale } from '../../db/repositories/salesRepo';
import { SaleCategory } from '../../types/models';
import { getCurrencySymbol } from '../../utils/format';
import DateField from '../../components/common/DateField';
import { todayIso } from '../../utils/date';

type Route = RouteProp<ExpensesStackParamList, 'SaleForm'>;

export default function SaleFormScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation();
  const route = useRoute<Route>();
  const saleId = route.params?.saleId;
  const { t } = useI18n();

  const [date, setDate] = useState(todayIso());
  const [amount, setAmount] = useState('');
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [categories, setCategories] = useState<SaleCategory[]>([]);
  const [note, setNote] = useState('');
  const [loaded, setLoaded] = useState(!saleId);
  const savingRef = useRef(false); // double appui sur Enregistrer = un seul enregistrement

  useEffect(() => {
    listSaleCategories(db).then(setCategories);
  }, [db]);

  useEffect(() => {
    if (!saleId) return;
    getSale(db, saleId).then((sale) => {
      if (sale) {
        setDate(sale.saleDate);
        setAmount(String(sale.amount));
        setCategoryId(sale.categoryId);
        setNote(sale.note ?? '');
      }
      setLoaded(true);
    });
  }, [db, saleId]);

  const canSave = date.trim().length > 0 && parseFloat(amount.replace(',', '.')) > 0;

  async function handleSave() {
    if (savingRef.current) return;
    savingRef.current = true;
    const input = {
      categoryId,
      saleDate: date.trim(),
      amount: parseFloat(amount.replace(',', '.')),
      note: note.trim() || null,
    };
    if (saleId) {
      await updateSale(db, saleId, input);
    } else {
      await createSale(db, input);
    }
    navigation.goBack();
  }

  function handleDelete() {
    if (!saleId) return;
    Alert.alert(t('Supprimer cette vente ?'), t('Cette action est irréversible.'), [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Supprimer'),
        style: 'destructive',
        onPress: async () => {
          await deleteSale(db, saleId);
          navigation.goBack();
        },
      },
    ]);
  }

  if (!loaded) return <ScreenContainer />;

  return (
    <ScreenContainer>
      <GradientHeaderBand title={t('Vente')} onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <KeyboardAwareScrollView contentContainerStyle={styles.content}>
        <FieldLabel>{t('Date de la vente')}</FieldLabel>
        <DateField value={date} onChange={setDate} />

        <FieldLabel>{t('Montant ({currency})', { currency: getCurrencySymbol() })}</FieldLabel>
        <TextInput
          style={inputStyles.input}
          value={amount}
          onChangeText={setAmount}
          keyboardType="decimal-pad"
          placeholder={t('ex: 500')}
        />

        <FieldLabel>{t('Catégorie')}</FieldLabel>
        <SaleCategoryPicker
          categories={categories}
          selectedId={categoryId}
          onSelect={setCategoryId}
          onCategoriesChanged={setCategories}
          allowNone
        />

        <View style={{ marginTop: spacing.md }}>
          <FieldLabel>{t('Note (optionnel)')}</FieldLabel>
          <TextInput style={inputStyles.input} value={note} onChangeText={setNote} placeholder={t('ex: recette du jour')} />
        </View>

        <PrimaryButton label={t('Enregistrer')} onPress={handleSave} disabled={!canSave} style={styles.saveBtn} />
        {saleId && <PrimaryButton label={t('Supprimer')} variant="danger" onPress={handleDelete} style={styles.saveBtn} />}
      </KeyboardAwareScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xl,
  },
  saveBtn: {
    marginTop: spacing.lg,
  },
});
