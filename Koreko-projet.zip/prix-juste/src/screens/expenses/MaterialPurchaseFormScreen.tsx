import React, { useRef, useCallback, useEffect, useState } from 'react';
import { View, Text, TextInput, FlatList, Pressable, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import KeyboardAwareScrollView from '../../components/common/KeyboardAwareScrollView';
import FieldLabel from '../../components/common/FieldLabel';
import PrimaryButton from '../../components/common/PrimaryButton';
import SupplierPicker from '../../components/ingredient/SupplierPicker';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { useEditGuard } from '../../access/AccessContext';
import { inputStyles } from '../../theme/inputStyle';
import { Ingredient, PurchaseUnit, Supplier } from '../../types/models';
import { listIngredients, createIngredient } from '../../db/repositories/ingredientsRepo';
import { normalizeSearch } from '../../utils/normalize';
import { getLastUnitWeight, recordPurchase } from '../../db/repositories/ingredientPurchasesRepo';
import { listRecipesUsingIngredient } from '../../db/repositories/recipesRepo';
import { PurchaseUnitPicker, UnitWeightField, asksUnitWeight, parseWeight } from '../../components/ingredient/UnitFields';
import { isCountUnit } from '../../utils/priceCalc';
import { listSuppliers } from '../../db/repositories/suppliersRepo';
import { getCurrencySymbol, purchaseUnitLabel } from '../../utils/format';
import DateField from '../../components/common/DateField';
import { todayIso } from '../../utils/date';
import { confirmPurchaseUnit } from '../../components/ingredient/confirmPurchaseUnit';


export default function MaterialPurchaseFormScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation();
  const { accent } = useTheme();
  const { t } = useI18n();
  const guard = useEditGuard();

  const [search, setSearch] = useState('');
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [selected, setSelected] = useState<Ingredient | 'new' | null>(null);

  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [supplierId, setSupplierId] = useState<string | null>(null);
  const [date, setDate] = useState(todayIso());
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState<PurchaseUnit>('kg');
  const [note, setNote] = useState('');
  // Poids (g) d'UNE unité achetée (pièce, paquet, carton, litre) et obligation de le donner.
  const [unitWeight, setUnitWeight] = useState('');
  const [usedInGrams, setUsedInGrams] = useState(false);
  const [lastWeights, setLastWeights] = useState<Partial<Record<PurchaseUnit, number>>>({});
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);

  useEffect(() => {
    listIngredients(db, search || undefined).then(setIngredients);
  }, [db, search]);

  const loadSuppliers = useCallback(async () => {
    const rows = await listSuppliers(db);
    setSuppliers(rows);
    // Un fournisseur supprimé entre-temps ne doit pas rester sélectionné (l'enregistrement échouerait).
    setSupplierId((prev) => (prev && rows.some((r) => r.id === prev) ? prev : rows[0]?.id ?? null));
  }, [db]);

  useFocusEffect(
    useCallback(() => {
      loadSuppliers();
    }, [loadSuppliers])
  );

  const exactMatch = ingredients.some((i) => normalizeSearch(i.name) === normalizeSearch(search));

  function handleSelect(ingredient: Ingredient | 'new') {
    setSelected(ingredient);
    // Même unité que d'habitude pour cet ingrédient (sinon « kg » par défaut fausserait le prix
    // d'un ingrédient acheté à la pièce).
    setUnitWeight('');
    setUsedInGrams(false);
    setLastWeights({});
    if (ingredient !== 'new') {
      setUnit(ingredient.purchaseUnit);
      // Poids habituel de cette unité, et savoir si l'ingrédient sert déjà au gramme dans des recettes.
      getLastUnitWeight(db, ingredient.id, ingredient.purchaseUnit).then((w) => {
        if (w) {
          setLastWeights({ [ingredient.purchaseUnit]: w });
          setUnitWeight(String(w));
        }
      });
      listRecipesUsingIngredient(db, ingredient.id).then((rows) =>
        setUsedInGrams(rows.some((r) => r.unit === 'g' || r.unit === 'ml'))
      );
    }
  }

  function handleUnitChange(next: PurchaseUnit) {
    setUnit(next);
    const known = lastWeights[next];
    setUnitWeight(known ? String(known) : '');
  }

  function handleBackToSearch() {
    setSelected(null);
  }

  const canSave =
    !!selected &&
    !!supplierId &&
    date.trim().length > 0 &&
    parseFloat(price.replace(',', '.')) > 0 &&
    parseFloat(quantity.replace(',', '.')) > 0 &&
    !(usedInGrams && isCountUnit(unit) && !parseWeight(unitWeight)) &&
    (selected !== 'new' || search.trim().length > 0);

  const unitWeightG = asksUnitWeight(unit) ? parseWeight(unitWeight) : null;

  async function handleSave() {
    if (savingRef.current || !selected || !supplierId) return;
    // Après l'essai gratuit, la caisse reste utilisable : seul créer un NOUVEL ingrédient est bloqué.
    if (selected === 'new' && !guard()) return;
    if (selected !== 'new' && !(await confirmPurchaseUnit(db, selected.id, unit, unitWeightG, t))) return;
    savingRef.current = true;
    setSaving(true);
    try {
      await savePurchase(selected, supplierId);
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  }

  async function savePurchase(selected: Ingredient | 'new', supplierId: string) {
    const priceValue = parseFloat(price.replace(',', '.'));
    const quantityValue = parseFloat(quantity.replace(',', '.'));

    let ingredientId: string;
    if (selected === 'new') {
      ingredientId = await createIngredient(db, {
        name: search.trim(),
        purchasePrice: priceValue,
        purchaseQuantity: quantityValue,
        purchaseUnit: unit,
        vatRate: 0,
        categoryId: null,
        avgPieceWeightG: unitWeightG,
      });
    } else {
      ingredientId = selected.id;
    }

    await recordPurchase(db, {
      ingredientId,
      supplierId,
      purchaseDate: date.trim(),
      price: priceValue,
      quantity: quantityValue,
      unit,
      unitWeightG,
      note: note.trim() || null,
    });

    navigation.goBack();
  }

  if (!selected) {
    return (
      <ScreenContainer>
        <GradientHeaderBand title={t('Matière première')} onBack={() => navigation.goBack()} />
        <Text style={styles.introText}>
          {t(
            "Choisis l'ingrédient concerné — son prix sera mis à jour automatiquement pour tes recettes."
          )}
        </Text>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={18} color={colors.textMuted} />
          <TextInput
            style={styles.searchInput}
            placeholder={t('Rechercher un ingrédient...')}
            placeholderTextColor={colors.textMuted}
            value={search}
            onChangeText={setSearch}
            autoFocus
          />
        </View>
        <FlatList
          data={ingredients}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <Pressable style={styles.row} onPress={() => handleSelect(item)}>
              <Ionicons name="basket-outline" size={18} color={colors.textMuted} style={{ marginRight: spacing.sm }} />
              <Text style={styles.rowText}>{item.name}</Text>
            </Pressable>
          )}
          ListFooterComponent={
            search.trim().length > 0 && !exactMatch ? (
              <Pressable style={styles.newRow} onPress={() => handleSelect('new')}>
                <Ionicons name="add-circle-outline" size={18} color={accent} style={{ marginRight: spacing.sm }} />
                <Text style={[styles.rowText, { color: accent, fontWeight: '700' }]}>
                  {t('Créer "{name}" comme nouvel ingrédient', { name: search.trim() })}
                </Text>
              </Pressable>
            ) : null
          }
        />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <GradientHeaderBand title={t('Matière première')} onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <KeyboardAwareScrollView contentContainerStyle={styles.content}>
          <Pressable style={styles.backRow} onPress={handleBackToSearch}>
            <Ionicons name="chevron-back" size={18} color={colors.textMuted} />
            <Text style={styles.backText}>{t('Changer d\'ingrédient')}</Text>
          </Pressable>

          <Text style={styles.selectedName}>{selected === 'new' ? search.trim() : selected.name}</Text>
          {selected === 'new' && <Text style={styles.newBadge}>{t('Nouvel ingrédient')}</Text>}

          <FieldLabel>{t('Fournisseur')}</FieldLabel>
          <SupplierPicker
            suppliers={suppliers}
            selectedId={supplierId}
            onSelect={setSupplierId}
            onSuppliersChanged={setSuppliers}
          />

          <FieldLabel>{t("Date d'achat")}</FieldLabel>
          <DateField value={date} onChange={setDate} />

          <FieldLabel>{t('Prix payé ({currency})', { currency: getCurrencySymbol() })}</FieldLabel>
          <TextInput
            style={inputStyles.input}
            value={price}
            onChangeText={setPrice}
            keyboardType="decimal-pad"
            placeholder={t('ex: 45')}
          />

          <FieldLabel>{t('Quantité correspondante')}</FieldLabel>
          <TextInput
            style={inputStyles.input}
            value={quantity}
            onChangeText={setQuantity}
            keyboardType="decimal-pad"
            placeholder={t('ex: 500')}
          />

          <FieldLabel>{t('Unité')}</FieldLabel>
          <PurchaseUnitPicker value={unit} onChange={handleUnitChange} />
          <UnitWeightField
            unit={unit}
            value={unitWeight}
            onChange={setUnitWeight}
            required={usedInGrams && isCountUnit(unit)}
          />

          <FieldLabel>{t('Note (optionnel)')}</FieldLabel>
          <TextInput style={inputStyles.input} value={note} onChangeText={setNote} placeholder={t('ex: promotion')} />

          <PrimaryButton label={t('Enregistrer')} onPress={handleSave} disabled={!canSave || saving} style={styles.saveBtn} />
        </KeyboardAwareScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  introText: {
    fontSize: 13,
    color: colors.textMuted,
    padding: spacing.md,
    paddingBottom: spacing.sm,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
    paddingHorizontal: spacing.sm + 2,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: spacing.sm,
    fontSize: 15,
    color: colors.text,
  },
  listContent: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.xl,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  newRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderStyle: 'dashed',
  },
  rowText: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.text,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xl,
  },
  backRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  backText: {
    fontSize: 13,
    color: colors.textMuted,
    fontWeight: '600',
  },
  selectedName: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.text,
    marginBottom: 2,
  },
  newBadge: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.textMuted,
    marginBottom: spacing.md,
  },
  unitRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  unitBtn: {
    flex: 1,
    paddingVertical: spacing.sm + 2,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    backgroundColor: colors.surface,
  },
  unitBtnText: {
    color: colors.text,
    fontWeight: '600',
  },
  unitBtnTextActive: {
    color: '#fff',
  },
  saveBtn: {
    marginTop: spacing.lg,
  },
});
