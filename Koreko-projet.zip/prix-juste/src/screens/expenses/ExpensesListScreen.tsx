import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Alert } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import HintBanner from '../../components/common/HintBanner';
import SettingsHeaderButton from '../../navigation/SettingsHeaderButton';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { CashSummary, CategoryBreakdownRow, PurchaseUnit, Sale, SpendingEntry } from '../../types/models';
import {
  getCategoryBreakdownEntries,
  getMonthlyCategoryBreakdown,
  getMonthlyTotal,
  getSpendingFeed,
} from '../../db/repositories/expensesRepo';
import { getCashBalanceUntil, getMonthlyCashSummary, listSales } from '../../db/repositories/salesRepo';
import { formatMoney, formatQuantity, purchaseUnitLabel } from '../../utils/format';
import { ExpensesStackParamList } from '../../navigation/types';
import { formatDate, todayIso } from '../../utils/date';

type Nav = NativeStackNavigationProp<ExpensesStackParamList, 'ExpensesList'>;
type Segment = 'expenses' | 'sales';

function currentMonthPrefix(): string {
  return todayIso().slice(0, 7); // 'YYYY-MM'
}

// Premier jour du mois suivant ('AAAA-MM-01'), pour compter la caisse jusqu'à la fin d'un mois.
function nextMonthStart(monthPrefix: string): string {
  const [y, m] = monthPrefix.split('-').map(Number);
  return new Date(Date.UTC(y, m, 1)).toISOString().slice(0, 10);
}

function breakdownKey(row: CategoryBreakdownRow): string {
  return row.isIngredientPurchases ? `ing:${row.ingredientId ?? ''}` : row.categoryId ?? '__none';
}

function monthLabelFor(monthPrefix: string, locale: string): string {
  const [y, m] = monthPrefix.split('-').map(Number);
  const d = new Date(Date.UTC(y, m - 1, 1));
  return d.toLocaleDateString(locale, { month: 'long', year: 'numeric', timeZone: 'UTC' });
}

export default function ExpensesListScreen() {
  const db = useSQLiteContext();
  const navigation = useNavigation<Nav>();
  const { accent, accentDark } = useTheme();
  const { t, locale } = useI18n();
  const [segment, setSegment] = useState<Segment>('expenses');
  const [entries, setEntries] = useState<SpendingEntry[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [monthlyTotal, setMonthlyTotal] = useState(0);
  const [monthlySalesTotal, setMonthlySalesTotal] = useState(0);
  const [cashSummary, setCashSummary] = useState<CashSummary | null>(null);
  const [breakdown, setBreakdown] = useState<CategoryBreakdownRow[]>([]);
  const [showBreakdown, setShowBreakdown] = useState(false);
  // Catégorie du rapport ouverte pour voir le détail de ses enregistrements (une seule à la fois).
  const [openBreakdownKey, setOpenBreakdownKey] = useState<string | null>(null);
  const [openBreakdownEntries, setOpenBreakdownEntries] = useState<SpendingEntry[]>([]);
  // Dépenses, ventes et rapport : le mois choisi (par défaut le mois en cours), ou null = « Tout »
  // depuis le début. Le solde de caisse, lui, est TOUJOURS cumulé depuis le début (ce qu'il y a
  // vraiment dans la caisse), jusqu'à la fin du mois choisi.
  const [monthFilter, setMonthFilter] = useState<string | null>(() => currentMonthPrefix());
  const [cashBalance, setCashBalance] = useState(0);

  const load = useCallback(async () => {
    const pattern = monthFilter ?? ''; // '' = LIKE '%' = tout, voir le commentaire des fonctions du repo
    const [feed, total, categoryBreakdown, saleRows, summary, balance] = await Promise.all([
      getSpendingFeed(db, pattern),
      getMonthlyTotal(db, pattern),
      getMonthlyCategoryBreakdown(db, pattern),
      listSales(db, pattern),
      getMonthlyCashSummary(db, pattern),
      getCashBalanceUntil(db, monthFilter && monthFilter < currentMonthPrefix() ? nextMonthStart(monthFilter) : null),
    ]);
    setCashBalance(balance);
    setEntries(feed);
    setMonthlyTotal(total);
    setBreakdown(categoryBreakdown);
    setSales(saleRows);
    setMonthlySalesTotal(summary.totalSales);
    setCashSummary(summary);
    // Rafraîchit le détail ouvert (après modification d'une dépense ou changement de mois).
    const openRow = openBreakdownKey ? categoryBreakdown.find((r) => breakdownKey(r) === openBreakdownKey) : undefined;
    setOpenBreakdownEntries(openRow ? await getCategoryBreakdownEntries(db, pattern, openRow) : []);
  }, [db, monthFilter, openBreakdownKey]);

  function toggleBreakdownRow(row: CategoryBreakdownRow) {
    const key = breakdownKey(row);
    if (openBreakdownKey === key) {
      setOpenBreakdownKey(null);
      setOpenBreakdownEntries([]);
    } else {
      setOpenBreakdownEntries([]);
      setOpenBreakdownKey(key); // le chargement se fait dans load()
    }
  }

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  // useFocusEffect ne se redéclenche qu'au focus de l'écran, pas à chaque changement de
  // monthFilter pendant qu'on est déjà dessus (ex: en appuyant sur une flèche de mois) — ce
  // second effet couvre ce cas-là.
  useEffect(() => {
    load();
  }, [load]);

  function shiftMonth(delta: number) {
    const base = monthFilter ?? currentMonthPrefix();
    const [y, m] = base.split('-').map(Number);
    const d = new Date(Date.UTC(y, m - 1 + delta, 1));
    setMonthFilter(d.toISOString().slice(0, 7));
  }

  function handlePressEntry(entry: SpendingEntry) {
    if (entry.kind === 'expense') {
      navigation.navigate('ExpenseForm', { expenseId: entry.id });
    } else if (entry.ingredientId) {
      // Ingredient purchases live on the ingredient's own screen (in the
      // other tab) — they're shown here for visibility, not re-editable.
      const parent = navigation.getParent();
      parent?.navigate('IngredientsTab', {
        screen: 'IngredientForm',
        params: { ingredientId: entry.ingredientId, month: entry.date.slice(0, 7) },
      } as never);
    }
  }

  function handleAddExpense() {
    Alert.alert(t('Ajouter une dépense'), t("Est-ce l'achat d'une matière première (ingrédient de recette) ou une autre dépense ?"), [
      {
        text: t('Matière première'),
        onPress: () => navigation.navigate('MaterialPurchaseForm'),
      },
      {
        text: t('Autre dépense'),
        onPress: () => navigation.navigate('ExpenseForm', {}),
      },
      { text: t('Annuler'), style: 'cancel' },
    ]);
  }

  const balanceColor = cashBalance < 0 ? colors.danger : '#2e8b57';
  const isPastMonth = monthFilter !== null && monthFilter < currentMonthPrefix();

  const header = (
    <View>
      <View style={styles.periodRow}>
        <Pressable
          // Un 2e appui sur « Tout » revient au mois en cours.
          onPress={() => setMonthFilter((m) => (m === null ? currentMonthPrefix() : null))}
          style={[styles.periodChip, monthFilter === null && { backgroundColor: accent, borderColor: accent }]}
        >
          <Text style={[styles.periodChipText, monthFilter === null && styles.periodChipTextActive]}>{t('Tout')}</Text>
        </Pressable>
        <Pressable onPress={() => shiftMonth(-1)} hitSlop={8} style={styles.periodArrow}>
          <Ionicons name="chevron-back" size={18} color={accentDark} />
        </Pressable>
        <Text style={[styles.periodMonthLabel, monthFilter !== null && { color: accentDark }]}>
          {monthFilter !== null ? monthLabelFor(monthFilter, locale) : monthLabelFor(currentMonthPrefix(), locale)}
        </Text>
        <Pressable onPress={() => shiftMonth(1)} hitSlop={8} style={styles.periodArrow}>
          <Ionicons name="chevron-forward" size={18} color={accentDark} />
        </Pressable>
      </View>

      {cashSummary && (
        <View style={styles.cashBox}>
          <Text style={styles.cashLabel}>
            {isPastMonth
              ? t('Solde de caisse fin {month}', { month: monthLabelFor(monthFilter!, locale) })
              : t('Solde de caisse')}
          </Text>
          <Text style={[styles.cashAmount, { color: balanceColor }]}>{formatMoney(cashBalance)}</Text>
          {monthFilter !== null && (
            <Text style={styles.monthResult}>
              {t('Résultat de {month} :', { month: monthLabelFor(monthFilter, locale) })}{' '}
              <Text style={{ color: cashSummary.balance < 0 ? colors.danger : '#2e8b57', fontWeight: '700' }}>
                {cashSummary.balance > 0 ? '+' : ''}
                {formatMoney(cashSummary.balance)}
              </Text>
            </Text>
          )}
        </View>
      )}

      <Pressable
        style={[styles.segmentCard, segment === 'expenses' ? { backgroundColor: accent } : styles.segmentCardInactive]}
        onPress={() => setSegment('expenses')}
      >
        <Text style={[styles.segmentCardLabel, segment === 'expenses' && styles.segmentCardLabelActive]}>
          {t('Dépenses')}
        </Text>
        <Text numberOfLines={1} adjustsFontSizeToFit style={[styles.segmentCardAmount, segment === 'expenses' && styles.segmentCardAmountActive]}>
          {formatMoney(monthlyTotal)}
        </Text>
      </Pressable>

      <Pressable
        style={[styles.segmentCard, segment === 'sales' ? { backgroundColor: accent } : styles.segmentCardInactive]}
        onPress={() => setSegment('sales')}
      >
        <Text style={[styles.segmentCardLabel, segment === 'sales' && styles.segmentCardLabelActive]}>
          {t('Recettes')}
        </Text>
        <Text numberOfLines={1} adjustsFontSizeToFit style={[styles.segmentCardAmount, segment === 'sales' && styles.segmentCardAmountActive]}>
          {formatMoney(monthlySalesTotal)}
        </Text>
      </Pressable>

      {segment === 'expenses' && breakdown.length > 0 && (
        <Pressable style={styles.breakdownToggle} onPress={() => setShowBreakdown((v) => !v)}>
          <Text style={[styles.breakdownToggleText, { color: accentDark }]}>{t('Rapport par catégorie')}</Text>
          <Ionicons name={showBreakdown ? 'chevron-up' : 'chevron-down'} size={18} color={accentDark} />
        </Pressable>
      )}

      {segment === 'expenses' && showBreakdown && (
        <View style={styles.breakdownBox}>
          {breakdown.map((row) => {
            const key = breakdownKey(row);
            const isOpen = openBreakdownKey === key;
            return (
              <View key={key} style={styles.breakdownRow}>
                <Pressable onPress={() => toggleBreakdownRow(row)}>
                  <View style={styles.breakdownHeader}>
                    <Text style={styles.breakdownName}>
                      {row.isIngredientPurchases ? (
                        <Ionicons name="basket-outline" size={13} color={colors.textMuted} />
                      ) : null}
                      {row.isIngredientPurchases ? ' ' : ''}
                      {row.categoryName ?? t('Sans catégorie')}{' '}
                      <Text style={styles.breakdownCount}>({row.count})</Text>
                    </Text>
                    <Text style={styles.breakdownAmount}>{formatMoney(row.total)}</Text>
                    <Ionicons
                      name={isOpen ? 'chevron-up' : 'chevron-down'}
                      size={14}
                      color={colors.textMuted}
                      style={{ marginLeft: 4 }}
                    />
                  </View>
                  <View style={styles.breakdownBarTrack}>
                    <View
                      style={[
                        styles.breakdownBarFill,
                        { width: `${Math.min(row.percent, 100)}%`, backgroundColor: accent },
                      ]}
                    />
                  </View>
                </Pressable>
                {isOpen && (
                  <View style={styles.breakdownDetail}>
                    {openBreakdownEntries.map((entry) => (
                      <Pressable
                        key={entry.id}
                        style={styles.breakdownDetailRow}
                        onPress={() => handlePressEntry(entry)}
                      >
                        <View style={{ flex: 1 }}>
                          <Text style={styles.breakdownDetailMain}>
                            {formatDate(entry.date)}
                            {entry.label && entry.kind === 'expense' ? ` · ${entry.label}` : ''}
                            {entry.quantity != null && entry.unit
                              ? ` · ${formatQuantity(entry.quantity)} ${purchaseUnitLabel(entry.unit as PurchaseUnit, t)}`
                              : ''}
                            {entry.vatRate != null ? (
                              <Text style={{ fontWeight: '700', color: accentDark }}>
                                {` · ${t('TVA {rate} %', { rate: String(entry.vatRate) })}`}
                              </Text>
                            ) : null}
                          </Text>
                          {entry.kind === 'ingredientPurchase' && entry.categoryOrSupplier ? (
                            <Text style={styles.breakdownDetailNote}>{entry.categoryOrSupplier}</Text>
                          ) : null}
                          {entry.note?.trim() ? (
                            <Text style={[styles.breakdownDetailNote, { fontStyle: 'italic' }]}>{entry.note.trim()}</Text>
                          ) : null}
                        </View>
                        <Text style={[styles.breakdownDetailAmount, { color: accentDark }]}>
                          {formatMoney(entry.amount)}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                )}
              </View>
            );
          })}
        </View>
      )}
    </View>
  );

  if (segment === 'sales') {
    return (
      <ScreenContainer>
        <GradientHeaderBand title={t('Caisse')} right={<SettingsHeaderButton />} />
        <HintBanner
          id="expenses-intro"
          text={t("Note ici tes dépenses et tes ventes pour voir ton solde en un coup d'œil — touche un mois pour revoir son détail.")}
        />
        <FlatList
          data={sales}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          ListHeaderComponent={header}
          ListEmptyComponent={
            <Text style={styles.emptyText}>{t("Aucune recette enregistrée pour l'instant. Ajoute-en une avec le bouton +.")}</Text>
          }
          renderItem={({ item }) => (
            <Pressable style={styles.row} onPress={() => navigation.navigate('SaleForm', { saleId: item.id })}>
              <View style={{ flex: 1 }}>
                <Text style={styles.label}>{item.categoryName || item.note || t('Vente')}</Text>
                <Text style={styles.sub}>{formatDate(item.saleDate)}</Text>
                {item.categoryName && item.note?.trim() ? <Text style={styles.note}>{item.note.trim()}</Text> : null}
              </View>
              <Text style={[styles.amount, { color: '#2e8b57' }]}>{formatMoney(item.amount)}</Text>
            </Pressable>
          )}
        />
        <Pressable style={[styles.fab, { backgroundColor: accent }]} onPress={() => navigation.navigate('SaleForm', {})}>
          <Ionicons name="add" size={30} color="#fff" />
        </Pressable>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <GradientHeaderBand title={t('Caisse')} right={<SettingsHeaderButton />} />
      <HintBanner
        id="expenses-intro"
        text={t("Note ici tes dépenses et tes ventes pour voir ton solde en un coup d'œil — touche un mois pour revoir son détail.")}
      />
      <FlatList
        data={entries}
        keyExtractor={(item) => `${item.kind}-${item.id}`}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={header}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            {t("Aucune dépense enregistrée pour l'instant. Ajoute-en une avec le bouton +.")}
          </Text>
        }
        renderItem={({ item }) => (
          <Pressable style={styles.row} onPress={() => handlePressEntry(item)}>
            {item.kind === 'ingredientPurchase' && (
              <Ionicons name="basket-outline" size={16} color={colors.textMuted} style={{ marginRight: spacing.sm }} />
            )}
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>{item.label || t('Dépense')}</Text>
              <Text style={styles.sub}>
                {formatDate(item.date)}
                {item.categoryOrSupplier ? ` · ${item.categoryOrSupplier}` : ''}
              </Text>
              {/* La note (ex: à qui le salaire a été versé) visible sans ouvrir la dépense. */}
              {item.note?.trim() ? <Text style={styles.note}>{item.note.trim()}</Text> : null}
            </View>
            <Text style={[styles.amount, { color: accentDark }]}>{formatMoney(item.amount)}</Text>
          </Pressable>
        )}
      />

      <Pressable style={[styles.fab, { backgroundColor: accent }]} onPress={handleAddExpense}>
        <Ionicons name="add" size={30} color="#fff" />
      </Pressable>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  periodRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    gap: spacing.sm,
  },
  periodChip: {
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  periodChipText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.text,
  },
  periodChipTextActive: {
    color: '#fff',
  },
  periodArrow: {
    padding: 4,
  },
  periodMonthLabel: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textMuted,
    minWidth: 120,
    textAlign: 'center',
    textTransform: 'capitalize',
  },
  cashBox: {
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    marginBottom: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.lg,
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cashLabel: {
    color: colors.textMuted,
    fontSize: 12,
    fontWeight: '600',
  },
  monthResult: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 4,
  },
  cashAmount: {
    fontSize: 24,
    fontWeight: '800',
    marginTop: 2,
  },
  segmentCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.lg,
  },
  segmentCardInactive: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  segmentCardLabel: {
    marginRight: spacing.md,
    fontSize: 15,
    fontWeight: '700',
    color: colors.text,
  },
  segmentCardLabelActive: {
    color: '#fff',
  },
  segmentCardAmount: {
    flexShrink: 1,
    fontSize: 20,
    fontWeight: '800',
    color: colors.text,
  },
  segmentCardAmountActive: {
    color: '#fff',
  },
  breakdownToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
    paddingVertical: spacing.xs,
  },
  breakdownToggleText: {
    fontSize: 13,
    fontWeight: '700',
    marginRight: 4,
  },
  breakdownBox: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  breakdownRow: {
    marginBottom: spacing.sm,
  },
  breakdownHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  breakdownName: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.text,
    flex: 1,
    marginRight: spacing.sm,
  },
  breakdownCount: {
    color: colors.textMuted,
    fontWeight: '400',
  },
  breakdownAmount: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.text,
  },
  breakdownDetail: {
    marginTop: spacing.xs,
    marginLeft: spacing.sm,
    paddingLeft: spacing.sm,
    borderLeftWidth: 2,
    borderLeftColor: colors.border,
  },
  breakdownDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  breakdownDetailMain: {
    fontSize: 12,
    color: colors.text,
  },
  breakdownDetailNote: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 1,
  },
  breakdownDetailAmount: {
    fontSize: 13,
    fontWeight: '700',
    marginLeft: spacing.sm,
  },
  breakdownBarTrack: {
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.surfaceAlt,
    overflow: 'hidden',
  },
  breakdownBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  listContent: {
    paddingHorizontal: spacing.md,
    paddingBottom: 100,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  label: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.text,
  },
  sub: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  note: {
    fontSize: 13,
    color: colors.text,
    fontStyle: 'italic',
    marginTop: 2,
  },
  amount: {
    fontSize: 14,
    fontWeight: '700',
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginTop: spacing.xl,
    fontSize: 15,
  },
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: spacing.lg,
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
});
