import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Alert, Share } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useSQLiteContext } from 'expo-sqlite';
import { Ionicons } from '@expo/vector-icons';
import ScreenContainer from '../../components/common/ScreenContainer';
import GradientHeaderBand from '../../components/common/GradientHeaderBand';
import HintBanner from '../../components/common/HintBanner';
import SettingsHeaderButton from '../../navigation/SettingsHeaderButton';
import AddShoppingListItemModal from '../../components/shoppingList/AddShoppingListItemModal';
import EditShoppingListItemModal from '../../components/shoppingList/EditShoppingListItemModal';
import SupplierSuggestionsModal from '../../components/shoppingList/SupplierSuggestionsModal';
import PromptModal from '../../components/common/PromptModal';
import { colors, radius, spacing } from '../../theme/colors';
import { useTheme } from '../../theme/ThemeContext';
import { useI18n } from '../../i18n/I18nContext';
import { Ingredient, ShoppingListItem, Supplier, SupplierIngredientSuggestion } from '../../types/models';
import { listIngredients } from '../../db/repositories/ingredientsRepo';
import { createSupplier, listSuppliers } from '../../db/repositories/suppliersRepo';
import { listSupplierIngredientSuggestions } from '../../db/repositories/ingredientPurchasesRepo';
import {
  addToShoppingList,
  listShoppingListItems,
  removeShoppingListItem,
  clearShoppingList,
  removeCheckedItems,
  setShoppingListItemChecked,
  updateShoppingListItem,
} from '../../db/repositories/shoppingListRepo';
import { formatMoney, purchaseUnitLabel } from '../../utils/format';

const NO_SUPPLIER_KEY = '__none__';
const ALL_KEY = '__all__';

interface SupplierGroup {
  key: string;
  supplierId: string | null;
  name: string;
  items: ShoppingListItem[];
}

export default function ShoppingListScreen() {
  const db = useSQLiteContext();
  const { accent, accentDark } = useTheme();
  const { t } = useI18n();

  const [items, setItems] = useState<ShoppingListItem[]>([]);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [selectedGroupKey, setSelectedGroupKey] = useState<string | null>(null);
  const [addVisible, setAddVisible] = useState(false);
  const [addSupplierVisible, setAddSupplierVisible] = useState(false);
  const [editingItem, setEditingItem] = useState<ShoppingListItem | null>(null);
  const [onlyChecked, setOnlyChecked] = useState(false);
  const [suggestionsVisible, setSuggestionsVisible] = useState(false);
  const [suggestions, setSuggestions] = useState<SupplierIngredientSuggestion[]>([]);

  const load = useCallback(async () => {
    const [itemRows, ingredientRows, supplierRows] = await Promise.all([
      listShoppingListItems(db),
      listIngredients(db),
      listSuppliers(db),
    ]);
    setItems(itemRows);
    setIngredients(ingredientRows);
    setSuppliers(supplierRows);
  }, [db]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  // Un onglet par fournisseur existant — même sans encore aucun article dedans — pour que tu
  // puisses toujours voir tous tes fournisseurs et y naviguer, comme dans Listy. Un onglet
  // "Sans fournisseur" s'ajoute seulement s'il y a réellement des articles non assignés.
  const groups = useMemo<SupplierGroup[]>(() => {
    const map = new Map<string, SupplierGroup>();
    for (const s of suppliers) {
      map.set(s.id, { key: s.id, supplierId: s.id, name: s.name, items: [] });
    }
    for (const item of items) {
      const key = item.supplierId ?? NO_SUPPLIER_KEY;
      if (!map.has(key)) {
        map.set(key, {
          key,
          supplierId: item.supplierId,
          name: item.supplierName ?? t('Sans fournisseur'),
          items: [],
        });
      }
      map.get(key)!.items.push(item);
    }
    const result = Array.from(map.values());
    result.sort((a, b) => {
      if (a.key === NO_SUPPLIER_KEY) return 1;
      if (b.key === NO_SUPPLIER_KEY) return -1;
      return a.name.localeCompare(b.name);
    });
    // Onglet "Tout" : toute la liste d'un coup, triée par magasin, pour voir ce qui est déjà noté
    // sans devoir ouvrir chaque fournisseur.
    const allItems = [...items].sort((a, b) => {
      if (!a.supplierId !== !b.supplierId) return a.supplierId ? -1 : 1;
      const bySupplier = (a.supplierName ?? '').localeCompare(b.supplierName ?? '');
      return bySupplier !== 0 ? bySupplier : a.ingredientName.localeCompare(b.ingredientName);
    });
    return [{ key: ALL_KEY, supplierId: null, name: t('Tout'), items: allItems }, ...result];
  }, [items, suppliers, t]);

  useEffect(() => {
    if (groups.length === 0) {
      setSelectedGroupKey(null);
      return;
    }
    if (!groups.some((g) => g.key === selectedGroupKey)) {
      setSelectedGroupKey(groups[0].key);
    }
  }, [groups, selectedGroupKey]);

  const activeGroup = groups.find((g) => g.key === selectedGroupKey) ?? null;
  const checkedCount = activeGroup?.items.filter((i) => i.checked).length ?? 0;
  const estimatedTotal = activeGroup?.items.reduce((sum, i) => sum + (i.estimatedPrice ?? 0), 0) ?? 0;
  const hasUnknownPrice = activeGroup?.items.some((i) => i.estimatedPrice == null) ?? false;

  async function handleAddSubmit(data: { ingredientId: string; quantity: number; unit: ShoppingListItem['unit'] }) {
    setAddVisible(false);
    // L'article va chez le fournisseur dont l'onglet est ouvert (sinon : le moins cher connu).
    await addToShoppingList(db, { ...data, supplierId: activeGroup?.supplierId ?? undefined });
    await load();
  }

  // Propose tout ce qui a déjà été acheté chez ce fournisseur par le passé, pour ne rien
  // oublier au moment de faire les courses là-bas.
  async function handleOpenSuggestions() {
    if (!activeGroup?.supplierId) return;
    setSuggestions(await listSupplierIngredientSuggestions(db, activeGroup.supplierId));
    setSuggestionsVisible(true);
  }

  async function handleAddSuggestion(suggestion: SupplierIngredientSuggestion) {
    if (!activeGroup?.supplierId) return;
    await addToShoppingList(db, {
      ingredientId: suggestion.ingredientId,
      quantity: suggestion.lastQuantity,
      unit: suggestion.lastUnit,
      supplierId: activeGroup.supplierId,
    });
    await load();
  }

  async function handleAddSupplier(name: string) {
    setAddSupplierVisible(false);
    const id = await createSupplier(db, name);
    await load();
    setSelectedGroupKey(id);
  }

  async function handleToggle(item: ShoppingListItem) {
    await setShoppingListItemChecked(db, item.id, !item.checked);
    await load();
  }

  async function handleEditSubmit(data: { quantity: number; unit: ShoppingListItem['unit']; supplierId: string | null }) {
    if (!editingItem) return;
    setEditingItem(null);
    await updateShoppingListItem(db, editingItem.id, data);
    await load();
  }

  function handleDelete() {
    if (!editingItem) return;
    const id = editingItem.id;
    setEditingItem(null);
    Alert.alert(t('Retirer cet article ?'), undefined, [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Retirer'),
        style: 'destructive',
        onPress: async () => {
          await removeShoppingListItem(db, id);
          await load();
        },
      },
    ]);
  }

  // Partage la liste du fournisseur affiché en texte simple via la feuille de partage du
  // téléphone (WhatsApp, mail, SMS...). Les articles cochés sont ceux à commander ; les non
  // cochés ne partent pas.
  async function handleShare() {
    if (!activeGroup) return;
    const shared = activeGroup.items.filter((i) => i.checked);
    if (shared.length === 0) {
      Alert.alert(t('Rien à partager'), t('Coche les articles à commander, puis partage la liste.'));
      return;
    }
    const formatLine = (i: ShoppingListItem) => `- ${i.ingredientName} : ${i.quantity} ${purchaseUnitLabel(i.unit, t)}`;
    let message: string;
    if (activeGroup.key === ALL_KEY) {
      const bySupplier = new Map<string, ShoppingListItem[]>();
      for (const i of shared) {
        const supplier = i.supplierName ?? t('Sans fournisseur');
        bySupplier.set(supplier, [...(bySupplier.get(supplier) ?? []), i]);
      }
      const sections = Array.from(bySupplier.entries()).map(
        ([supplier, list]) => `${supplier}\n${list.map(formatLine).join('\n')}`
      );
      message = `${t('Liste de courses')}\n\n${sections.join('\n\n')}`;
    } else {
      message = `${t('Liste de courses')} — ${activeGroup.name}\n\n${shared.map(formatLine).join('\n')}`;
    }
    try {
      await Share.share({ message });
    } catch {
      Alert.alert(t('Erreur'), t("Impossible de partager la liste."));
    }
  }

  // Efface ce qui a été trouvé au magasin (coché) — garde ce qui manquait (non coché), pour ne
  // pas l'oublier au prochain passage. Fonctionne aussi sur "Tout" (contrairement à
  // Réinitialiser) puisqu'elle ne touche jamais à ce qui n'est pas coché.
  function handleClearBought() {
    if (!activeGroup) return;
    const boughtCount = activeGroup.items.filter((i) => i.checked).length;
    if (boughtCount === 0) {
      Alert.alert(t('Rien à effacer'), t("Coche d'abord ce que tu as trouvé au magasin."));
      return;
    }
    Alert.alert(
      t('Effacer les achetés ?'),
      t('{count} article(s) coché(s) seront retirés de la liste. Ce qui n\'est pas coché reste.', {
        count: boughtCount,
      }),
      [
        { text: t('Annuler'), style: 'cancel' },
        {
          text: t('Effacer'),
          style: 'destructive',
          onPress: async () => {
            await removeCheckedItems(db, activeGroup.key === ALL_KEY ? 'all' : activeGroup.supplierId);
            await load();
          },
        },
      ]
    );
  }

  function handleReset() {
    if (!activeGroup || activeGroup.key === ALL_KEY) return;
    Alert.alert(t('Réinitialiser la liste ?'), t('Tous les ingrédients de {supplier} seront retirés de la liste.', { supplier: activeGroup.name }), [
      { text: t('Annuler'), style: 'cancel' },
      {
        text: t('Réinitialiser'),
        style: 'destructive',
        onPress: async () => {
          await clearShoppingList(db, activeGroup.supplierId);
          await load();
        },
      },
    ]);
  }

  return (
    <ScreenContainer>
      <GradientHeaderBand title={t('Liste de courses')} right={<SettingsHeaderButton />} />
      <HintBanner
        id="shopping-list-intro"
        text={t('Ajoute ce qui te manque avec le bouton +, coche ce que tu commandes, puis partage la liste au magasin.')}
      />
      <FlatList
        horizontal
        data={groups}
        keyExtractor={(g) => g.key}
        showsHorizontalScrollIndicator={false}
        style={styles.tabsList}
        contentContainerStyle={styles.tabsContent}
        renderItem={({ item: g }) => {
          const active = g.key === selectedGroupKey;
          return (
            <Pressable
              onPress={() => setSelectedGroupKey(g.key)}
              style={[styles.tab, active && { backgroundColor: accent, borderColor: accent }]}
            >
              <Text style={[styles.tabText, active && styles.tabTextActive]}>
                {g.name} · {g.items.length}
              </Text>
            </Pressable>
          );
        }}
        ListFooterComponent={
          <Pressable style={styles.addTab} onPress={() => setAddSupplierVisible(true)}>
            <Ionicons name="add" size={16} color={colors.textMuted} />
            <Text style={styles.addTabText}>{t('Nouveau fournisseur')}</Text>
          </Pressable>
        }
      />

      {activeGroup && (
        <View style={styles.groupHeader}>
          <View style={{ flex: 1 }}>
            <Text style={styles.groupTitle}>{activeGroup.name}</Text>
            <Text style={styles.groupCount}>
              {t('{checked} / {total} cochés', { checked: checkedCount, total: activeGroup.items.length })}
            </Text>
          </View>
        </View>
      )}

      {activeGroup && (
        <View style={styles.actionsRow}>
          <Pressable onPress={() => setOnlyChecked((v) => !v)} hitSlop={8} style={styles.resetBtn}>
            <Ionicons name={onlyChecked ? 'eye-outline' : 'funnel-outline'} size={16} color={accentDark} />
            <Text style={[styles.resetText, { color: accentDark }]}>
              {onlyChecked ? t('Tout afficher') : t('Cochés seulement')}
            </Text>
          </Pressable>
          {activeGroup.supplierId && (
            <Pressable onPress={handleOpenSuggestions} hitSlop={8} style={styles.resetBtn}>
              <Ionicons name="sparkles-outline" size={16} color={accentDark} />
              <Text style={[styles.resetText, { color: accentDark }]}>{t('Mes habitudes')}</Text>
            </Pressable>
          )}
          <Pressable onPress={handleShare} hitSlop={8} style={styles.resetBtn}>
            <Ionicons name="share-social-outline" size={16} color={accentDark} />
            <Text style={[styles.resetText, { color: accentDark }]}>{t('Partager')}</Text>
          </Pressable>
          <Pressable onPress={handleClearBought} hitSlop={8} style={styles.resetBtn}>
            <Ionicons name="checkmark-done-outline" size={16} color={accentDark} />
            <Text style={[styles.resetText, { color: accentDark }]}>{t('Effacer les achetés')}</Text>
          </Pressable>
          {activeGroup.key !== ALL_KEY && (
            <Pressable onPress={handleReset} hitSlop={8} style={styles.resetBtn}>
              <Ionicons name="refresh" size={16} color={accentDark} />
              <Text style={[styles.resetText, { color: accentDark }]}>{t('Réinitialiser')}</Text>
            </Pressable>
          )}
        </View>
      )}

      {activeGroup && activeGroup.items.length > 0 && (
        <View style={styles.totalBox}>
          <Text style={[styles.totalText, { color: accentDark }]}>
            {t('Total estimé : ~{total}', { total: formatMoney(estimatedTotal) })}
          </Text>
          {hasUnknownPrice && <Text style={styles.totalHint}>{t('Certains prix ne sont pas encore connus.')}</Text>}
        </View>
      )}

      <FlatList
        data={(activeGroup?.items ?? []).filter((i) => !onlyChecked || i.checked)}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            {items.length === 0
              ? t('Ta liste de courses est vide. Ajoute un article avec le bouton +.')
              : t('Aucun article pour ce fournisseur.')}
          </Text>
        }
        renderItem={({ item }) => (
          <View style={styles.row}>
            {activeGroup?.key === ALL_KEY && (
              <Text style={[styles.rowSupplier, { color: accentDark }]} numberOfLines={2}>
                {item.supplierName ?? t('Sans fournisseur')}
              </Text>
            )}
            <Pressable
              onPress={() => handleToggle(item)}
              hitSlop={8}
              style={[styles.checkbox, item.checked && { backgroundColor: colors.success, borderColor: colors.success }]}
            >
              {item.checked && <Ionicons name="checkmark" size={18} color="#fff" />}
            </Pressable>
            <Pressable style={{ flex: 1 }} onPress={() => handleToggle(item)}>
              {/* Coché = à commander : la case suffit, le nom n'est pas barré (il faut cocher pour partager). */}
              <Text style={styles.itemName}>{item.ingredientName}</Text>
              <Text style={styles.itemQty}>
                {item.quantity} {purchaseUnitLabel(item.unit, t)}
                {item.estimatedPrice != null ? ` · ${formatMoney(item.estimatedPrice)}` : ''}
              </Text>
            </Pressable>
            <Pressable onPress={() => setEditingItem(item)} hitSlop={8} style={{ padding: spacing.xs }}>
              <Ionicons name="pencil-outline" size={18} color={colors.textMuted} />
            </Pressable>
          </View>
        )}
      />

      <Pressable style={[styles.fab, { backgroundColor: accent }]} onPress={() => setAddVisible(true)}>
        <Ionicons name="add" size={30} color="#fff" />
      </Pressable>

      <AddShoppingListItemModal
        visible={addVisible}
        ingredients={ingredients}
        onSubmit={handleAddSubmit}
        onCancel={() => setAddVisible(false)}
      />
      <EditShoppingListItemModal
        visible={!!editingItem}
        item={editingItem}
        suppliers={suppliers}
        onSuppliersChanged={setSuppliers}
        onSubmit={handleEditSubmit}
        onDelete={handleDelete}
        onCancel={() => setEditingItem(null)}
      />
      <PromptModal
        visible={addSupplierVisible}
        title={t('Nouveau fournisseur')}
        placeholder={t('ex: Mon grossiste')}
        onSubmit={handleAddSupplier}
        onCancel={() => setAddSupplierVisible(false)}
      />
      <SupplierSuggestionsModal
        visible={suggestionsVisible}
        supplierName={activeGroup?.name ?? ''}
        suggestions={suggestions}
        alreadyAddedIds={new Set((activeGroup?.items ?? []).map((i) => i.ingredientId))}
        onAdd={handleAddSuggestion}
        onClose={() => setSuggestionsVisible(false)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  tabsList: {
    flexGrow: 0,
    marginTop: spacing.md,
  },
  tabsContent: {
    paddingHorizontal: spacing.md,
    gap: spacing.sm,
  },
  tab: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  tabText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.text,
  },
  tabTextActive: {
    color: '#fff',
  },
  addTab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderStyle: 'dashed',
  },
  addTabText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textMuted,
    marginLeft: 2,
  },
  groupHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    marginTop: spacing.md,
  },
  groupTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  groupCount: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
  },
  actionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: spacing.sm,
  },
  rowSupplier: {
    width: 92,
    fontSize: 12.5,
    fontWeight: '700',
    marginRight: spacing.sm,
  },
  resetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  resetText: {
    fontSize: 12,
    fontWeight: '700',
  },
  totalBox: {
    marginHorizontal: spacing.md,
    marginTop: spacing.sm,
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.sm,
    padding: spacing.sm,
  },
  totalText: {
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
  },
  totalHint: {
    fontSize: 11,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: 2,
  },
  listContent: {
    padding: spacing.md,
    paddingBottom: 100,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  checkbox: {
    width: 26,
    height: 26,
    borderRadius: radius.sm,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
    backgroundColor: colors.surfaceAlt,
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  itemNameChecked: {
    textDecorationLine: 'line-through',
    color: colors.textMuted,
  },
  itemQty: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 2,
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textMuted,
    marginTop: spacing.xl,
    fontSize: 15,
  },
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: spacing.lg,
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
});
