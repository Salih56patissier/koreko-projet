import { ProcessAction, RecipeFull } from '../types/models';
import { formatQuantity, formatWeight, unitLabel } from '../utils/format';
import { totalWeightGrams } from '../utils/priceCalc';

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function generateRecipeHtml(
  recipe: RecipeFull,
  categoryName: string,
  processActions: ProcessAction[],
  t?: (key: string, vars?: Record<string, string | number>) => string
): string {
  const tagLookup = new Map(processActions.map((a) => [a.id, a]));

  const groupsHtml = recipe.groups
    .map((group, index) => {
      const tags = group.processTagIds
        .map((id) => tagLookup.get(id))
        .filter((a): a is ProcessAction => !!a)
        .filter((a) => a.name.trim().toLowerCase() !== group.name.trim().toLowerCase())
        .map(
          (a) =>
            `<span class="tag" style="color:${a.color};border-color:${a.color};background:${a.color}1a">${escapeHtml(
              a.name
            )}</span>`
        )
        .join('');

      const itemsHtml = group.items
        .map(
          (item) =>
            `<li>${escapeHtml(item.name)} — ${formatQuantity(item.quantity)} ${unitLabel(item.unit, t)}${
              item.note ? ` <span class="note">(${escapeHtml(item.note)})</span>` : ''
            }</li>`
        )
        .join('');

      return `
        <section class="group">
          <div class="group-header">
            <span class="group-number">${index + 1}</span>
            <h2>${escapeHtml(group.name)}</h2>
          </div>
          ${tags ? `<div class="tags">${tags}</div>` : ''}
          ${group.instruction ? `<p class="instruction">${escapeHtml(group.instruction)}</p>` : ''}
          ${itemsHtml ? `<ul class="items">${itemsHtml}</ul>` : ''}
        </section>
      `;
    })
    .join('');

  // Une seule page A4, remplie au maximum : on cherche la plus grande taille de texte qui tient.
  // Hauteur estimée en « em » (1 em = taille du texte) ; ~1000 px utiles sur la page.
  function estimatedHeightEm(fontPx: number): number {
    const charsPerLine = 690 / (0.52 * fontPx);
    let h = 4.2; // titre + poids
    for (const g of recipe.groups) {
      h += 2.9; // titre d'étape + espace
      if (g.processTagIds.length > 0) h += 1.6;
      if (g.instruction) h += Math.ceil(g.instruction.length / (charsPerLine - 4)) * 1.5 + 0.4;
      h += g.items.length * 1.65;
    }
    return h;
  }
  let base = 8;
  for (let px = 34; px >= 8; px -= 0.5) {
    if (estimatedHeightEm(px) * px <= 960) {
      base = px;
      break;
    }
  }
  const weightG = totalWeightGrams(recipe.groups);
  const weightHtml =
    weightG > 0
      ? `<div class="weight">${escapeHtml(
          t ? t('Poids total : {weight}', { weight: formatWeight(weightG) }) : `Poids total : ${formatWeight(weightG)}`
        )}</div>`
      : '';
  const title = categoryName ? `${categoryName} · ${recipe.name}` : recipe.name;

  return `
    <html>
      <head>
        <meta charset="utf-8" />
        <style>
          @page { size: A4; margin: 14mm; }
          body {
            font-family: -apple-system, Helvetica, Arial, sans-serif;
            color: #2b2118;
            margin: 0;
            font-size: ${base}px;
          }
          .header {
            text-align: center;
            border-bottom: 3px solid #c9852f;
            padding-bottom: 0.4em;
            margin-bottom: 0.7em;
          }
          h1 { font-size: 1.7em; text-transform: uppercase; margin: 0; line-height: 1.15; }
          .weight { margin-top: 0.3em; font-weight: 600; font-size: 1.1em; color: #6b5a47; }
          .group { margin-bottom: 0.9em; page-break-inside: avoid; }
          .group-header { display: flex; align-items: center; gap: 0.5em; }
          .group-number {
            display: inline-block;
            width: 1.7em; height: 1.7em; line-height: 1.7em; text-align: center;
            border-radius: 50%;
            background: #c9852f; color: white; font-weight: 700; font-size: 1em;
            flex-shrink: 0;
          }
          .group h2 { font-size: 1.35em; margin: 0; }
          .tags { margin: 0.2em 0 0.1em 2.3em; }
          .tag {
            display: inline-block; font-size: 0.8em; font-weight: 700;
            border: 1px solid; border-radius: 999px; padding: 1px 0.6em; margin-right: 0.4em;
          }
          .instruction { margin: 0.25em 0 0.25em 2.3em; line-height: 1.4; }
          .items { margin: 0.2em 0 0 2.3em; padding-left: 1.2em; line-height: 1.55; }
          .note { color: #8a7a68; font-style: italic; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>${escapeHtml(title)}</h1>
          ${weightHtml}
        </div>
        ${groupsHtml}
      </body>
    </html>
  `;
}
