export interface AccentTheme {
  id: string;
  name: string;
  accent: string;
  accentDark: string;
}

// Palette flashy validée avec l'utilisatrice (2026-09) — remplace l'ancienne palette
// terreuse (caramel/terracotta/sauge...) jugée "moche" et trop proche du dégradé
// orange/turquoise du logo Koreko.
export const ACCENT_THEMES: AccentTheme[] = [
  { id: 'fuchsia', name: 'Fuchsia', accent: '#f0327a', accentDark: '#c41f5e' },
  { id: 'violet', name: 'Violet électrique', accent: '#8b3ce0', accentDark: '#6f28ba' },
  { id: 'bleu', name: 'Bleu électrique', accent: '#1f6feb', accentDark: '#1552b8' },
  { id: 'vert', name: 'Vert vif', accent: '#00c853', accentDark: '#00963e' },
  { id: 'orange', name: 'Orange flashy', accent: '#ffab00', accentDark: '#cc8800' },
  { id: 'rouge', name: 'Rouge corail', accent: '#e8382f', accentDark: '#c22318' },
  { id: 'turquoise', name: 'Turquoise vif', accent: '#00d9c8', accentDark: '#00a99b' },
  { id: 'rose', name: 'Rose bonbon', accent: '#ff7ab6', accentDark: '#e0558f' },
];

export const DEFAULT_ACCENT_THEME_ID = 'fuchsia';

export function getAccentTheme(id: string): AccentTheme {
  return ACCENT_THEMES.find((t) => t.id === id) ?? ACCENT_THEMES[0];
}
