// `accent`/`accentDark` here are only the fallback defaults used before the
// theme is loaded from settings (e.g. very first frame). Everywhere in the
// app that needs the *current* accent color must use useTheme() instead,
// since these two are frozen at bundle-eval time and never change.
export const colors = {
  background: '#faf6f1',
  surface: '#ffffff',
  surfaceAlt: '#f2e9de',
  accent: '#c9852f',
  accentDark: '#a8681f',
  text: '#3a2e22',
  textMuted: '#8a7a68',
  border: '#e8ddcf',
  danger: '#c0392b',
  dangerBg: '#fbeae7',
  success: '#3f7d4f',
  successBg: '#eaf5ec',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 20,
  pill: 999,
};

// Deterministic color assignment for process action badges.
export const processTagPalette = [
  '#c9852f', // caramel
  '#8a6fb0', // violet
  '#4f8f7a', // sauge
  '#c0554b', // brique
  '#4a7fb5', // bleu
  '#b5834a', // terracotta clair
  '#6f8f4a', // olive
  '#a05a8c', // prune
];

export function colorForIndex(index: number): string {
  return processTagPalette[index % processTagPalette.length];
}
