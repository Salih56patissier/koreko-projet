import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useSQLiteContext } from 'expo-sqlite';
import { getSettings, updateAccentTheme } from '../db/repositories/settingsRepo';
import { ACCENT_THEMES, AccentTheme, DEFAULT_ACCENT_THEME_ID, getAccentTheme } from './accentThemes';

interface ThemeContextValue {
  accent: string;
  accentDark: string;
  themeId: string;
  themes: AccentTheme[];
  setAccentThemeId: (id: string) => void;
}

const ThemeContext = createContext<ThemeContextValue>({
  accent: getAccentTheme(DEFAULT_ACCENT_THEME_ID).accent,
  accentDark: getAccentTheme(DEFAULT_ACCENT_THEME_ID).accentDark,
  themeId: DEFAULT_ACCENT_THEME_ID,
  themes: ACCENT_THEMES,
  setAccentThemeId: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const db = useSQLiteContext();
  const [themeId, setThemeId] = useState(DEFAULT_ACCENT_THEME_ID);

  useEffect(() => {
    getSettings(db).then((s) => setThemeId(s.accentThemeId));
  }, [db]);

  const setAccentThemeId = useCallback(
    (id: string) => {
      setThemeId(id);
      updateAccentTheme(db, id);
    },
    [db]
  );

  const theme = getAccentTheme(themeId);

  return (
    <ThemeContext.Provider
      value={{ accent: theme.accent, accentDark: theme.accentDark, themeId, themes: ACCENT_THEMES, setAccentThemeId }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme(): ThemeContextValue {
  return useContext(ThemeContext);
}
