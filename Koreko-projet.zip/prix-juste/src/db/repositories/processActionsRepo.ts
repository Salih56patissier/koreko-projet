import { type SQLiteDatabase } from 'expo-sqlite';
import { ProcessAction } from '../../types/models';
import { newId } from '../../utils/uuid';
import { colorForIndex } from '../../theme/colors';

interface ProcessActionRow {
  id: string;
  name: string;
  color: string;
  is_custom: number;
  created_at: string;
}

function mapRow(row: ProcessActionRow): ProcessAction {
  return {
    id: row.id,
    name: row.name,
    color: row.color,
    isCustom: row.is_custom === 1,
    createdAt: row.created_at,
  };
}

export async function listProcessActions(db: SQLiteDatabase): Promise<ProcessAction[]> {
  const rows = await db.getAllAsync<ProcessActionRow>(
    'SELECT * FROM process_actions ORDER BY is_custom ASC, created_at ASC'
  );
  return rows.map(mapRow);
}

export async function createCustomProcessAction(db: SQLiteDatabase, name: string): Promise<string> {
  const id = newId();
  const now = new Date().toISOString();
  const count = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM process_actions');
  const color = colorForIndex(count?.count ?? 0);
  await db.runAsync(
    'INSERT INTO process_actions (id, name, color, is_custom, created_at) VALUES (?, ?, ?, 1, ?)',
    [id, name, color, now]
  );
  return id;
}

export async function updateProcessAction(db: SQLiteDatabase, id: string, name: string): Promise<void> {
  await db.runAsync('UPDATE process_actions SET name = ? WHERE id = ?', [name, id]);
}

// Porte la liste des recettes concernées (via recipeNames) pour que l'écran puisse dire
// précisément où l'action est utilisée, plutôt qu'un message générique.
export class ProcessActionInUseError extends Error {
  recipeNames: string[];
  constructor(recipeNames: string[]) {
    super('ProcessActionInUse');
    this.recipeNames = recipeNames;
  }
}

export async function deleteProcessAction(db: SQLiteDatabase, id: string): Promise<void> {
  const rows = await db.getAllAsync<{ name: string }>(
    `SELECT DISTINCT r.name FROM recipe_group_process_tags rgpt
     JOIN recipe_groups rg ON rg.id = rgpt.group_id
     JOIN recipes r ON r.id = rg.recipe_id
     WHERE rgpt.process_action_id = ?`,
    [id]
  );
  if (rows.length > 0) {
    throw new ProcessActionInUseError(rows.map((r) => r.name));
  }
  await db.runAsync('DELETE FROM process_actions WHERE id = ?', [id]);
}
