import { type SQLiteDatabase } from 'expo-sqlite';
import { Supplier } from '../../types/models';
import { newId } from '../../utils/uuid';

interface SupplierRow {
  id: string;
  name: string;
  created_at: string;
}

function mapRow(row: SupplierRow): Supplier {
  return { id: row.id, name: row.name, createdAt: row.created_at };
}

export async function listSuppliers(db: SQLiteDatabase): Promise<Supplier[]> {
  const rows = await db.getAllAsync<SupplierRow>('SELECT * FROM suppliers ORDER BY name ASC');
  return rows.map(mapRow);
}

export async function createSupplier(db: SQLiteDatabase, name: string): Promise<string> {
  const id = newId();
  await db.runAsync('INSERT INTO suppliers (id, name, created_at) VALUES (?, ?, ?)', [
    id,
    name,
    new Date().toISOString(),
  ]);
  return id;
}

export async function updateSupplier(db: SQLiteDatabase, id: string, name: string): Promise<void> {
  await db.runAsync('UPDATE suppliers SET name = ? WHERE id = ?', [name, id]);
}

export class SupplierInUseError extends Error {}

export async function deleteSupplier(db: SQLiteDatabase, id: string): Promise<void> {
  try {
    await db.runAsync('DELETE FROM suppliers WHERE id = ?', [id]);
  } catch (e) {
    throw new SupplierInUseError(
      'Ce fournisseur a des achats enregistrés : impossible de le supprimer. Tu peux le renommer à la place.'
    );
  }
}
