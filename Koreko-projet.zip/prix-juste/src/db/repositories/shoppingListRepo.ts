import { type SQLiteDatabase } from 'expo-sqlite';
import { PurchaseUnit, ShoppingListItem } from '../../types/models';
import { newId } from '../../utils/uuid';
import { getSupplierComparison } from './ingredientPurchasesRepo';
import { baseUnitForPurchaseUnit, computeUnitPrice, purchaseWeightG, toBaseQuantity } from '../../utils/priceCalc';
import { BaseUnit } from '../../types/models';

interface ShoppingListItemRow {
  id: string;
  ingredient_id: string;
  ingredient_name: string;
  ingredient_unit_price: number;
  supplier_id: string | null;
  supplier_name: string | null;
  quantity: number;
  unit: PurchaseUnit;
  checked: number;
  created_at: string;
  supplier_price_ht: number | null;
  supplier_price_qty: number | null;
  supplier_price_unit: PurchaseUnit | null;
  supplier_price_weight: number | null;
  ingredient_base_unit: BaseUnit;
  line_unit_weight: number | null;
  avg_piece_weight_g: number | null;
}

function mapRow(row: ShoppingListItemRow): ShoppingListItem {
  // Prix HT/unité de base connu chez le fournisseur assigné à cet article, ou à défaut le
  // prix courant de l'ingrédient (dernier achat enregistré, tous fournisseurs confondus).
  const hasSupplierPrice =
    row.supplier_price_ht != null && row.supplier_price_qty != null && row.supplier_price_unit != null;
  let priceBase: BaseUnit = row.ingredient_base_unit;
  let unitPriceHt = row.ingredient_unit_price;
  if (hasSupplierPrice) {
    const w = purchaseWeightG(row.supplier_price_unit!, row.supplier_price_weight, row.avg_piece_weight_g);
    priceBase = baseUnitForPurchaseUnit(row.supplier_price_unit!, w);
    unitPriceHt = computeUnitPrice(row.supplier_price_ht!, row.supplier_price_qty!, row.supplier_price_unit!, w);
  }
  // Poids d'une unité de la ligne : celui du dernier achat dans cette unité (carton, paquet…), ou le
  // poids d'une pièce pour une ligne « unité ».
  const lineWeight = purchaseWeightG(row.unit, row.line_unit_weight, row.avg_piece_weight_g);
  const lineBase = baseUnitForPurchaseUnit(row.unit, lineWeight);
  // g et ml se valent ; sinon (ex: prix au gramme mais ligne « 2 cartons » sans poids) on préfère
  // ne pas afficher de prix plutôt qu'un montant absurde.
  const comparable = lineBase === priceBase || (lineBase !== 'unite' && priceBase !== 'unite');
  const estimatedPrice =
    comparable && unitPriceHt > 0 ? unitPriceHt * toBaseQuantity(row.quantity, row.unit, lineWeight) : null;
  return {
    id: row.id,
    ingredientId: row.ingredient_id,
    ingredientName: row.ingredient_name,
    supplierId: row.supplier_id,
    supplierName: row.supplier_name,
    quantity: row.quantity,
    unit: row.unit,
    checked: row.checked === 1,
    createdAt: row.created_at,
    estimatedPrice,
  };
}

export interface AddToShoppingListInput {
  ingredientId: string;
  quantity: number;
  unit: PurchaseUnit;
  // Absent = auto-assigné au fournisseur actuellement le moins cher pour cet ingrédient
  // (d'après l'historique d'achats) ; null s'il n'a encore jamais été acheté nulle part.
  supplierId?: string | null;
}

export async function addToShoppingList(db: SQLiteDatabase, input: AddToShoppingListInput): Promise<void> {
  let supplierId = input.supplierId;
  if (supplierId === undefined) {
    const comparison = await getSupplierComparison(db, input.ingredientId);
    supplierId = comparison[0]?.supplierId ?? null;
  }
  await db.runAsync(
    'INSERT INTO shopping_list_items (id, ingredient_id, supplier_id, quantity, unit, checked, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)',
    [newId(), input.ingredientId, supplierId, input.quantity, input.unit, new Date().toISOString()]
  );
}

export async function listShoppingListItems(db: SQLiteDatabase): Promise<ShoppingListItem[]> {
  const rows = await db.getAllAsync<ShoppingListItemRow>(
    `WITH ranked AS (
       SELECT ingredient_id, supplier_id, price_ht, quantity, unit, unit_weight_g,
         ROW_NUMBER() OVER (PARTITION BY ingredient_id, supplier_id ORDER BY purchase_date DESC, created_at DESC) as rn
       FROM ingredient_purchases
     )
     SELECT si.*, i.name as ingredient_name, i.unit_price as ingredient_unit_price, i.base_unit as ingredient_base_unit,
       i.avg_piece_weight_g, s.name as supplier_name,
       r.price_ht as supplier_price_ht, r.quantity as supplier_price_qty, r.unit as supplier_price_unit,
       r.unit_weight_g as supplier_price_weight,
       (SELECT p2.unit_weight_g FROM ingredient_purchases p2
          WHERE p2.ingredient_id = si.ingredient_id AND p2.unit = si.unit AND p2.unit_weight_g IS NOT NULL
          ORDER BY p2.purchase_date DESC, p2.created_at DESC LIMIT 1) as line_unit_weight
     FROM shopping_list_items si
     JOIN ingredients i ON i.id = si.ingredient_id
     LEFT JOIN suppliers s ON s.id = si.supplier_id
     LEFT JOIN ranked r ON r.ingredient_id = si.ingredient_id AND r.supplier_id = si.supplier_id AND r.rn = 1
     ORDER BY si.created_at ASC`
  );
  return rows.map(mapRow);
}

export async function setShoppingListItemChecked(db: SQLiteDatabase, id: string, checked: boolean): Promise<void> {
  await db.runAsync('UPDATE shopping_list_items SET checked = ? WHERE id = ?', [checked ? 1 : 0, id]);
}

export async function updateShoppingListItem(
  db: SQLiteDatabase,
  id: string,
  data: { quantity: number; unit: PurchaseUnit; supplierId: string | null }
): Promise<void> {
  await db.runAsync('UPDATE shopping_list_items SET quantity = ?, unit = ?, supplier_id = ? WHERE id = ?', [
    data.quantity,
    data.unit,
    data.supplierId,
    id,
  ]);
}

export async function removeShoppingListItem(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('DELETE FROM shopping_list_items WHERE id = ?', [id]);
}

// Vide la liste d'un fournisseur (tous ses ingrédients, cochés ou non) pour repartir de zéro.
// `supplierId` null = le groupe "sans fournisseur", pas toutes les listes.
export async function clearShoppingList(db: SQLiteDatabase, supplierId: string | null): Promise<void> {
  if (supplierId === null) {
    await db.runAsync('DELETE FROM shopping_list_items WHERE supplier_id IS NULL');
  } else {
    await db.runAsync('DELETE FROM shopping_list_items WHERE supplier_id = ?', [supplierId]);
  }
}

// Retire uniquement ce qui est coché (déjà trouvé/acheté) — ce qui reste non coché est gardé, car
// ça veut dire que ça manquait au magasin et il ne faut pas l'oublier la prochaine fois.
// `scope`: 'all' = tous les fournisseurs confondus (onglet "Tout") ; null = le groupe "sans
// fournisseur" ; un id = un seul fournisseur.
export async function removeCheckedItems(db: SQLiteDatabase, scope: 'all' | string | null): Promise<void> {
  if (scope === 'all') {
    await db.runAsync('DELETE FROM shopping_list_items WHERE checked = 1');
  } else if (scope === null) {
    await db.runAsync('DELETE FROM shopping_list_items WHERE supplier_id IS NULL AND checked = 1');
  } else {
    await db.runAsync('DELETE FROM shopping_list_items WHERE supplier_id = ? AND checked = 1', [scope]);
  }
}
