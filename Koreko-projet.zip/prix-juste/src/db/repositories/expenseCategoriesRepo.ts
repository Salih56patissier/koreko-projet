import { type SQLiteDatabase } from 'expo-sqlite';
import { ExpenseCategory } from '../../types/models';
import { newId } from '../../utils/uuid';

interface ExpenseCategoryRow {
  id: string;
  name: string;
  created_at: string;
}

function mapRow(row: ExpenseCategoryRow): ExpenseCategory {
  return { id: row.id, name: row.name, createdAt: row.created_at };
}

export async function listExpenseCategories(db: SQLiteDatabase): Promise<ExpenseCategory[]> {
  const rows = await db.getAllAsync<ExpenseCategoryRow>('SELECT * FROM expense_categories ORDER BY name ASC');
  return rows.map(mapRow);
}

export async function createExpenseCategory(db: SQLiteDatabase, name: string): Promise<string> {
  const id = newId();
  await db.runAsync('INSERT INTO expense_categories (id, name, created_at) VALUES (?, ?, ?)', [
    id,
    name,
    new Date().toISOString(),
  ]);
  return id;
}

export async function updateExpenseCategory(db: SQLiteDatabase, id: string, name: string): Promise<void> {
  await db.runAsync('UPDATE expense_categories SET name = ? WHERE id = ?', [name, id]);
}

// Expenses keep existing (they just lose their category) rather than being
// deleted along with the category — same non-destructive pattern as
// ingredient categories and suppliers.
export async function deleteExpenseCategory(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('UPDATE expenses SET category_id = NULL WHERE category_id = ?', [id]);
  await db.runAsync('DELETE FROM expense_categories WHERE id = ?', [id]);
}
