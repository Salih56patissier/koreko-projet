import { type SQLiteDatabase } from 'expo-sqlite';
import { SaleCategory } from '../../types/models';
import { newId } from '../../utils/uuid';

interface SaleCategoryRow {
  id: string;
  name: string;
  created_at: string;
}

function mapRow(row: SaleCategoryRow): SaleCategory {
  return { id: row.id, name: row.name, createdAt: row.created_at };
}

export async function listSaleCategories(db: SQLiteDatabase): Promise<SaleCategory[]> {
  const rows = await db.getAllAsync<SaleCategoryRow>('SELECT * FROM sale_categories ORDER BY name ASC');
  return rows.map(mapRow);
}

export async function createSaleCategory(db: SQLiteDatabase, name: string): Promise<string> {
  const id = newId();
  await db.runAsync('INSERT INTO sale_categories (id, name, created_at) VALUES (?, ?, ?)', [
    id,
    name,
    new Date().toISOString(),
  ]);
  return id;
}

export async function updateSaleCategory(db: SQLiteDatabase, id: string, name: string): Promise<void> {
  await db.runAsync('UPDATE sale_categories SET name = ? WHERE id = ?', [name, id]);
}

// Sales keep existing (they just lose their category) rather than being
// deleted along with the category — same non-destructive pattern as
// expense categories, ingredient categories and suppliers.
export async function deleteSaleCategory(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('UPDATE sales SET category_id = NULL WHERE category_id = ?', [id]);
  await db.runAsync('DELETE FROM sale_categories WHERE id = ?', [id]);
}
