import { type SQLiteDatabase } from 'expo-sqlite';
import { CashSummary, Sale } from '../../types/models';
import { newId } from '../../utils/uuid';

interface SaleRow {
  id: string;
  category_id: string | null;
  category_name: string | null;
  sale_date: string;
  amount: number;
  note: string | null;
  created_at: string;
}

function mapSaleRow(r: SaleRow): Sale {
  return {
    id: r.id,
    categoryId: r.category_id,
    categoryName: r.category_name,
    saleDate: r.sale_date,
    amount: r.amount,
    note: r.note,
    createdAt: r.created_at,
  };
}

export interface SaleInput {
  categoryId: string | null;
  saleDate: string;
  amount: number;
  note: string | null;
}

// `monthPrefix` is 'YYYY-MM' to restrict to one month, or '' for every period (LIKE '%').
export async function listSales(db: SQLiteDatabase, monthPrefix: string, limit = 1000000): Promise<Sale[]> {
  const pattern = `${monthPrefix}%`;
  const rows = await db.getAllAsync<SaleRow>(
    `SELECT s.*, sc.name as category_name FROM sales s
     LEFT JOIN sale_categories sc ON sc.id = s.category_id
     WHERE s.sale_date LIKE ?
     ORDER BY s.sale_date DESC, s.created_at DESC LIMIT ?`,
    [pattern, limit]
  );
  return rows.map(mapSaleRow);
}

export async function getSale(db: SQLiteDatabase, id: string): Promise<Sale | null> {
  const row = await db.getFirstAsync<SaleRow>(
    `SELECT s.*, sc.name as category_name FROM sales s
     LEFT JOIN sale_categories sc ON sc.id = s.category_id
     WHERE s.id = ?`,
    [id]
  );
  return row ? mapSaleRow(row) : null;
}

export async function createSale(db: SQLiteDatabase, input: SaleInput): Promise<string> {
  const id = newId();
  await db.runAsync('INSERT INTO sales (id, category_id, sale_date, amount, note, created_at) VALUES (?, ?, ?, ?, ?, ?)', [
    id,
    input.categoryId,
    input.saleDate,
    input.amount,
    input.note,
    new Date().toISOString(),
  ]);
  return id;
}

export async function updateSale(db: SQLiteDatabase, id: string, input: SaleInput): Promise<void> {
  await db.runAsync('UPDATE sales SET category_id = ?, sale_date = ?, amount = ?, note = ? WHERE id = ?', [
    input.categoryId,
    input.saleDate,
    input.amount,
    input.note,
    id,
  ]);
}

export async function deleteSale(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('DELETE FROM sales WHERE id = ?', [id]);
}

// `monthPrefix` is 'YYYY-MM' (dates are stored as 'YYYY-MM-DD' text, so a
// prefix match is enough — no need to parse dates).
export async function getMonthlySalesTotal(db: SQLiteDatabase, monthPrefix: string): Promise<number> {
  const pattern = `${monthPrefix}%`;
  const row = await db.getFirstAsync<{ total: number }>(
    'SELECT COALESCE(SUM(amount), 0) as total FROM sales WHERE sale_date LIKE ?',
    [pattern]
  );
  return row?.total ?? 0;
}

// Ce qu'il y a dans la caisse : toutes les ventes − toutes les dépenses et achats d'ingrédients
// enregistrés depuis le début, jusqu'à `endExclusive` non compris ('AAAA-MM-JJ', ex: le 1er du
// mois suivant pour avoir la caisse à la fin d'un mois). null = jusqu'à aujourd'hui et au-delà.
export async function getCashBalanceUntil(db: SQLiteDatabase, endExclusive: string | null): Promise<number> {
  const end = endExclusive ?? '9999-12-31';
  const row = await db.getFirstAsync<{ balance: number }>(
    `SELECT
       (SELECT COALESCE(SUM(amount), 0) FROM sales WHERE sale_date < ?)
       - (SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE expense_date < ?)
       - (SELECT COALESCE(SUM(price), 0) FROM ingredient_purchases WHERE purchase_date < ?) as balance`,
    [end, end, end]
  );
  return row?.balance ?? 0;
}

// Solde de caisse du mois : ventes − (dépenses + achats d'ingrédients).
export async function getMonthlyCashSummary(db: SQLiteDatabase, monthPrefix: string): Promise<CashSummary> {
  const pattern = `${monthPrefix}%`;
  const salesRow = await db.getFirstAsync<{ total: number }>(
    'SELECT COALESCE(SUM(amount), 0) as total FROM sales WHERE sale_date LIKE ?',
    [pattern]
  );
  const expenseRow = await db.getFirstAsync<{ total: number }>(
    'SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE expense_date LIKE ?',
    [pattern]
  );
  const purchaseRow = await db.getFirstAsync<{ total: number }>(
    'SELECT COALESCE(SUM(price), 0) as total FROM ingredient_purchases WHERE purchase_date LIKE ?',
    [pattern]
  );
  const totalSales = salesRow?.total ?? 0;
  const totalSpending = (expenseRow?.total ?? 0) + (purchaseRow?.total ?? 0);
  return { totalSales, totalSpending, balance: totalSales - totalSpending };
}
