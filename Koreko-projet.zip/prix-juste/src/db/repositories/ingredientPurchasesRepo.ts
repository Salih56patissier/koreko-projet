import { type SQLiteDatabase } from 'expo-sqlite';
import {
  IngredientPriceInfo,
  IngredientPurchase,
  PurchaseUnit,
  SupplierIngredientSuggestion,
  SupplierPriceRow,
} from '../../types/models';
import { newId } from '../../utils/uuid';
import {
  baseUnitForPurchaseUnit,
  computeUnitPrice,
  priceExcludingVat,
  purchaseWeightG,
} from '../../utils/priceCalc';
import { normalizeSearch } from '../../utils/normalize';

// Keeps `ingredients.purchase_price/quantity/unit/unit_price` (the value the
// recipe cost engine reads) in sync with whichever purchase is now the most
// recent for this ingredient — across all suppliers. This is the only place
// that ever changes those columns once a first purchase has been recorded,
// so there's a single source of truth for "the current price". `unit_price`
// is derived from the purchase's own `price_ht` (already computed and frozen
// at record time), not the raw price paid — recipe costs always use HT.
export async function resyncIngredientCurrentPrice(db: SQLiteDatabase, ingredientId: string): Promise<void> {
  const latest = await db.getFirstAsync<{
    price: number;
    price_ht: number;
    quantity: number;
    unit: PurchaseUnit;
    unit_weight_g: number | null;
    avg_piece_weight_g: number | null;
  }>(
    `SELECT p.price, p.price_ht, p.quantity, p.unit, p.unit_weight_g, i.avg_piece_weight_g
     FROM ingredient_purchases p JOIN ingredients i ON i.id = p.ingredient_id
     WHERE p.ingredient_id = ? ORDER BY p.purchase_date DESC, p.created_at DESC LIMIT 1`,
    [ingredientId]
  );
  if (!latest) return; // last purchase for this ingredient was just deleted — keep the existing values
  const weight = purchaseWeightG(latest.unit, latest.unit_weight_g, latest.avg_piece_weight_g);
  const baseUnit = baseUnitForPurchaseUnit(latest.unit, weight);
  const unitPrice = computeUnitPrice(latest.price_ht, latest.quantity, latest.unit, weight);
  // Achat à la pièce pesée : on retient le poids d'une pièce pour convertir « 2 œufs » ↔ « 100 g ».
  const pieceWeight = latest.unit === 'unite' && latest.unit_weight_g ? latest.unit_weight_g : latest.avg_piece_weight_g;
  await db.runAsync(
    'UPDATE ingredients SET purchase_price = ?, purchase_quantity = ?, purchase_unit = ?, base_unit = ?, unit_price = ?, avg_piece_weight_g = ?, updated_at = ? WHERE id = ?',
    [latest.price, latest.quantity, latest.unit, baseUnit, unitPrice, pieceWeight, new Date().toISOString(), ingredientId]
  );
}

// Used to show (or hide) the "here's how the comparator works" hint on the
// ingredients list — with zero purchases recorded anywhere, there's nothing
// yet to compare, which otherwise looks like the feature is simply missing.
export async function hasAnyPurchases(db: SQLiteDatabase): Promise<boolean> {
  const row = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM ingredient_purchases');
  return (row?.count ?? 0) > 0;
}

// Dernier poids d'unité connu pour cet ingrédient et cette unité d'achat (préremplit les formulaires :
// on ne retape pas le poids d'un carton à chaque achat). null = jamais indiqué.
export async function getLastUnitWeight(db: SQLiteDatabase, ingredientId: string, unit: PurchaseUnit): Promise<number | null> {
  const row = await db.getFirstAsync<{ unit_weight_g: number | null }>(
    `SELECT unit_weight_g FROM ingredient_purchases
     WHERE ingredient_id = ? AND unit = ? AND unit_weight_g IS NOT NULL
     ORDER BY purchase_date DESC, created_at DESC LIMIT 1`,
    [ingredientId, unit]
  );
  if (row?.unit_weight_g) return row.unit_weight_g;
  if (unit === 'unite') {
    const ing = await db.getFirstAsync<{ avg_piece_weight_g: number | null }>(
      'SELECT avg_piece_weight_g FROM ingredients WHERE id = ?',
      [ingredientId]
    );
    return ing?.avg_piece_weight_g ?? null;
  }
  return null;
}

export interface RecordPurchaseInput {
  ingredientId: string;
  supplierId: string;
  purchaseDate: string;
  price: number;
  quantity: number;
  unit: PurchaseUnit;
  note: string | null;
  // Poids en grammes d'UNE unité (pièce, paquet, carton, litre pesé). Absent = inconnu.
  unitWeightG?: number | null;
  // Absent = reprend le taux actuel de l'ingrédient (comportement historique). Se fige sur cet
  // achat dans tous les cas : un changement de taux plus tard ne le recalculera pas rétroactivement.
  vatRate?: number;
}

export async function recordPurchase(db: SQLiteDatabase, input: RecordPurchaseInput): Promise<void> {
  let vatRate = input.vatRate;
  if (vatRate == null) {
    const ingredient = await db.getFirstAsync<{ vat_rate: number }>('SELECT vat_rate FROM ingredients WHERE id = ?', [
      input.ingredientId,
    ]);
    vatRate = ingredient?.vat_rate ?? 20;
  }
  const priceHt = priceExcludingVat(input.price, vatRate);
  await db.runAsync(
    `INSERT INTO ingredient_purchases (id, ingredient_id, supplier_id, purchase_date, price, vat_rate, price_ht, quantity, unit, unit_weight_g, note, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      newId(),
      input.ingredientId,
      input.supplierId,
      input.purchaseDate,
      input.price,
      vatRate,
      priceHt,
      input.quantity,
      input.unit,
      input.unitWeightG ?? null,
      input.note,
      new Date().toISOString(),
    ]
  );
  await resyncIngredientCurrentPrice(db, input.ingredientId);
}

export interface UpdatePurchaseInput {
  supplierId: string;
  purchaseDate: string;
  price: number;
  quantity: number;
  unit: PurchaseUnit;
  note: string | null;
  vatRate: number;
  unitWeightG?: number | null;
}

// Corrige un achat déjà enregistré (ex: fournisseur oublié/faux, ou taux de TVA erroné — un
// achat au marché sans facture saisi par erreur avec la TVA par défaut de l'époque) sans avoir à
// le supprimer et le ressaisir. Re-synchronise ensuite le prix courant de l'ingrédient, au cas où
// cet achat était (ou devient) le plus récent.
export async function updatePurchase(db: SQLiteDatabase, id: string, input: UpdatePurchaseInput): Promise<void> {
  const row = await db.getFirstAsync<{ ingredient_id: string }>(
    'SELECT ingredient_id FROM ingredient_purchases WHERE id = ?',
    [id]
  );
  if (!row) return;
  const priceHt = priceExcludingVat(input.price, input.vatRate);
  await db.runAsync(
    'UPDATE ingredient_purchases SET supplier_id = ?, purchase_date = ?, price = ?, vat_rate = ?, price_ht = ?, quantity = ?, unit = ?, unit_weight_g = ?, note = ? WHERE id = ?',
    [input.supplierId, input.purchaseDate, input.price, input.vatRate, priceHt, input.quantity, input.unit, input.unitWeightG ?? null, input.note, id]
  );
  await resyncIngredientCurrentPrice(db, row.ingredient_id);
}

interface PurchaseRow {
  id: string;
  ingredient_id: string;
  supplier_id: string;
  supplier_name: string;
  purchase_date: string;
  price: number;
  vat_rate: number;
  price_ht: number;
  quantity: number;
  unit: PurchaseUnit;
  unit_weight_g: number | null;
  note: string | null;
  created_at: string;
}

export async function listPurchasesForIngredient(db: SQLiteDatabase, ingredientId: string): Promise<IngredientPurchase[]> {
  const ingredient = await db.getFirstAsync<{ avg_piece_weight_g: number | null }>(
    'SELECT avg_piece_weight_g FROM ingredients WHERE id = ?',
    [ingredientId]
  );
  const avgPieceWeightG = ingredient?.avg_piece_weight_g ?? null;
  const rows = await db.getAllAsync<PurchaseRow>(
    `SELECT p.*, s.name as supplier_name FROM ingredient_purchases p
     JOIN suppliers s ON s.id = p.supplier_id
     WHERE p.ingredient_id = ?
     ORDER BY p.purchase_date DESC, p.created_at DESC`,
    [ingredientId]
  );
  return rows.map((r) => ({
    id: r.id,
    ingredientId: r.ingredient_id,
    supplierId: r.supplier_id,
    supplierName: r.supplier_name,
    purchaseDate: r.purchase_date,
    price: r.price,
    vatRate: r.vat_rate,
    priceHt: r.price_ht,
    quantity: r.quantity,
    unit: r.unit,
    unitWeightG: r.unit_weight_g,
    unitPrice: computeUnitPrice(r.price_ht, r.quantity, r.unit, purchaseWeightG(r.unit, r.unit_weight_g, avgPieceWeightG)),
    note: r.note,
    createdAt: r.created_at,
  }));
}

export async function deletePurchase(db: SQLiteDatabase, id: string): Promise<void> {
  const row = await db.getFirstAsync<{ ingredient_id: string }>(
    'SELECT ingredient_id FROM ingredient_purchases WHERE id = ?',
    [id]
  );
  await db.runAsync('DELETE FROM ingredient_purchases WHERE id = ?', [id]);
  if (row) await resyncIngredientCurrentPrice(db, row.ingredient_id);
}

// The latest known price at each supplier that has ever sold this
// ingredient, cheapest first.
export async function getSupplierComparison(db: SQLiteDatabase, ingredientId: string): Promise<SupplierPriceRow[]> {
  const ingredient = await db.getFirstAsync<{ avg_piece_weight_g: number | null }>(
    'SELECT avg_piece_weight_g FROM ingredients WHERE id = ?',
    [ingredientId]
  );
  const avgPieceWeightG = ingredient?.avg_piece_weight_g ?? null;
  const rows = await db.getAllAsync<{
    supplier_id: string;
    supplier_name: string;
    price_ht: number;
    quantity: number;
    unit: PurchaseUnit;
    unit_weight_g: number | null;
    purchase_date: string;
  }>(
    `WITH ranked AS (
       SELECT p.supplier_id, s.name as supplier_name, p.price_ht, p.quantity, p.unit, p.unit_weight_g, p.purchase_date,
         ROW_NUMBER() OVER (PARTITION BY p.supplier_id ORDER BY p.purchase_date DESC, p.created_at DESC) as rn
       FROM ingredient_purchases p
       JOIN suppliers s ON s.id = p.supplier_id
       WHERE p.ingredient_id = ?
     )
     SELECT supplier_id, supplier_name, price_ht, quantity, unit, unit_weight_g, purchase_date FROM ranked WHERE rn = 1`,
    [ingredientId]
  );
  const withPrice: SupplierPriceRow[] = rows.map((r) => ({
    supplierId: r.supplier_id,
    supplierName: r.supplier_name,
    unitPrice: computeUnitPrice(r.price_ht, r.quantity, r.unit, purchaseWeightG(r.unit, r.unit_weight_g, avgPieceWeightG)),
    purchaseDate: r.purchase_date,
    isCheapest: false,
  }));
  withPrice.sort((a, b) => a.unitPrice - b.unitPrice);
  if (withPrice.length > 0) withPrice[0].isCheapest = true;
  return withPrice;
}

// Batched for the ingredients list: for every ingredient that has at least
// one recorded purchase, the cheapest currently-known supplier price and the
// trend (current purchase vs the one before it). One pair of queries
// regardless of how many ingredients there are.
export async function getIngredientPriceInfoMap(db: SQLiteDatabase): Promise<Map<string, IngredientPriceInfo>> {
  const supplierLatestRows = await db.getAllAsync<{
    ingredient_id: string;
    supplier_name: string;
    price_ht: number;
    quantity: number;
    unit: PurchaseUnit;
    unit_weight_g: number | null;
    avg_piece_weight_g: number | null;
  }>(
    `WITH ranked AS (
       SELECT p.ingredient_id, s.name as supplier_name, p.price_ht, p.quantity, p.unit, p.unit_weight_g, i.avg_piece_weight_g,
         ROW_NUMBER() OVER (PARTITION BY p.ingredient_id, p.supplier_id ORDER BY p.purchase_date DESC, p.created_at DESC) as rn
       FROM ingredient_purchases p
       JOIN suppliers s ON s.id = p.supplier_id
       JOIN ingredients i ON i.id = p.ingredient_id
     )
     SELECT ingredient_id, supplier_name, price_ht, quantity, unit, unit_weight_g, avg_piece_weight_g FROM ranked WHERE rn = 1`
  );
  const cheapestByIngredient = new Map<string, { name: string; unitPrice: number }>();
  for (const r of supplierLatestRows) {
    const unitPrice = computeUnitPrice(r.price_ht, r.quantity, r.unit, purchaseWeightG(r.unit, r.unit_weight_g, r.avg_piece_weight_g));
    const existing = cheapestByIngredient.get(r.ingredient_id);
    if (!existing || unitPrice < existing.unitPrice) {
      cheapestByIngredient.set(r.ingredient_id, { name: r.supplier_name, unitPrice });
    }
  }

  const globalRanked = await db.getAllAsync<{
    ingredient_id: string;
    price_ht: number;
    quantity: number;
    unit: PurchaseUnit;
    unit_weight_g: number | null;
    avg_piece_weight_g: number | null;
    rn: number;
  }>(
    `WITH ranked AS (
       SELECT p.ingredient_id, p.price_ht, p.quantity, p.unit, p.unit_weight_g, i.avg_piece_weight_g,
         ROW_NUMBER() OVER (PARTITION BY p.ingredient_id ORDER BY p.purchase_date DESC, p.created_at DESC) as rn
       FROM ingredient_purchases p
       JOIN ingredients i ON i.id = p.ingredient_id
     )
     SELECT ingredient_id, price_ht, quantity, unit, unit_weight_g, avg_piece_weight_g, rn FROM ranked WHERE rn IN (1, 2)`
  );
  const trendByIngredient = new Map<string, { current?: number; previous?: number }>();
  for (const r of globalRanked) {
    const unitPrice = computeUnitPrice(r.price_ht, r.quantity, r.unit, purchaseWeightG(r.unit, r.unit_weight_g, r.avg_piece_weight_g));
    const entry = trendByIngredient.get(r.ingredient_id) ?? {};
    if (r.rn === 1) entry.current = unitPrice;
    else entry.previous = unitPrice;
    trendByIngredient.set(r.ingredient_id, entry);
  }

  const result = new Map<string, IngredientPriceInfo>();
  const allIds = new Set<string>([...cheapestByIngredient.keys(), ...trendByIngredient.keys()]);
  for (const id of allIds) {
    const cheapest = cheapestByIngredient.get(id);
    const trendEntry = trendByIngredient.get(id);
    let trend: IngredientPriceInfo['trend'] = null;
    if (trendEntry?.current != null && trendEntry?.previous != null) {
      trend = trendEntry.current > trendEntry.previous ? 'up' : trendEntry.current < trendEntry.previous ? 'down' : 'stable';
    }
    result.set(id, {
      cheapestSupplierName: cheapest?.name ?? null,
      cheapestUnitPrice: cheapest?.unitPrice ?? null,
      trend,
    });
  }
  return result;
}

// Tout ce qui a déjà été acheté chez ce fournisseur au moins une fois — proposé comme
// suggestions dans la liste de courses ("ce que je prends d'habitude ici") pour ne rien oublier.
export async function listSupplierIngredientSuggestions(
  db: SQLiteDatabase,
  supplierId: string
): Promise<SupplierIngredientSuggestion[]> {
  const rows = await db.getAllAsync<{
    ingredient_id: string;
    name: string;
    quantity: number;
    unit: PurchaseUnit;
  }>(
    `WITH ranked AS (
       SELECT ingredient_id, quantity, unit,
         ROW_NUMBER() OVER (PARTITION BY ingredient_id ORDER BY purchase_date DESC, created_at DESC) as rn
       FROM ingredient_purchases
       WHERE supplier_id = ?
     )
     SELECT r.ingredient_id, i.name, r.quantity, r.unit
     FROM ranked r JOIN ingredients i ON i.id = r.ingredient_id
     WHERE r.rn = 1`,
    [supplierId]
  );
  const suggestions = rows.map((r) => ({
    ingredientId: r.ingredient_id,
    ingredientName: r.name,
    lastQuantity: r.quantity,
    lastUnit: r.unit,
  }));
  suggestions.sort((a, b) => normalizeSearch(a.ingredientName).localeCompare(normalizeSearch(b.ingredientName)));
  return suggestions;
}
