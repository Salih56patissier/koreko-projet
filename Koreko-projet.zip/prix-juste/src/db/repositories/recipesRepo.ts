import { type SQLiteDatabase } from 'expo-sqlite';
import {
  BaseUnit,
  ComponentCandidateRecipe,
  Recipe,
  RecipeExtraCost,
  RecipeFull,
  RecipeGroupItemWithIngredient,
  RecipeGroupWithItems,
  RecipeSummary,
} from '../../types/models';
import { newId } from '../../utils/uuid';
import { componentUnitPrice, groupCost, itemQuantityInBaseUnit, itemWeightGrams, lineCost } from '../../utils/priceCalc';

// ---------- Row types ----------

interface RecipeRow {
  id: string;
  category_id: string;
  name: string;
  photo_uri: string | null;
  labor_hours: number;
  hourly_rate: number;
  margin_percent: number;
  servings: number;
  billed_price: number | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

function mapRecipeRow(row: RecipeRow): Recipe {
  return {
    id: row.id,
    categoryId: row.category_id,
    name: row.name,
    photoUri: row.photo_uri,
    laborHours: row.labor_hours,
    hourlyRate: row.hourly_rate,
    marginPercent: row.margin_percent,
    servings: row.servings,
    billedPrice: row.billed_price,
    sortOrder: row.sort_order,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// ---------- Recursive recipe cost/weight (a recipe's own ingredients + labor
// + extras + any recipes it uses as components, resolved recursively) ----------

interface RecipeCostAndWeight {
  ingredientsCost: number;
  laborCost: number;
  extraCosts: number;
  totalRealCost: number;
  totalWeight: number;
}

interface RecipeItemForCostRow {
  ingredient_id: string | null;
  component_recipe_id: string | null;
  quantity: number;
  unit: BaseUnit;
  ingredient_unit_price: number | null;
  ingredient_base_unit: BaseUnit | null;
  avg_piece_weight_g: number | null;
}

export async function computeRecipeRealCostAndWeight(
  db: SQLiteDatabase,
  recipeId: string,
  visited: Set<string> = new Set()
): Promise<RecipeCostAndWeight> {
  if (visited.has(recipeId)) {
    // Defensive guard: the component picker never offers a recipe that would
    // create a cycle, so this should not happen in practice.
    return { ingredientsCost: 0, laborCost: 0, extraCosts: 0, totalRealCost: 0, totalWeight: 0 };
  }
  // `visited` = the chain of recipes currently being computed (not every recipe seen so far):
  // the same sub-recipe used twice, or two sub-recipes sharing a base, must each count fully.
  const path = new Set(visited).add(recipeId);

  const recipeRow = await db.getFirstAsync<{ labor_hours: number; hourly_rate: number }>(
    'SELECT labor_hours, hourly_rate FROM recipes WHERE id = ?',
    [recipeId]
  );
  if (!recipeRow) {
    return { ingredientsCost: 0, laborCost: 0, extraCosts: 0, totalRealCost: 0, totalWeight: 0 };
  }

  const itemRows = await db.getAllAsync<RecipeItemForCostRow>(
    `SELECT rgi.ingredient_id, rgi.component_recipe_id, rgi.quantity, rgi.unit, i.unit_price as ingredient_unit_price,
            i.base_unit as ingredient_base_unit, i.avg_piece_weight_g
     FROM recipe_group_items rgi
     JOIN recipe_groups rg ON rg.id = rgi.group_id
     LEFT JOIN ingredients i ON i.id = rgi.ingredient_id
     WHERE rg.recipe_id = ?`,
    [recipeId]
  );

  const extraRow = await db.getFirstAsync<{ total: number }>(
    'SELECT COALESCE(SUM(cost), 0) as total FROM recipe_extra_costs WHERE recipe_id = ?',
    [recipeId]
  );

  let ingredientsCost = 0;
  let totalWeight = 0;
  for (const item of itemRows) {
    if (item.ingredient_id) {
      const qty = itemQuantityInBaseUnit(item.quantity, item.unit, item.ingredient_base_unit ?? item.unit, item.avg_piece_weight_g);
      ingredientsCost += qty * (item.ingredient_unit_price ?? 0);
    } else if (item.component_recipe_id) {
      const sub = await computeRecipeRealCostAndWeight(db, item.component_recipe_id, path);
      ingredientsCost += item.quantity * componentUnitPrice(sub.totalRealCost, sub.totalWeight);
    }
    totalWeight += itemWeightGrams(item.quantity, item.unit, item.avg_piece_weight_g);
  }

  const laborCost = recipeRow.labor_hours * recipeRow.hourly_rate;
  const extraCosts = extraRow?.total ?? 0;

  return {
    ingredientsCost,
    laborCost,
    extraCosts,
    totalRealCost: ingredientsCost + laborCost + extraCosts,
    totalWeight,
  };
}

// ---------- All recipes, for the search on the Recipes tab ----------

export interface RecipeSearchEntry {
  recipeId: string;
  recipeName: string;
  categoryId: string;
  categoryName: string;
}

export async function listRecipesForSearch(db: SQLiteDatabase): Promise<RecipeSearchEntry[]> {
  const rows = await db.getAllAsync<{ id: string; name: string; category_id: string; category_name: string }>(
    `SELECT r.id, r.name, r.category_id, c.name as category_name
     FROM recipes r JOIN categories c ON c.id = r.category_id`
  );
  return rows.map((r) => ({ recipeId: r.id, recipeName: r.name, categoryId: r.category_id, categoryName: r.category_name }));
}

// ---------- Recipes using an ingredient (shown on the ingredient's screen) ----------

export interface RecipeUsingIngredient {
  recipeId: string;
  recipeName: string;
  categoryId: string;
  categoryName: string;
  quantity: number; // total over all the recipe's steps
  unit: BaseUnit;
}

export async function listRecipesUsingIngredient(db: SQLiteDatabase, ingredientId: string): Promise<RecipeUsingIngredient[]> {
  const rows = await db.getAllAsync<{
    recipe_id: string;
    recipe_name: string;
    category_id: string;
    category_name: string;
    quantity: number;
    unit: BaseUnit;
  }>(
    `SELECT r.id as recipe_id, r.name as recipe_name, c.id as category_id, c.name as category_name,
            SUM(rgi.quantity) as quantity, rgi.unit as unit
     FROM recipe_group_items rgi
     JOIN recipe_groups rg ON rg.id = rgi.group_id
     JOIN recipes r ON r.id = rg.recipe_id
     JOIN categories c ON c.id = r.category_id
     WHERE rgi.ingredient_id = ?
     GROUP BY r.id, rgi.unit
     ORDER BY r.name COLLATE NOCASE ASC`,
    [ingredientId]
  );
  return rows.map((r) => ({
    recipeId: r.recipe_id,
    recipeName: r.recipe_name,
    categoryId: r.category_id,
    categoryName: r.category_name,
    quantity: r.quantity,
    unit: r.unit,
  }));
}

// Recettes qui utilisent une recette de base comme composant (ex: « Crème au beurre » est dans
// le Fraisier et l'Opéra), pour savoir où elle sert avant de la modifier ou la supprimer.
export async function listRecipesUsingComponent(db: SQLiteDatabase, componentRecipeId: string): Promise<RecipeUsingIngredient[]> {
  const rows = await db.getAllAsync<{
    recipe_id: string;
    recipe_name: string;
    category_id: string;
    category_name: string;
    quantity: number;
  }>(
    `SELECT r.id as recipe_id, r.name as recipe_name, c.id as category_id, c.name as category_name,
            SUM(rgi.quantity) as quantity
     FROM recipe_group_items rgi
     JOIN recipe_groups rg ON rg.id = rgi.group_id
     JOIN recipes r ON r.id = rg.recipe_id
     JOIN categories c ON c.id = r.category_id
     WHERE rgi.component_recipe_id = ?
     GROUP BY r.id
     ORDER BY r.name COLLATE NOCASE ASC`,
    [componentRecipeId]
  );
  return rows.map((r) => ({
    recipeId: r.recipe_id,
    recipeName: r.recipe_name,
    categoryId: r.category_id,
    categoryName: r.category_name,
    quantity: r.quantity,
    unit: 'g' as const,
  }));
}

// ---------- Category recipe list (with computed fair price) ----------

export async function listRecipeSummariesByCategory(
  db: SQLiteDatabase,
  categoryId: string
): Promise<RecipeSummary[]> {
  const rows = await db.getAllAsync<{ id: string; name: string; photo_uri: string | null; margin_percent: number }>(
    'SELECT id, name, photo_uri, margin_percent FROM recipes WHERE category_id = ? ORDER BY sort_order ASC, name ASC',
    [categoryId]
  );
  const summaries: RecipeSummary[] = [];
  for (const row of rows) {
    const cost = await computeRecipeRealCostAndWeight(db, row.id);
    summaries.push({
      id: row.id,
      name: row.name,
      photoUri: row.photo_uri,
      fairPrice: cost.totalRealCost * (1 + row.margin_percent / 100),
    });
  }
  return summaries;
}

// ---------- Recipes eligible to be used as a component/sub-recipe ----------
// Restricted to "base" recipes (no component items of their own) so a
// component's cost can never depend on the recipe being edited — this makes
// circular references impossible by construction.

// True if `recipeId` uses `targetId` as a component, directly or through a chain of other
// components — i.e. offering `recipeId` as a component of `targetId` would create a cycle.
async function recipeDependsOnComponent(
  db: SQLiteDatabase,
  recipeId: string,
  targetId: string,
  visited: Set<string> = new Set()
): Promise<boolean> {
  if (recipeId === targetId) return true;
  if (visited.has(recipeId)) return false;
  visited.add(recipeId);

  const rows = await db.getAllAsync<{ component_recipe_id: string }>(
    `SELECT DISTINCT rgi.component_recipe_id FROM recipe_group_items rgi
     JOIN recipe_groups rg ON rg.id = rgi.group_id
     WHERE rg.recipe_id = ? AND rgi.component_recipe_id IS NOT NULL`,
    [recipeId]
  );
  for (const row of rows) {
    if (await recipeDependsOnComponent(db, row.component_recipe_id, targetId, visited)) return true;
  }
  return false;
}

// A recipe can be reused as a component elsewhere as long as doing so wouldn't create a cycle
// (it, or something it itself uses as a component, must not already depend on the recipe being
// edited). Nesting several levels deep is fine — computeRecipeRealCostAndWeight resolves it
// recursively — this only guards against genuine A-uses-B-uses-A loops.
export async function listComponentCandidateRecipes(
  db: SQLiteDatabase,
  excludeRecipeId: string
): Promise<ComponentCandidateRecipe[]> {
  const rows = await db.getAllAsync<{ id: string; name: string; category_name: string }>(
    `SELECT r.id, r.name, c.name as category_name
     FROM recipes r
     JOIN categories c ON c.id = r.category_id
     WHERE r.id != ?
     ORDER BY r.name ASC`,
    [excludeRecipeId]
  );
  const candidates: ComponentCandidateRecipe[] = [];
  for (const row of rows) {
    if (await recipeDependsOnComponent(db, row.id, excludeRecipeId)) continue;
    const cost = await computeRecipeRealCostAndWeight(db, row.id);
    candidates.push({
      id: row.id,
      name: row.name,
      categoryName: row.category_name,
      unitPrice: componentUnitPrice(cost.totalRealCost, cost.totalWeight),
      totalWeight: cost.totalWeight,
    });
  }
  return candidates;
}

// ---------- Full recipe (recipe + groups + items + extra costs) ----------

interface GroupRow {
  id: string;
  recipe_id: string;
  name: string;
  instruction: string | null;
  sort_order: number;
}

interface ItemJoinRow {
  item_id: string;
  group_id: string;
  ingredient_id: string | null;
  component_recipe_id: string | null;
  quantity: number;
  unit: BaseUnit;
  note: string | null;
  item_sort_order: number;
  ing_name: string | null;
  ing_unit_price: number | null;
  component_name: string | null;
  ing_base_unit: BaseUnit | null;
  ing_avg_piece_weight_g: number | null;
}

interface ExtraCostRow {
  id: string;
  recipe_id: string;
  label: string;
  cost: number;
  sort_order: number;
}

export async function getRecipeFull(db: SQLiteDatabase, recipeId: string): Promise<RecipeFull | null> {
  const recipeRow = await db.getFirstAsync<RecipeRow>('SELECT * FROM recipes WHERE id = ?', [recipeId]);
  if (!recipeRow) return null;

  const groupRows = await db.getAllAsync<GroupRow>(
    'SELECT * FROM recipe_groups WHERE recipe_id = ? ORDER BY sort_order ASC',
    [recipeId]
  );
  const groupIds = groupRows.map((g) => g.id);

  const tagRows =
    groupIds.length > 0
      ? await db.getAllAsync<{ group_id: string; process_action_id: string }>(
          `SELECT group_id, process_action_id FROM recipe_group_process_tags WHERE group_id IN (${groupIds
            .map(() => '?')
            .join(',')})`,
          groupIds
        )
      : [];

  const itemRows =
    groupIds.length > 0
      ? await db.getAllAsync<ItemJoinRow>(
          `SELECT rgi.id as item_id, rgi.group_id, rgi.ingredient_id, rgi.component_recipe_id,
                  rgi.quantity, rgi.unit, rgi.note, rgi.sort_order as item_sort_order,
                  i.name as ing_name, i.unit_price as ing_unit_price,
                  i.base_unit as ing_base_unit, i.avg_piece_weight_g as ing_avg_piece_weight_g,
                  cr.name as component_name
           FROM recipe_group_items rgi
           LEFT JOIN ingredients i ON i.id = rgi.ingredient_id
           LEFT JOIN recipes cr ON cr.id = rgi.component_recipe_id
           WHERE rgi.group_id IN (${groupIds.map(() => '?').join(',')})
           ORDER BY rgi.sort_order ASC`,
          groupIds
        )
      : [];

  // Component (sub-recipe) unit prices are resolved separately since they
  // require walking that recipe's own ingredients/labor/extras.
  const componentIds = [...new Set(itemRows.filter((it) => it.component_recipe_id).map((it) => it.component_recipe_id as string))];
  const componentUnitPrices = new Map<string, number>();
  for (const componentId of componentIds) {
    const cost = await computeRecipeRealCostAndWeight(db, componentId, new Set([recipeId]));
    componentUnitPrices.set(componentId, componentUnitPrice(cost.totalRealCost, cost.totalWeight));
  }

  const extraCostRows = await db.getAllAsync<ExtraCostRow>(
    'SELECT * FROM recipe_extra_costs WHERE recipe_id = ? ORDER BY sort_order ASC',
    [recipeId]
  );

  const groups: RecipeGroupWithItems[] = groupRows.map((g) => {
    const processTagIds = tagRows.filter((t) => t.group_id === g.id).map((t) => t.process_action_id);
    const items: RecipeGroupItemWithIngredient[] = itemRows
      .filter((it) => it.group_id === g.id)
      .map((it) => {
        const isComponent = it.component_recipe_id != null;
        const unitPrice = isComponent
          ? componentUnitPrices.get(it.component_recipe_id as string) ?? 0
          : it.ing_unit_price ?? 0;
        const name = isComponent ? it.component_name ?? '?' : it.ing_name ?? '?';
        return {
          id: it.item_id,
          groupId: it.group_id,
          ingredientId: it.ingredient_id,
          componentRecipeId: it.component_recipe_id,
          quantity: it.quantity,
          unit: it.unit,
          note: it.note,
          sortOrder: it.item_sort_order,
          name,
          unitPrice,
          isComponent,
          avgPieceWeightG: it.ing_avg_piece_weight_g,
          lineCost: lineCost(
            unitPrice,
            isComponent
              ? it.quantity
              : itemQuantityInBaseUnit(it.quantity, it.unit, it.ing_base_unit ?? it.unit, it.ing_avg_piece_weight_g)
          ),
        };
      });
    return {
      id: g.id,
      recipeId: g.recipe_id,
      name: g.name,
      instruction: g.instruction,
      sortOrder: g.sort_order,
      processTagIds,
      items,
      groupCost: groupCost(items),
    };
  });

  const extraCosts: RecipeExtraCost[] = extraCostRows.map((e) => ({
    id: e.id,
    recipeId: e.recipe_id,
    label: e.label,
    cost: e.cost,
    sortOrder: e.sort_order,
  }));

  return {
    ...mapRecipeRow(recipeRow),
    groups,
    extraCosts,
  };
}

// ---------- Recipe mutations ----------

export async function createRecipe(
  db: SQLiteDatabase,
  categoryId: string,
  name: string,
  defaultHourlyRate: number
): Promise<string> {
  const id = newId();
  const now = new Date().toISOString();
  const maxOrder = await db.getFirstAsync<{ max_order: number | null }>(
    'SELECT MAX(sort_order) as max_order FROM recipes WHERE category_id = ?',
    [categoryId]
  );
  const sortOrder = (maxOrder?.max_order ?? -1) + 1;
  await db.runAsync(
    `INSERT INTO recipes (id, category_id, name, photo_uri, labor_hours, hourly_rate, margin_percent, servings, billed_price, sort_order, created_at, updated_at)
     VALUES (?, ?, ?, NULL, 0, ?, 0, 1, NULL, ?, ?, ?)`,
    [id, categoryId, name, defaultHourlyRate, sortOrder, now, now]
  );
  return id;
}

export interface RecipeMetaInput {
  name: string;
  photoUri: string | null;
  laborHours: number;
  hourlyRate: number;
  marginPercent: number;
  servings: number;
  billedPrice: number | null;
}

export async function updateRecipeMeta(db: SQLiteDatabase, id: string, input: RecipeMetaInput): Promise<void> {
  await db.runAsync(
    `UPDATE recipes SET name = ?, photo_uri = ?, labor_hours = ?, hourly_rate = ?, margin_percent = ?,
       servings = ?, billed_price = ?, updated_at = ? WHERE id = ?`,
    [
      input.name,
      input.photoUri,
      input.laborHours,
      input.hourlyRate,
      input.marginPercent,
      input.servings,
      input.billedPrice,
      new Date().toISOString(),
      id,
    ]
  );
}

export async function deleteRecipe(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('DELETE FROM recipes WHERE id = ?', [id]);
}

// Change de catégorie sans rien effacer ni redemander — la recette garde toutes ses étapes,
// ingrédients et frais annexes, seule sa catégorie change.
export async function moveRecipeToCategory(db: SQLiteDatabase, recipeId: string, categoryId: string): Promise<void> {
  const maxOrder = await db.getFirstAsync<{ max_order: number | null }>(
    'SELECT MAX(sort_order) as max_order FROM recipes WHERE category_id = ?',
    [categoryId]
  );
  const sortOrder = (maxOrder?.max_order ?? -1) + 1;
  await db.runAsync('UPDATE recipes SET category_id = ?, sort_order = ?, updated_at = ? WHERE id = ?', [
    categoryId,
    sortOrder,
    new Date().toISOString(),
    recipeId,
  ]);
}

// Copie complète (étapes, actions, ingrédients, frais annexes) dans une autre catégorie — la
// recette d'origine reste intacte. La photo n'est volontairement pas reprise : les deux
// recettes partageraient le même fichier, et supprimer la photo de l'une effacerait aussi
// celle de l'autre.
export async function duplicateRecipe(
  db: SQLiteDatabase,
  recipeId: string,
  categoryId: string,
  newPhotoUri: string | null
): Promise<string> {
  const full = await getRecipeFull(db, recipeId);
  if (!full) throw new Error('Recipe not found');

  const newRecipeId = newId();
  const now = new Date().toISOString();
  const maxOrder = await db.getFirstAsync<{ max_order: number | null }>(
    'SELECT MAX(sort_order) as max_order FROM recipes WHERE category_id = ?',
    [categoryId]
  );
  const sortOrder = (maxOrder?.max_order ?? -1) + 1;
  await db.runAsync(
    `INSERT INTO recipes (id, category_id, name, photo_uri, labor_hours, hourly_rate, margin_percent, servings, billed_price, sort_order, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      newRecipeId,
      categoryId,
      full.name,
      newPhotoUri,
      full.laborHours,
      full.hourlyRate,
      full.marginPercent,
      full.servings,
      full.billedPrice,
      sortOrder,
      now,
      now,
    ]
  );

  for (const group of full.groups) {
    const newGroupId = newId();
    await db.runAsync(
      'INSERT INTO recipe_groups (id, recipe_id, name, instruction, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [newGroupId, newRecipeId, group.name, group.instruction, group.sortOrder, now, now]
    );
    for (const tagId of group.processTagIds) {
      await db.runAsync('INSERT INTO recipe_group_process_tags (group_id, process_action_id) VALUES (?, ?)', [
        newGroupId,
        tagId,
      ]);
    }
    for (const item of group.items) {
      await db.runAsync(
        'INSERT INTO recipe_group_items (id, group_id, ingredient_id, component_recipe_id, quantity, unit, note, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [newId(), newGroupId, item.ingredientId, item.componentRecipeId, item.quantity, item.unit, item.note, item.sortOrder]
      );
    }
  }

  for (const extra of full.extraCosts) {
    await db.runAsync('INSERT INTO recipe_extra_costs (id, recipe_id, label, cost, sort_order) VALUES (?, ?, ?, ?, ?)', [
      newId(),
      newRecipeId,
      extra.label,
      extra.cost,
      extra.sortOrder,
    ]);
  }

  return newRecipeId;
}

// ---------- Group mutations ----------

export async function addGroup(db: SQLiteDatabase, recipeId: string, name: string): Promise<string> {
  const id = newId();
  const now = new Date().toISOString();
  const maxOrder = await db.getFirstAsync<{ max_order: number | null }>(
    'SELECT MAX(sort_order) as max_order FROM recipe_groups WHERE recipe_id = ?',
    [recipeId]
  );
  const sortOrder = (maxOrder?.max_order ?? -1) + 1;
  await db.runAsync(
    'INSERT INTO recipe_groups (id, recipe_id, name, instruction, sort_order, created_at, updated_at) VALUES (?, ?, ?, NULL, ?, ?, ?)',
    [id, recipeId, name, sortOrder, now, now]
  );
  return id;
}

export async function updateGroup(
  db: SQLiteDatabase,
  groupId: string,
  fields: { name: string; instruction: string | null }
): Promise<void> {
  await db.runAsync('UPDATE recipe_groups SET name = ?, instruction = ?, updated_at = ? WHERE id = ?', [
    fields.name,
    fields.instruction,
    new Date().toISOString(),
    groupId,
  ]);
}

export async function deleteGroup(db: SQLiteDatabase, groupId: string): Promise<void> {
  await db.runAsync('DELETE FROM recipe_groups WHERE id = ?', [groupId]);
}

// Ordre des recettes dans leur catégorie, choisi par glisser-déposer.
export async function reorderRecipes(db: SQLiteDatabase, orderedRecipeIds: string[]): Promise<void> {
  for (let i = 0; i < orderedRecipeIds.length; i++) {
    await db.runAsync('UPDATE recipes SET sort_order = ? WHERE id = ?', [i, orderedRecipeIds[i]]);
  }
}

export async function reorderGroups(db: SQLiteDatabase, orderedGroupIds: string[]): Promise<void> {
  for (let i = 0; i < orderedGroupIds.length; i++) {
    await db.runAsync('UPDATE recipe_groups SET sort_order = ? WHERE id = ?', [i, orderedGroupIds[i]]);
  }
}

export async function setGroupProcessTags(db: SQLiteDatabase, groupId: string, tagIds: string[]): Promise<void> {
  await db.runAsync('DELETE FROM recipe_group_process_tags WHERE group_id = ?', [groupId]);
  for (const tagId of tagIds) {
    await db.runAsync('INSERT INTO recipe_group_process_tags (group_id, process_action_id) VALUES (?, ?)', [
      groupId,
      tagId,
    ]);
  }
}

// ---------- Group item mutations ----------

// Exactly one of ingredientId / componentRecipeId must be set.
export interface GroupItemInput {
  ingredientId: string | null;
  componentRecipeId: string | null;
  quantity: number;
  unit: BaseUnit;
  note: string | null;
}

export async function addGroupItem(db: SQLiteDatabase, groupId: string, input: GroupItemInput): Promise<string> {
  const id = newId();
  const maxOrder = await db.getFirstAsync<{ max_order: number | null }>(
    'SELECT MAX(sort_order) as max_order FROM recipe_group_items WHERE group_id = ?',
    [groupId]
  );
  const sortOrder = (maxOrder?.max_order ?? -1) + 1;
  await db.runAsync(
    'INSERT INTO recipe_group_items (id, group_id, ingredient_id, component_recipe_id, quantity, unit, note, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [id, groupId, input.ingredientId, input.componentRecipeId, input.quantity, input.unit, input.note, sortOrder]
  );
  return id;
}

export async function updateGroupItem(db: SQLiteDatabase, itemId: string, input: GroupItemInput): Promise<void> {
  await db.runAsync(
    'UPDATE recipe_group_items SET ingredient_id = ?, component_recipe_id = ?, quantity = ?, unit = ?, note = ? WHERE id = ?',
    [input.ingredientId, input.componentRecipeId, input.quantity, input.unit, input.note, itemId]
  );
}

export async function deleteGroupItem(db: SQLiteDatabase, itemId: string): Promise<void> {
  await db.runAsync('DELETE FROM recipe_group_items WHERE id = ?', [itemId]);
}

export async function reorderGroupItems(db: SQLiteDatabase, orderedItemIds: string[]): Promise<void> {
  for (let i = 0; i < orderedItemIds.length; i++) {
    await db.runAsync('UPDATE recipe_group_items SET sort_order = ? WHERE id = ?', [i, orderedItemIds[i]]);
  }
}

// ---------- Extra cost mutations ----------

export async function addExtraCost(db: SQLiteDatabase, recipeId: string, label: string, cost: number): Promise<string> {
  const id = newId();
  const maxOrder = await db.getFirstAsync<{ max_order: number | null }>(
    'SELECT MAX(sort_order) as max_order FROM recipe_extra_costs WHERE recipe_id = ?',
    [recipeId]
  );
  const sortOrder = (maxOrder?.max_order ?? -1) + 1;
  await db.runAsync(
    'INSERT INTO recipe_extra_costs (id, recipe_id, label, cost, sort_order) VALUES (?, ?, ?, ?, ?)',
    [id, recipeId, label, cost, sortOrder]
  );
  return id;
}

export async function updateExtraCost(db: SQLiteDatabase, id: string, label: string, cost: number): Promise<void> {
  await db.runAsync('UPDATE recipe_extra_costs SET label = ?, cost = ? WHERE id = ?', [label, cost, id]);
}

export async function deleteExtraCost(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('DELETE FROM recipe_extra_costs WHERE id = ?', [id]);
}
