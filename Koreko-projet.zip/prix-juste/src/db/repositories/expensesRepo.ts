import { type SQLiteDatabase } from 'expo-sqlite';
import { CategoryBreakdownRow, Expense, SpendingEntry } from '../../types/models';
import { newId } from '../../utils/uuid';

interface ExpenseRow {
  id: string;
  category_id: string | null;
  category_name: string | null;
  expense_date: string;
  amount: number;
  payee: string | null;
  note: string | null;
  created_at: string;
}

function mapExpenseRow(r: ExpenseRow): Expense {
  return {
    id: r.id,
    categoryId: r.category_id,
    categoryName: r.category_name,
    expenseDate: r.expense_date,
    amount: r.amount,
    payee: r.payee,
    note: r.note,
    createdAt: r.created_at,
  };
}

export interface ExpenseInput {
  categoryId: string | null;
  expenseDate: string;
  amount: number;
  payee: string | null;
  note: string | null;
}

export async function listExpenses(db: SQLiteDatabase): Promise<Expense[]> {
  const rows = await db.getAllAsync<ExpenseRow>(
    `SELECT e.*, ec.name as category_name FROM expenses e
     LEFT JOIN expense_categories ec ON ec.id = e.category_id
     ORDER BY e.expense_date DESC, e.created_at DESC`
  );
  return rows.map(mapExpenseRow);
}

export async function getExpense(db: SQLiteDatabase, id: string): Promise<Expense | null> {
  const row = await db.getFirstAsync<ExpenseRow>(
    `SELECT e.*, ec.name as category_name FROM expenses e
     LEFT JOIN expense_categories ec ON ec.id = e.category_id
     WHERE e.id = ?`,
    [id]
  );
  return row ? mapExpenseRow(row) : null;
}

export async function createExpense(db: SQLiteDatabase, input: ExpenseInput): Promise<string> {
  const id = newId();
  await db.runAsync(
    `INSERT INTO expenses (id, category_id, expense_date, amount, payee, note, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [id, input.categoryId, input.expenseDate, input.amount, input.payee, input.note, new Date().toISOString()]
  );
  return id;
}

export async function updateExpense(db: SQLiteDatabase, id: string, input: ExpenseInput): Promise<void> {
  await db.runAsync(
    `UPDATE expenses SET category_id = ?, expense_date = ?, amount = ?, payee = ?, note = ? WHERE id = ?`,
    [input.categoryId, input.expenseDate, input.amount, input.payee, input.note, id]
  );
}

export async function deleteExpense(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('DELETE FROM expenses WHERE id = ?', [id]);
}

// The single combined feed: general expenses and ingredient purchases,
// merged into one chronological list — so the user has one place to see
// everything they've spent, without re-entering ingredient purchases here.
// `monthPrefix` is 'YYYY-MM' to restrict to one month, or '' for every period (LIKE '%').
// Aucune coupure à 300 lignes : toute la période demandée est listée (la liste est virtualisée).
export async function getSpendingFeed(db: SQLiteDatabase, monthPrefix: string, limit = 1000000): Promise<SpendingEntry[]> {
  const pattern = `${monthPrefix}%`;
  const expenseRows = await db.getAllAsync<{
    id: string;
    expense_date: string;
    amount: number;
    payee: string | null;
    note: string | null;
    category_name: string | null;
  }>(
    `SELECT e.id, e.expense_date, e.amount, e.payee, e.note, ec.name as category_name
     FROM expenses e LEFT JOIN expense_categories ec ON ec.id = e.category_id
     WHERE e.expense_date LIKE ?
     ORDER BY e.expense_date DESC, e.created_at DESC LIMIT ?`,
    [pattern, limit]
  );
  const purchaseRows = await db.getAllAsync<{
    id: string;
    purchase_date: string;
    price: number;
    ingredient_id: string;
    ingredient_name: string;
    supplier_name: string;
    note: string | null;
  }>(
    `SELECT p.id, p.purchase_date, p.price, p.ingredient_id, i.name as ingredient_name, s.name as supplier_name, p.note
     FROM ingredient_purchases p
     JOIN ingredients i ON i.id = p.ingredient_id
     JOIN suppliers s ON s.id = p.supplier_id
     WHERE p.purchase_date LIKE ?
     ORDER BY p.purchase_date DESC, p.created_at DESC LIMIT ?`,
    [pattern, limit]
  );

  const entries: SpendingEntry[] = [
    ...expenseRows.map((r) => ({
      id: r.id,
      kind: 'expense' as const,
      date: r.expense_date,
      amount: r.amount,
      label: r.payee?.trim() || r.category_name || null,
      categoryOrSupplier: r.category_name,
      note: r.note,
    })),
    ...purchaseRows.map((r) => ({
      id: r.id,
      kind: 'ingredientPurchase' as const,
      date: r.purchase_date,
      amount: r.price,
      label: r.ingredient_name,
      categoryOrSupplier: r.supplier_name,
      ingredientId: r.ingredient_id,
      note: r.note,
    })),
  ];
  entries.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
  return entries.slice(0, limit);
}

// Mirrors a classic "spending by category" report: every expense category this month, plus one
// row per ingredient bought (each ingredient counts as its own category).
export async function getMonthlyCategoryBreakdown(db: SQLiteDatabase, monthPrefix: string): Promise<CategoryBreakdownRow[]> {
  const pattern = `${monthPrefix}%`;
  const expenseRows = await db.getAllAsync<{ category_id: string | null; name: string | null; total: number; count: number }>(
    `SELECT e.category_id as category_id, ec.name as name, SUM(e.amount) as total, COUNT(*) as count
     FROM expenses e LEFT JOIN expense_categories ec ON ec.id = e.category_id
     WHERE e.expense_date LIKE ?
     GROUP BY e.category_id`,
    [pattern]
  );
  // Chaque ingrédient est une catégorie à part entière (ex: « Crème » : combien en septembre ?).
  const purchaseRows = await db.getAllAsync<{ ingredient_id: string; name: string; total: number; count: number }>(
    `SELECT p.ingredient_id, i.name, SUM(p.price) as total, COUNT(*) as count
     FROM ingredient_purchases p JOIN ingredients i ON i.id = p.ingredient_id
     WHERE p.purchase_date LIKE ?
     GROUP BY p.ingredient_id`,
    [pattern]
  );

  const rows: Omit<CategoryBreakdownRow, 'percent'>[] = expenseRows.map((r) => ({
    categoryId: r.category_id,
    categoryName: r.name,
    isIngredientPurchases: false,
    total: r.total,
    count: r.count,
  }));
  for (const r of purchaseRows) {
    rows.push({
      categoryId: null,
      categoryName: r.name,
      isIngredientPurchases: true,
      ingredientId: r.ingredient_id,
      total: r.total,
      count: r.count,
    });
  }

  const grandTotal = rows.reduce((sum, r) => sum + r.total, 0);
  rows.sort((a, b) => b.total - a.total);
  return rows.map((r) => ({ ...r, percent: grandTotal > 0 ? (r.total / grandTotal) * 100 : 0 }));
}

// The individual records behind one row of the category report, so the user can
// see how a total was made up (e.g. 2 × 400 or 600 + 200) and the notes they wrote.
export async function getCategoryBreakdownEntries(
  db: SQLiteDatabase,
  monthPrefix: string,
  row: Pick<CategoryBreakdownRow, 'categoryId' | 'isIngredientPurchases' | 'ingredientId'>
): Promise<SpendingEntry[]> {
  const pattern = `${monthPrefix}%`;
  if (row.isIngredientPurchases) {
    const rows = await db.getAllAsync<{
      id: string;
      purchase_date: string;
      price: number;
      quantity: number;
      unit: string;
      vat_rate: number;
      note: string | null;
      ingredient_id: string;
      ingredient_name: string;
      supplier_name: string;
    }>(
      `SELECT p.id, p.purchase_date, p.price, p.quantity, p.unit, p.vat_rate, p.note, p.ingredient_id,
              i.name as ingredient_name, s.name as supplier_name
       FROM ingredient_purchases p
       JOIN ingredients i ON i.id = p.ingredient_id
       JOIN suppliers s ON s.id = p.supplier_id
       WHERE p.purchase_date LIKE ? AND (? IS NULL OR p.ingredient_id = ?)
       ORDER BY p.purchase_date DESC, p.created_at DESC`,
      [pattern, row.ingredientId ?? null, row.ingredientId ?? null]
    );
    return rows.map((r) => ({
      id: r.id,
      kind: 'ingredientPurchase' as const,
      date: r.purchase_date,
      amount: r.price,
      label: r.ingredient_name,
      categoryOrSupplier: r.supplier_name,
      ingredientId: r.ingredient_id,
      note: r.note,
      quantity: r.quantity,
      unit: r.unit,
      vatRate: r.vat_rate,
    }));
  }
  const rows = await db.getAllAsync<{
    id: string;
    expense_date: string;
    amount: number;
    payee: string | null;
    note: string | null;
    category_name: string | null;
  }>(
    `SELECT e.id, e.expense_date, e.amount, e.payee, e.note, ec.name as category_name
     FROM expenses e LEFT JOIN expense_categories ec ON ec.id = e.category_id
     WHERE e.expense_date LIKE ? AND e.category_id IS ?
     ORDER BY e.expense_date DESC, e.created_at DESC`,
    [pattern, row.categoryId]
  );
  return rows.map((r) => ({
    id: r.id,
    kind: 'expense' as const,
    date: r.expense_date,
    amount: r.amount,
    label: r.payee?.trim() || null,
    categoryOrSupplier: r.category_name,
    note: r.note,
  }));
}

// `monthPrefix` is 'YYYY-MM' (dates are stored as 'YYYY-MM-DD' text, so a
// prefix match is enough — no need to parse dates).
export async function getMonthlyTotal(db: SQLiteDatabase, monthPrefix: string): Promise<number> {
  const pattern = `${monthPrefix}%`;
  const expenseTotal = await db.getFirstAsync<{ total: number }>(
    'SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE expense_date LIKE ?',
    [pattern]
  );
  const purchaseTotal = await db.getFirstAsync<{ total: number }>(
    'SELECT COALESCE(SUM(price), 0) as total FROM ingredient_purchases WHERE purchase_date LIKE ?',
    [pattern]
  );
  return (expenseTotal?.total ?? 0) + (purchaseTotal?.total ?? 0);
}
