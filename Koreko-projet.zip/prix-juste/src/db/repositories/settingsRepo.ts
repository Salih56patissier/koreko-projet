import { type SQLiteDatabase } from 'expo-sqlite';
import { AppSettings } from '../../types/models';
import { DEFAULT_ACCENT_THEME_ID } from '../../theme/accentThemes';

interface SettingsRow {
  default_hourly_rate: number;
  currency_symbol: string;
  gemini_api_key: string | null;
  accent_theme: string;
  auto_backup_folder_uri: string | null;
  last_auto_backup_at: string | null;
  locale: string | null;
  onboarding_seen: number;
}

export async function getSettings(db: SQLiteDatabase): Promise<AppSettings> {
  const row = await db.getFirstAsync<SettingsRow>(
    'SELECT default_hourly_rate, currency_symbol, gemini_api_key, accent_theme, auto_backup_folder_uri, last_auto_backup_at, locale, onboarding_seen FROM app_settings WHERE id = 1'
  );
  return {
    defaultHourlyRate: row?.default_hourly_rate ?? 17.92,
    currencySymbol: row?.currency_symbol ?? 'DH',
    geminiApiKey: row?.gemini_api_key ?? null,
    accentThemeId: row?.accent_theme ?? DEFAULT_ACCENT_THEME_ID,
    autoBackupFolderUri: row?.auto_backup_folder_uri ?? null,
    lastAutoBackupAt: row?.last_auto_backup_at ?? null,
    locale: row?.locale ?? null,
    onboardingSeen: (row?.onboarding_seen ?? 0) === 1,
  };
}

export async function markOnboardingSeen(db: SQLiteDatabase): Promise<void> {
  await db.runAsync('UPDATE app_settings SET onboarding_seen = 1, updated_at = ? WHERE id = 1', [
    new Date().toISOString(),
  ]);
}

export async function updateSettings(
  db: SQLiteDatabase,
  settings: Pick<AppSettings, 'defaultHourlyRate' | 'currencySymbol'>
): Promise<void> {
  await db.runAsync(
    'UPDATE app_settings SET default_hourly_rate = ?, currency_symbol = ?, updated_at = ? WHERE id = 1',
    [settings.defaultHourlyRate, settings.currencySymbol, new Date().toISOString()]
  );
}

export async function updateGeminiApiKey(db: SQLiteDatabase, apiKey: string | null): Promise<void> {
  await db.runAsync('UPDATE app_settings SET gemini_api_key = ?, updated_at = ? WHERE id = 1', [
    apiKey,
    new Date().toISOString(),
  ]);
}

export async function updateAccentTheme(db: SQLiteDatabase, themeId: string): Promise<void> {
  await db.runAsync('UPDATE app_settings SET accent_theme = ?, updated_at = ? WHERE id = 1', [
    themeId,
    new Date().toISOString(),
  ]);
}

export async function updateAutoBackupFolder(db: SQLiteDatabase, folderUri: string | null): Promise<void> {
  await db.runAsync('UPDATE app_settings SET auto_backup_folder_uri = ?, updated_at = ? WHERE id = 1', [
    folderUri,
    new Date().toISOString(),
  ]);
}

export async function updateLastAutoBackupAt(db: SQLiteDatabase, isoDate: string): Promise<void> {
  await db.runAsync('UPDATE app_settings SET last_auto_backup_at = ? WHERE id = 1', [isoDate]);
}

export async function updateLocale(db: SQLiteDatabase, locale: string | null): Promise<void> {
  await db.runAsync('UPDATE app_settings SET locale = ?, updated_at = ? WHERE id = 1', [
    locale,
    new Date().toISOString(),
  ]);
}
