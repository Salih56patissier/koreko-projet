import { type SQLiteDatabase } from 'expo-sqlite';
import { CategoryWithCount } from '../../types/models';
import { newId } from '../../utils/uuid';

interface CategoryRow {
  id: string;
  name: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
  recipe_count: number;
}

function mapRow(row: CategoryRow): CategoryWithCount {
  return {
    id: row.id,
    name: row.name,
    sortOrder: row.sort_order,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    recipeCount: row.recipe_count,
  };
}

export async function listCategories(db: SQLiteDatabase): Promise<CategoryWithCount[]> {
  const rows = await db.getAllAsync<CategoryRow>(
    `SELECT c.*, (SELECT COUNT(*) FROM recipes r WHERE r.category_id = c.id) as recipe_count
     FROM categories c
     ORDER BY c.sort_order ASC, c.name ASC`
  );
  return rows.map(mapRow);
}

export async function createCategory(db: SQLiteDatabase, name: string): Promise<string> {
  const id = newId();
  const now = new Date().toISOString();
  const maxOrder = await db.getFirstAsync<{ max_order: number | null }>(
    'SELECT MAX(sort_order) as max_order FROM categories'
  );
  const sortOrder = (maxOrder?.max_order ?? -1) + 1;
  await db.runAsync(
    'INSERT INTO categories (id, name, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
    [id, name, sortOrder, now, now]
  );
  return id;
}

export async function updateCategory(db: SQLiteDatabase, id: string, name: string): Promise<void> {
  await db.runAsync('UPDATE categories SET name = ?, updated_at = ? WHERE id = ?', [
    name,
    new Date().toISOString(),
    id,
  ]);
}

// Ordre choisi par glisser-déposer (écran « Réorganiser »).
export async function reorderCategories(db: SQLiteDatabase, orderedIds: string[]): Promise<void> {
  for (let i = 0; i < orderedIds.length; i++) {
    await db.runAsync('UPDATE categories SET sort_order = ? WHERE id = ?', [i, orderedIds[i]]);
  }
}

export async function deleteCategory(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('DELETE FROM categories WHERE id = ?', [id]);
}
