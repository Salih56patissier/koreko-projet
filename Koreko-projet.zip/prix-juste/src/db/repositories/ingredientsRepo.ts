import { type SQLiteDatabase } from 'expo-sqlite';
import { Ingredient, PurchaseUnit } from '../../types/models';
import { newId } from '../../utils/uuid';
import { baseUnitForPurchaseUnit, computeUnitPrice, priceExcludingVat } from '../../utils/priceCalc';
import { resyncIngredientCurrentPrice } from './ingredientPurchasesRepo';
import { normalizeSearch } from '../../utils/normalize';

interface IngredientRow {
  id: string;
  name: string;
  purchase_price: number;
  purchase_quantity: number;
  purchase_unit: PurchaseUnit;
  base_unit: 'g' | 'ml' | 'unite';
  unit_price: number;
  vat_rate: number;
  category_id: string | null;
  avg_piece_weight_g: number | null;
  archived?: number;
  created_at: string;
  updated_at: string;
}

function mapRow(row: IngredientRow): Ingredient {
  return {
    id: row.id,
    name: row.name,
    purchasePrice: row.purchase_price,
    purchaseQuantity: row.purchase_quantity,
    purchaseUnit: row.purchase_unit,
    baseUnit: row.base_unit,
    unitPrice: row.unit_price,
    vatRate: row.vat_rate,
    categoryId: row.category_id,
    avgPieceWeightG: row.avg_piece_weight_g,
    archived: row.archived === 1,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// SQLite's NOCASE collation only folds ASCII A-Z — it sorts accented letters
// (like the î in "Boîte") by raw Unicode code point, far away from their
// unaccented equivalent ("Boite"), which looks broken to a human reader. So
// the actual alphabetical order is done here in JS, ignoring both case and
// accents, instead of relying on SQL ORDER BY.
function sortKey(name: string): string {
  return name.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

// Les ingrédients « supprimés » mais gardés (leurs achats restent dans la Caisse) ne sont pas listés.
export async function listIngredients(db: SQLiteDatabase, search?: string): Promise<Ingredient[]> {
  const rows = await db.getAllAsync<IngredientRow>('SELECT * FROM ingredients WHERE archived = 0');
  let ingredients = rows.map(mapRow);
  // Filtré en JS plutôt qu'en SQL (LIKE + COLLATE NOCASE ne gère ni les accents ni les espaces
  // en trop) : le clavier du téléphone ajoute souvent un espace après un mot suggéré, et "crème"
  // tapé sans accent doit quand même retrouver "Crème".
  if (search && search.trim()) {
    const needle = normalizeSearch(search);
    ingredients = ingredients.filter((i) => normalizeSearch(i.name).includes(needle));
  }
  ingredients.sort((a, b) => {
    const ka = sortKey(a.name);
    const kb = sortKey(b.name);
    return ka < kb ? -1 : ka > kb ? 1 : 0;
  });
  return ingredients;
}

export async function getIngredient(db: SQLiteDatabase, id: string): Promise<Ingredient | null> {
  const row = await db.getFirstAsync<IngredientRow>('SELECT * FROM ingredients WHERE id = ?', [id]);
  return row ? mapRow(row) : null;
}

export interface IngredientInput {
  name: string;
  purchasePrice: number;
  purchaseQuantity: number;
  purchaseUnit: PurchaseUnit;
  vatRate: number;
  categoryId: string | null;
  // Poids en grammes d'UNE unité d'achat (pièce, paquet, carton, ou litre pesé) : le prix est alors
  // ramené au gramme. Absent = inconnu (usage à la pièce).
  avgPieceWeightG?: number | null;
}

// Seul un poids d'une PIÈCE sert à convertir « 2 œufs » ↔ « 100 g » dans les recettes.
function pieceWeightColumn(unit: PurchaseUnit, weightG: number | null, previous: number | null = null): number | null {
  return unit === 'unite' && weightG ? weightG : previous;
}

export async function createIngredient(db: SQLiteDatabase, input: IngredientInput): Promise<string> {
  const id = newId();
  const now = new Date().toISOString();
  const weightG = input.avgPieceWeightG ?? null;
  const avgPieceWeightG = pieceWeightColumn(input.purchaseUnit, weightG);
  const baseUnit = baseUnitForPurchaseUnit(input.purchaseUnit, weightG);
  const priceHt = priceExcludingVat(input.purchasePrice, input.vatRate);
  const unitPrice = computeUnitPrice(priceHt, input.purchaseQuantity, input.purchaseUnit, weightG);
  await db.runAsync(
    `INSERT INTO ingredients (id, name, purchase_price, purchase_quantity, purchase_unit, base_unit, unit_price, vat_rate, category_id, avg_piece_weight_g, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, input.name, input.purchasePrice, input.purchaseQuantity, input.purchaseUnit, baseUnit, unitPrice, input.vatRate, input.categoryId, avgPieceWeightG, now, now]
  );
  return id;
}

export async function updateIngredient(db: SQLiteDatabase, id: string, input: IngredientInput): Promise<void> {
  const now = new Date().toISOString();
  const weightG = input.avgPieceWeightG ?? null;
  const existing = await db.getFirstAsync<{ avg_piece_weight_g: number | null }>(
    'SELECT avg_piece_weight_g FROM ingredients WHERE id = ?',
    [id]
  );
  const avgPieceWeightG = pieceWeightColumn(input.purchaseUnit, weightG, existing?.avg_piece_weight_g ?? null);
  const baseUnit = baseUnitForPurchaseUnit(input.purchaseUnit, weightG);
  const priceHt = priceExcludingVat(input.purchasePrice, input.vatRate);
  const unitPrice = computeUnitPrice(priceHt, input.purchaseQuantity, input.purchaseUnit, weightG);
  await db.runAsync(
    `UPDATE ingredients SET name = ?, purchase_price = ?, purchase_quantity = ?, purchase_unit = ?, base_unit = ?, unit_price = ?, vat_rate = ?, category_id = ?, avg_piece_weight_g = ?, updated_at = ?
     WHERE id = ?`,
    [input.name, input.purchasePrice, input.purchaseQuantity, input.purchaseUnit, baseUnit, unitPrice, input.vatRate, input.categoryId, avgPieceWeightG, now, id]
  );
}

// Modifie la fiche d'un ingrédient existant (nom, catégorie, taux de TVA des prochains achats)
// SANS toucher à son prix : le prix actuel vient du dernier achat (avec son propre taux de TVA) ou
// d'une correction manuelle, et ne doit pas bouger quand on renomme l'ingrédient.
export async function updateIngredientDetails(
  db: SQLiteDatabase,
  id: string,
  input: { name: string; categoryId: string | null; vatRate: number }
): Promise<void> {
  await db.runAsync('UPDATE ingredients SET name = ?, category_id = ?, vat_rate = ?, updated_at = ? WHERE id = ?', [
    input.name,
    input.categoryId,
    input.vatRate,
    new Date().toISOString(),
    id,
  ]);
}

// Indique (ou corrige) le poids d'UNE unité d'achat de cet ingrédient : le prix de ses achats déjà
// faits dans cette unité est alors ramené au gramme, et ses recettes passent au poids. Utilisé
// quand on met dans une recette un ingrédient acheté à la pièce / au paquet / au carton.
export async function setIngredientUnitWeight(db: SQLiteDatabase, id: string, weightG: number): Promise<void> {
  const ing = await db.getFirstAsync<IngredientRow>('SELECT * FROM ingredients WHERE id = ?', [id]);
  if (!ing || !(weightG > 0)) return;
  const purchaseCount = await db.getFirstAsync<{ c: number }>(
    'SELECT COUNT(*) as c FROM ingredient_purchases WHERE ingredient_id = ?',
    [id]
  );
  if ((purchaseCount?.c ?? 0) > 0) {
    await db.runAsync(
      'UPDATE ingredient_purchases SET unit_weight_g = ? WHERE ingredient_id = ? AND unit = ? AND unit_weight_g IS NULL',
      [weightG, id, ing.purchase_unit]
    );
    if (ing.purchase_unit === 'unite') {
      await db.runAsync('UPDATE ingredients SET avg_piece_weight_g = ? WHERE id = ?', [weightG, id]);
    }
    await resyncIngredientCurrentPrice(db, id);
    return;
  }
  // Prix saisi à la main, sans achat : on le recalcule directement.
  const priceHt = priceExcludingVat(ing.purchase_price, ing.vat_rate);
  const baseUnit = baseUnitForPurchaseUnit(ing.purchase_unit, weightG);
  const unitPrice = computeUnitPrice(priceHt, ing.purchase_quantity, ing.purchase_unit, weightG);
  await db.runAsync(
    'UPDATE ingredients SET base_unit = ?, unit_price = ?, avg_piece_weight_g = ?, updated_at = ? WHERE id = ?',
    [baseUnit, unitPrice, pieceWeightColumn(ing.purchase_unit, weightG, ing.avg_piece_weight_g), new Date().toISOString(), id]
  );
}

// Taux de TVA des PROCHAINS achats : n'a aucun effet sur le prix actuel.
export async function updateIngredientVatRate(db: SQLiteDatabase, id: string, vatRate: number): Promise<void> {
  await db.runAsync('UPDATE ingredients SET vat_rate = ?, updated_at = ? WHERE id = ?', [vatRate, new Date().toISOString(), id]);
}

export class IngredientInUseError extends Error {}

// « Supprimer » un ingrédient :
//  - utilisé dans une recette → refusé (message) ;
//  - sans achat enregistré → vraiment supprimé ;
//  - avec des achats → ARCHIVÉ : il disparaît des listes et des sélecteurs, mais ses achats restent
//    dans la Caisse (les dépenses passées et le solde ne changent pas).
export async function deleteIngredient(db: SQLiteDatabase, id: string): Promise<'deleted' | 'archived'> {
  const used = await db.getFirstAsync<{ c: number }>(
    'SELECT COUNT(*) as c FROM recipe_group_items WHERE ingredient_id = ?',
    [id]
  );
  if ((used?.c ?? 0) > 0) {
    throw new IngredientInUseError(
      "Cet ingrédient est utilisé dans une ou plusieurs recettes : impossible de le supprimer."
    );
  }
  await db.runAsync('DELETE FROM shopping_list_items WHERE ingredient_id = ?', [id]);
  const purchases = await db.getFirstAsync<{ c: number }>(
    'SELECT COUNT(*) as c FROM ingredient_purchases WHERE ingredient_id = ?',
    [id]
  );
  if ((purchases?.c ?? 0) > 0) {
    await db.runAsync('UPDATE ingredients SET archived = 1, updated_at = ? WHERE id = ?', [new Date().toISOString(), id]);
    return 'archived';
  }
  await db.runAsync('DELETE FROM ingredients WHERE id = ?', [id]);
  return 'deleted';
}
