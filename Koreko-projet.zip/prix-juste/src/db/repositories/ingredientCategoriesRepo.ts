import { type SQLiteDatabase } from 'expo-sqlite';
import { IngredientCategory } from '../../types/models';
import { newId } from '../../utils/uuid';
import { colorForIndex } from '../../theme/colors';

interface IngredientCategoryRow {
  id: string;
  name: string;
  color: string;
  created_at: string;
}

function mapRow(row: IngredientCategoryRow): IngredientCategory {
  return { id: row.id, name: row.name, color: row.color, createdAt: row.created_at };
}

export async function listIngredientCategories(db: SQLiteDatabase): Promise<IngredientCategory[]> {
  const rows = await db.getAllAsync<IngredientCategoryRow>(
    'SELECT * FROM ingredient_categories ORDER BY created_at ASC'
  );
  return rows.map(mapRow);
}

export async function createIngredientCategory(db: SQLiteDatabase, name: string): Promise<string> {
  const id = newId();
  const now = new Date().toISOString();
  const count = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM ingredient_categories');
  const color = colorForIndex(count?.count ?? 0);
  await db.runAsync('INSERT INTO ingredient_categories (id, name, color, created_at) VALUES (?, ?, ?, ?)', [
    id,
    name,
    color,
    now,
  ]);
  return id;
}

export async function updateIngredientCategory(db: SQLiteDatabase, id: string, name: string): Promise<void> {
  await db.runAsync('UPDATE ingredient_categories SET name = ? WHERE id = ?', [name, id]);
}

// Ingredients keep existing (they just lose their color tag), rather than
// being deleted along with the category — the category is only a label.
export async function deleteIngredientCategory(db: SQLiteDatabase, id: string): Promise<void> {
  await db.runAsync('UPDATE ingredients SET category_id = NULL WHERE category_id = ?', [id]);
  await db.runAsync('DELETE FROM ingredient_categories WHERE id = ?', [id]);
}
