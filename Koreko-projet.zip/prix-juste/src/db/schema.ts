export const CREATE_TABLES_SQL = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS ingredient_categories (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  color TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ingredients (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  purchase_price REAL NOT NULL,
  purchase_quantity REAL NOT NULL,
  purchase_unit TEXT NOT NULL,
  base_unit TEXT NOT NULL,
  unit_price REAL NOT NULL,
  vat_rate REAL NOT NULL DEFAULT 0,
  category_id TEXT REFERENCES ingredient_categories(id),
  avg_piece_weight_g REAL,
  archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS process_actions (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  color TEXT NOT NULL,
  is_custom INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS recipes (
  id TEXT PRIMARY KEY NOT NULL,
  category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  photo_uri TEXT,
  labor_hours REAL NOT NULL DEFAULT 0,
  hourly_rate REAL NOT NULL DEFAULT 17.92,
  margin_percent REAL NOT NULL DEFAULT 0,
  servings INTEGER NOT NULL DEFAULT 1,
  billed_price REAL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS recipe_groups (
  id TEXT PRIMARY KEY NOT NULL,
  recipe_id TEXT NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  instruction TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS recipe_group_process_tags (
  group_id TEXT NOT NULL REFERENCES recipe_groups(id) ON DELETE CASCADE,
  process_action_id TEXT NOT NULL REFERENCES process_actions(id),
  PRIMARY KEY (group_id, process_action_id)
);

CREATE TABLE IF NOT EXISTS recipe_group_items (
  id TEXT PRIMARY KEY NOT NULL,
  group_id TEXT NOT NULL REFERENCES recipe_groups(id) ON DELETE CASCADE,
  ingredient_id TEXT REFERENCES ingredients(id),
  component_recipe_id TEXT REFERENCES recipes(id),
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  note TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  CHECK (
    (ingredient_id IS NOT NULL AND component_recipe_id IS NULL) OR
    (ingredient_id IS NULL AND component_recipe_id IS NOT NULL)
  )
);

CREATE TABLE IF NOT EXISTS recipe_extra_costs (
  id TEXT PRIMARY KEY NOT NULL,
  recipe_id TEXT NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  cost REAL NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dismissed_hints (
  id TEXT PRIMARY KEY NOT NULL
);

CREATE TABLE IF NOT EXISTS suppliers (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ingredient_purchases (
  id TEXT PRIMARY KEY NOT NULL,
  ingredient_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  supplier_id TEXT NOT NULL REFERENCES suppliers(id),
  purchase_date TEXT NOT NULL,
  price REAL NOT NULL,
  vat_rate REAL NOT NULL DEFAULT 0,
  price_ht REAL NOT NULL DEFAULT 0,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  unit_weight_g REAL,
  note TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shopping_list_items (
  id TEXT PRIMARY KEY NOT NULL,
  ingredient_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  supplier_id TEXT REFERENCES suppliers(id) ON DELETE SET NULL,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  checked INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS expense_categories (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS expenses (
  id TEXT PRIMARY KEY NOT NULL,
  category_id TEXT REFERENCES expense_categories(id),
  expense_date TEXT NOT NULL,
  amount REAL NOT NULL,
  payee TEXT,
  note TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sale_categories (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sales (
  id TEXT PRIMARY KEY NOT NULL,
  category_id TEXT REFERENCES sale_categories(id),
  sale_date TEXT NOT NULL,
  amount REAL NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  default_hourly_rate REAL NOT NULL DEFAULT 17.92,
  currency_symbol TEXT NOT NULL DEFAULT 'DH',
  gemini_api_key TEXT,
  accent_theme TEXT NOT NULL DEFAULT 'caramel',
  auto_backup_folder_uri TEXT,
  last_auto_backup_at TEXT,
  locale TEXT,
  expense_categories_daily_app_seeded INTEGER,
  -- Marqueurs des migrations ponctuelles : présents dès la création sur une installation neuve,
  -- pour qu'elles ne tournent jamais chez un nouvel utilisateur (elles ne concernent que les
  -- données de l'utilisatrice d'origine). Voir database.ts.
  august_2026_history_seeded INTEGER,
  raw_material_expense_categories_removed INTEGER,
  vat_default_reset_to_zero INTEGER,
  zero_price_ht_repaired INTEGER,
  onboarding_seen INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_access (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  trial_started_at TEXT NOT NULL,
  premium INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_recipes_category ON recipes(category_id);
CREATE INDEX IF NOT EXISTS idx_recipe_groups_recipe ON recipe_groups(recipe_id);
CREATE INDEX IF NOT EXISTS idx_recipe_group_items_group ON recipe_group_items(group_id);
CREATE INDEX IF NOT EXISTS idx_recipe_extra_costs_recipe ON recipe_extra_costs(recipe_id);
CREATE INDEX IF NOT EXISTS idx_ingredient_purchases_ingredient ON ingredient_purchases(ingredient_id);
CREATE INDEX IF NOT EXISTS idx_ingredient_purchases_supplier ON ingredient_purchases(supplier_id);
CREATE INDEX IF NOT EXISTS idx_shopping_list_items_supplier ON shopping_list_items(supplier_id);
CREATE INDEX IF NOT EXISTS idx_shopping_list_items_ingredient ON shopping_list_items(ingredient_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category_id);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);
CREATE INDEX IF NOT EXISTS idx_sales_category ON sales(category_id);
`;

// Catégories proposées à un nouvel utilisateur (installation neuve) : génériques, sans nom
// d'entreprise ni de fournisseur. Traduites dans la langue du téléphone au moment de la création.
export const STARTER_EXPENSE_CATEGORIES = [
  'Loyer',
  'Salaires',
  'Électricité/Eau',
  'Gaz',
  'Téléphone /internet',
  'Emballage',
  'Transport',
  'Matériel / réparation',
  'Publicité / marketing',
  'Produits ménagers',
  'Taxes',
  'Comptable',
  'Autre',
];

export const STARTER_SALE_CATEGORIES = ['Boutique', 'Commandes', 'Revendeurs'];

export const DEFAULT_PROCESS_ACTIONS = [
  'Mélanger',
  'Fouetter',
  'Chauffer',
  'Faire bouillir',
  'Congeler',
  'Cuire au four',
  'Tamiser',
  'Foisonner',
  'Pétrir',
  'Laisser reposer/pousser',
  'Refroidir',
  'Chinoiser',
];
