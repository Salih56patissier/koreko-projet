import { type SQLiteDatabase } from 'expo-sqlite';
import {
  CREATE_TABLES_SQL,
  DEFAULT_PROCESS_ACTIONS,
  STARTER_EXPENSE_CATEGORIES,
  STARTER_SALE_CATEGORIES,
} from './schema';
import * as Localization from 'expo-localization';
import { translateForDevice as tr } from '../i18n/I18nContext';
import { EGG_WEIGHT_G, looksLikeEgg } from '../utils/normalize';
import { toBaseQuantity } from '../utils/priceCalc';
import { colorForIndex } from '../theme/colors';
import { newId } from '../utils/uuid';
import { baseUnitForPurchaseUnit, computeUnitPrice } from '../utils/priceCalc';
import { PurchaseUnit } from '../types/models';

export const DATABASE_NAME = 'prixjuste.db';

// Deux éditions de l'application :
//  - « personal » (par défaut) : celle de l'utilisatrice d'origine, avec ses données et ses
//    anciennes migrations personnelles ;
//  - « public » (EXPO_PUBLIC_KOREKO_EDITION=public au moment du build, voir build-public.ps1) :
//    vide, avec seulement des exemples. Le fichier personalData.ts n'y est PAS embarqué.
// Metro remplace la variable à la compilation puis supprime la branche inutilisée, donc le
// `require` ci-dessous disparaît de la version publique.
const personal: typeof import('./personalData') | null =
  process.env.EXPO_PUBLIC_KOREKO_EDITION !== 'public' ? require('./personalData') : null;
const AUGUST_2026_EXPENSES = personal?.AUGUST_2026_EXPENSES ?? [];
const AUGUST_2026_SALES = personal?.AUGUST_2026_SALES ?? [];
const DEFAULT_EXPENSE_CATEGORIES = personal?.DEFAULT_EXPENSE_CATEGORIES ?? [];
const RAW_MATERIAL_EXPENSE_CATEGORY_NAMES_TO_REMOVE = personal?.RAW_MATERIAL_EXPENSE_CATEGORY_NAMES_TO_REMOVE ?? [];

// Older installs have `recipe_group_items` without `component_recipe_id`
// (and with `ingredient_id NOT NULL`, incompatible with sub-recipe rows).
// SQLite can't ALTER a column's nullability, so the table is rebuilt.
async function migrateRecipeGroupItemsForComponents(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('recipe_group_items')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasComponentColumn = columns.some((c) => c.name === 'component_recipe_id');
  if (hasComponentColumn) return;

  await db.execAsync('ALTER TABLE recipe_group_items RENAME TO recipe_group_items_old;');
}

async function finishRecipeGroupItemsMigration(db: SQLiteDatabase): Promise<void> {
  const oldTable = await db.getFirstAsync("SELECT name FROM sqlite_master WHERE type='table' AND name='recipe_group_items_old'");
  if (!oldTable) return;

  await db.execAsync(`
    INSERT INTO recipe_group_items (id, group_id, ingredient_id, component_recipe_id, quantity, unit, note, sort_order)
      SELECT id, group_id, ingredient_id, NULL, quantity, unit, note, sort_order FROM recipe_group_items_old;
    DROP TABLE recipe_group_items_old;
  `);
}

async function migrateAppSettingsGeminiKey(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasColumn = columns.some((c) => c.name === 'gemini_api_key');
  if (hasColumn) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN gemini_api_key TEXT;');
}

async function migrateIngredientCategoryId(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('ingredients')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasColumn = columns.some((c) => c.name === 'category_id');
  if (hasColumn) return;
  await db.execAsync('ALTER TABLE ingredients ADD COLUMN category_id TEXT REFERENCES ingredient_categories(id);');
}

// TVA sur les ingrédients : taux stocké sur l'ingrédient (vat_rate) + prix HT calculé et figé
// par achat (price_ht), à côté du prix payé (price, TTC) déjà existant. Les achats déjà
// enregistrés avant cette fonctionnalité ne se voient pas appliquer de TVA rétroactivement —
// leur HT reste égal au prix payé tel quel, pour ne pas changer silencieusement le coût de
// recettes déjà calculées. Seuls les nouveaux achats utilisent le taux de TVA de l'ingrédient.
async function migrateVatSupport(db: SQLiteDatabase): Promise<void> {
  const ingredientColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('ingredients')");
  if (ingredientColumns.length > 0 && !ingredientColumns.some((c) => c.name === 'vat_rate')) {
    await db.execAsync('ALTER TABLE ingredients ADD COLUMN vat_rate REAL NOT NULL DEFAULT 0;');
  }

  const purchaseColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('ingredient_purchases')");
  if (purchaseColumns.length > 0 && !purchaseColumns.some((c) => c.name === 'vat_rate')) {
    await db.execAsync('ALTER TABLE ingredient_purchases ADD COLUMN vat_rate REAL NOT NULL DEFAULT 0;');
    await db.execAsync('ALTER TABLE ingredient_purchases ADD COLUMN price_ht REAL NOT NULL DEFAULT 0;');
    await db.execAsync('UPDATE ingredient_purchases SET vat_rate = 0, price_ht = price;');
  }
}

// Le taux de TVA par défaut est passé de 20% à 0% (la plupart des achats du pâtissier se font
// sans facture, donc sans TVA récupérable — voir migrateVatSupport). Les installations qui ont
// déjà tourné migrateVatSupport avant ce changement ont reçu 20% par défaut sur tous leurs
// ingrédients ; comme cette valeur n'a pas encore été ajustée manuellement à ce stade, on la
// remet à 0% une seule fois. Ne touche pas unit_price : la restauration d'une sauvegarde
// n'importe que la colonne vat_rate avec la valeur par défaut, elle ne recalcule jamais
// unit_price à l'aide de ce taux — donc rien d'autre à corriger.
async function migrateResetDefaultVatRateToZero(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return;
  const hasFlag = columns.some((c) => c.name === 'vat_default_reset_to_zero');
  if (hasFlag) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN vat_default_reset_to_zero INTEGER;');
  await db.execAsync('UPDATE ingredients SET vat_rate = 0 WHERE vat_rate = 20;');
}

// Répare les achats dont le HT est resté à 0 DH malgré un prix payé réel. Cause identifiée :
// une sauvegarde/restauration (voir l'export/import JSON dans backup/backupRepo.ts) n'exporte
// que les colonnes présentes au moment de l'export — une sauvegarde prise avant l'ajout des
// colonnes vat_rate/price_ht (migrateVatSupport ci-dessus) ne les contient donc pas, et leur
// restauration les laisse retomber sur leur valeur par défaut (0) au lieu du prix réel. Sans
// facture/taux fiable pour ces lignes-là, HT = TTC est la meilleure approximation (même logique
// que le backfill initial de migrateVatSupport) — et on resynchronise ensuite le prix courant
// de chaque ingrédient concerné, qui était lui aussi resté bloqué à 0.
async function migrateRepairZeroPriceHtFromRestore(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return;
  const hasFlag = columns.some((c) => c.name === 'zero_price_ht_repaired');
  if (hasFlag) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN zero_price_ht_repaired INTEGER;');

  const affected = await db.getAllAsync<{ ingredient_id: string }>(
    'SELECT DISTINCT ingredient_id FROM ingredient_purchases WHERE price_ht = 0 AND price > 0'
  );
  if (affected.length === 0) return;

  await db.execAsync('UPDATE ingredient_purchases SET price_ht = price WHERE price_ht = 0 AND price > 0;');

  for (const { ingredient_id } of affected) {
    const latest = await db.getFirstAsync<{
      price: number;
      price_ht: number;
      quantity: number;
      unit: PurchaseUnit;
      avg_piece_weight_g: number | null;
    }>(
      `SELECT p.price, p.price_ht, p.quantity, p.unit, i.avg_piece_weight_g
       FROM ingredient_purchases p JOIN ingredients i ON i.id = p.ingredient_id
       WHERE p.ingredient_id = ? ORDER BY p.purchase_date DESC, p.created_at DESC LIMIT 1`,
      [ingredient_id]
    );
    if (!latest) continue;
    const baseUnit = baseUnitForPurchaseUnit(latest.unit, latest.avg_piece_weight_g);
    const unitPrice = computeUnitPrice(latest.price_ht, latest.quantity, latest.unit, latest.avg_piece_weight_g);
    await db.runAsync(
      'UPDATE ingredients SET purchase_price = ?, purchase_quantity = ?, purchase_unit = ?, base_unit = ?, unit_price = ?, updated_at = ? WHERE id = ?',
      [latest.price, latest.quantity, latest.unit, baseUnit, unitPrice, new Date().toISOString(), ingredient_id]
    );
  }
}

// Les installs déjà en place n'ont pas besoin de revoir le tuto au prochain démarrage — la
// colonne se crée avec DEFAULT 1 (déjà vu) pour elles. Une install neuve, elle, passe par
// CREATE_TABLES_SQL directement avec son propre défaut à 0 (pas encore vu) — voir schema.ts.
async function migrateAppSettingsOnboarding(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasColumn = columns.some((c) => c.name === 'onboarding_seen');
  if (hasColumn) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN onboarding_seen INTEGER NOT NULL DEFAULT 1;');
}

async function migrateAppSettingsAccentTheme(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasColumn = columns.some((c) => c.name === 'accent_theme');
  if (hasColumn) return;
  await db.execAsync("ALTER TABLE app_settings ADD COLUMN accent_theme TEXT NOT NULL DEFAULT 'caramel';");
}

async function migrateAppSettingsLocale(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasColumn = columns.some((c) => c.name === 'locale');
  if (hasColumn) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN locale TEXT;');
}

async function migrateIngredientsAvgPieceWeight(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('ingredients')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasColumn = columns.some((c) => c.name === 'avg_piece_weight_g');
  if (hasColumn) return;
  await db.execAsync('ALTER TABLE ingredients ADD COLUMN avg_piece_weight_g REAL;');
}

async function migrateAppSettingsAutoBackup(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasFolder = columns.some((c) => c.name === 'auto_backup_folder_uri');
  if (!hasFolder) {
    await db.execAsync('ALTER TABLE app_settings ADD COLUMN auto_backup_folder_uri TEXT;');
  }
  const hasLastAt = columns.some((c) => c.name === 'last_auto_backup_at');
  if (!hasLastAt) {
    await db.execAsync('ALTER TABLE app_settings ADD COLUMN last_auto_backup_at TEXT;');
  }
}

// One-time: add the user's real "Dépenses quotidiennes" categories to any existing install,
// skipping ones that already exist (case-insensitive name match) so nothing is duplicated.
// Guarded by the presence of the marker column, so it only ever runs once per install.
async function migrateExpenseCategoriesFromDailyExpensesApp(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return; // fresh install, CREATE_TABLES_SQL will create the current schema
  const hasFlag = columns.some((c) => c.name === 'expense_categories_daily_app_seeded');
  if (hasFlag) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN expense_categories_daily_app_seeded INTEGER;');

  const now = new Date().toISOString();
  for (const name of DEFAULT_EXPENSE_CATEGORIES) {
    await db.runAsync(
      `INSERT INTO expense_categories (id, name, created_at)
       SELECT ?, ?, ?
       WHERE NOT EXISTS (SELECT 1 FROM expense_categories WHERE LOWER(name) = LOWER(?))`,
      [newId(), name, now, name]
    );
  }
}

// One-time: the "Rapport mensuel" (dépenses + recettes) d'août 2026 exporté
// par l'utilisateur depuis "Dépenses quotidiennes", inséré directement au
// premier lancement après cette mise à jour. Chaque ligne devient une seule
// dépense/vente "lot" pour le mois (le rapport source n'a que des totaux
// mensuels par catégorie, pas les transactions individuelles), avec le
// nombre d'opérations d'origine gardé dans la note pour référence. Guardé
// par la présence de la colonne marqueur, donc ne tourne qu'une seule fois.
async function migrateHistoricalDataAugust2026(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return; // fresh install, nothing to backfill
  const hasFlag = columns.some((c) => c.name === 'august_2026_history_seeded');
  if (hasFlag) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN august_2026_history_seeded INTEGER;');

  const now = new Date().toISOString();
  const monthEnd = '2026-08-31';

  async function findOrCreateCategory(table: 'expense_categories' | 'sale_categories', name: string): Promise<string> {
    const existing = await db.getFirstAsync<{ id: string }>(
      `SELECT id FROM ${table} WHERE LOWER(name) = LOWER(?)`,
      [name]
    );
    if (existing) return existing.id;
    const id = newId();
    await db.runAsync(`INSERT INTO ${table} (id, name, created_at) VALUES (?, ?, ?)`, [id, name, now]);
    return id;
  }

  for (const row of AUGUST_2026_EXPENSES) {
    const categoryId = await findOrCreateCategory('expense_categories', row.category);
    await db.runAsync(
      `INSERT INTO expenses (id, category_id, expense_date, amount, payee, note, created_at)
       VALUES (?, ?, ?, ?, NULL, ?, ?)`,
      [newId(), categoryId, monthEnd, row.amount, `Import rapport mensuel — ${row.count} opération(s)`, now]
    );
  }

  for (const row of AUGUST_2026_SALES) {
    const categoryId = await findOrCreateCategory('sale_categories', row.category);
    await db.runAsync(
      `INSERT INTO sales (id, category_id, sale_date, amount, note, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [newId(), categoryId, monthEnd, row.amount, `Import rapport mensuel — ${row.count} opération(s)`, now]
    );
  }
}

// One-time: matières premières (Beurre, Farine, Café...) achetées via une catégorie de dépense
// générique ne mettaient pas à jour le prix de l'ingrédient correspondant utilisé par les
// recettes — désormais elles se choisissent via le chemin "Matière première" (un ingrédient
// précis). Cette migration retire ces catégories devenues inutiles. Non destructif : les
// dépenses déjà enregistrées gardent leur montant/date, elles perdent juste l'étiquette de
// catégorie (comme toute suppression de catégorie de dépense dans l'app). Ne tourne qu'une
// seule fois. Placée après migrateHistoricalDataAugust2026 pour nettoyer les catégories que
// cet import aurait pu recréer sur une base neuve.
async function migrateRemoveRawMaterialExpenseCategories(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0) return;
  const hasFlag = columns.some((c) => c.name === 'raw_material_expense_categories_removed');
  if (hasFlag) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN raw_material_expense_categories_removed INTEGER;');

  for (const name of RAW_MATERIAL_EXPENSE_CATEGORY_NAMES_TO_REMOVE) {
    const existing = await db.getFirstAsync<{ id: string }>(
      'SELECT id FROM expense_categories WHERE LOWER(name) = LOWER(?)',
      [name]
    );
    if (!existing) continue;
    await db.runAsync('UPDATE expenses SET category_id = NULL WHERE category_id = ?', [existing.id]);
    await db.runAsync('DELETE FROM expense_categories WHERE id = ?', [existing.id]);
  }
}

// Semé uniquement sur une toute nouvelle installation (aucun ingrédient existant) : un
// fournisseur, un ingrédient et une recette clairement marqués "(exemple)", pour qu'un nouvel
// utilisateur voie tout de suite comment l'appli s'articule plutôt que de démarrer sur des
// écrans vides — facile à repérer et à supprimer, et distinct des vraies données de personne
// (contrairement à l'ancienne liste de fournisseurs par défaut, qui reprenait les fournisseurs
// personnels de l'utilisatrice d'origine).
// Devise d'une installation neuve : celle de la région du téléphone (€, $, £…), « DH » au Maroc
// (le symbole officiel « MAD »/« د.م. » est moins parlant au quotidien).
function deviceCurrencySymbol(): string {
  const l = Localization.getLocales()[0];
  if (!l || l.regionCode === 'MA' || l.currencyCode === 'MAD') return 'DH';
  return l.currencySymbol || l.currencyCode || 'DH';
}

async function seedExampleDataForFreshInstall(db: SQLiteDatabase, isFreshInstall: boolean): Promise<void> {
  // Seulement à la toute première installation — sinon les exemples réapparaîtraient chez
  // quelqu'un qui a supprimé tous ses ingrédients.
  if (!isFreshInstall) return;
  const existingIngredients = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) as count FROM ingredients');
  if (existingIngredients && existingIngredients.count > 0) return;

  const now = new Date().toISOString();

  const supplierId = newId();
  await db.runAsync('INSERT INTO suppliers (id, name, created_at) VALUES (?, ?, ?)', [
    supplierId,
    tr('Mon fournisseur (exemple)'),
    now,
  ]);

  const ingredientId = newId();
  const purchasePrice = 90;
  const purchaseQuantity = 10;
  const purchaseUnit: PurchaseUnit = 'kg';
  const baseUnit = baseUnitForPurchaseUnit(purchaseUnit);
  const unitPrice = computeUnitPrice(purchasePrice, purchaseQuantity, purchaseUnit);
  await db.runAsync(
    `INSERT INTO ingredients (id, name, purchase_price, purchase_quantity, purchase_unit, base_unit, unit_price, vat_rate, category_id, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0, NULL, ?, ?)`,
    [ingredientId, tr('Farine (exemple)'), purchasePrice, purchaseQuantity, purchaseUnit, baseUnit, unitPrice, now, now]
  );
  // Pas d'achat d'exemple : il compterait comme une vraie dépense dans la Caisse d'un nouvel utilisateur.

  const mixAction = await db.getFirstAsync<{ id: string; name: string }>(
    'SELECT id, name FROM process_actions WHERE name = ?',
    [tr('Mélanger')]
  );

  const categoryId = newId();
  await db.runAsync('INSERT INTO categories (id, name, sort_order, created_at, updated_at) VALUES (?, ?, 0, ?, ?)', [
    categoryId,
    tr('Mes recettes (exemple)'),
    now,
    now,
  ]);

  const recipeId = newId();
  await db.runAsync(
    `INSERT INTO recipes (id, category_id, name, photo_uri, labor_hours, hourly_rate, margin_percent, servings, billed_price, sort_order, created_at, updated_at)
     VALUES (?, ?, ?, NULL, 0.25, 17.92, 30, 1, NULL, 0, ?, ?)`,
    [recipeId, categoryId, tr('Recette (exemple)'), now, now]
  );

  const groupId = newId();
  await db.runAsync(
    'INSERT INTO recipe_groups (id, recipe_id, name, instruction, sort_order, created_at, updated_at) VALUES (?, ?, ?, NULL, 0, ?, ?)',
    [groupId, recipeId, mixAction?.name ?? tr('Étape 1'), now, now]
  );
  if (mixAction) {
    await db.runAsync('INSERT INTO recipe_group_process_tags (group_id, process_action_id) VALUES (?, ?)', [
      groupId,
      mixAction.id,
    ]);
  }
  await db.runAsync(
    'INSERT INTO recipe_group_items (id, group_id, ingredient_id, component_recipe_id, quantity, unit, note, sort_order) VALUES (?, ?, ?, NULL, ?, ?, NULL, 0)',
    [newId(), groupId, ingredientId, 200, baseUnit]
  );
}

// Dans les recettes, tout se saisit au poids. Une seule fois :
// 1. Les œufs achetés à la pièce sans poids connu reçoivent 1 œuf = 50 g (leur prix passe au
//    gramme). Leurs lignes de recette enregistrées « en pièces » : jusqu'à 12, ce sont des œufs
//    entiers (× 50 g) ; au-delà, c'étaient des grammes tapés alors que l'app affichait « unité ».
// 2. Toute ligne encore « en pièces » d'un ingrédient dont on connaît le poids d'une pièce est
//    convertie en grammes (même coût, juste affichée au poids).
async function migrateRecipeQuantitiesToWeight(db: SQLiteDatabase): Promise<void> {
  const columns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('app_settings')");
  if (columns.length === 0 || columns.some((c) => c.name === 'recipe_quantities_by_weight')) return;
  await db.execAsync('ALTER TABLE app_settings ADD COLUMN recipe_quantities_by_weight INTEGER;');

  const pieceIngredients = await db.getAllAsync<{
    id: string;
    name: string;
    purchase_quantity: number;
    purchase_unit: PurchaseUnit;
    unit_price: number;
  }>("SELECT id, name, purchase_quantity, purchase_unit, unit_price FROM ingredients WHERE purchase_unit = 'unite' AND avg_piece_weight_g IS NULL");
  for (const ing of pieceIngredients) {
    if (!looksLikeEgg(ing.name)) continue;
    const totalHt = ing.unit_price * toBaseQuantity(ing.purchase_quantity, ing.purchase_unit, null);
    const grams = toBaseQuantity(ing.purchase_quantity, ing.purchase_unit, EGG_WEIGHT_G);
    await db.runAsync(
      "UPDATE ingredients SET avg_piece_weight_g = ?, base_unit = 'g', unit_price = ?, updated_at = ? WHERE id = ?",
      [EGG_WEIGHT_G, grams > 0 ? totalHt / grams : 0, new Date().toISOString(), ing.id]
    );
    await db.runAsync(
      "UPDATE recipe_group_items SET unit = 'g', quantity = CASE WHEN quantity <= 12 THEN quantity * ? ELSE quantity END WHERE ingredient_id = ? AND unit = 'unite'",
      [EGG_WEIGHT_G, ing.id]
    );
  }

  await db.execAsync(`
    UPDATE recipe_group_items
    SET quantity = quantity * (SELECT avg_piece_weight_g FROM ingredients i WHERE i.id = recipe_group_items.ingredient_id),
        unit = 'g'
    WHERE unit = 'unite' AND ingredient_id IN (
      SELECT id FROM ingredients WHERE avg_piece_weight_g IS NOT NULL AND avg_piece_weight_g > 0
    );
  `);
}

// Poids d'une unité d'achat gardé sur CHAQUE achat (pièce, paquet, carton, litre) et archivage des
// ingrédients « supprimés » (leurs achats restent dans la Caisse). Les anciens achats à la pièce
// reprennent le poids d'une pièce de leur ingrédient, pour que leur prix au gramme ne change pas.
async function migrateUnitWeightsAndArchive(db: SQLiteDatabase): Promise<void> {
  const purchaseColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('ingredient_purchases')");
  if (purchaseColumns.length > 0 && !purchaseColumns.some((c) => c.name === 'unit_weight_g')) {
    await db.execAsync('ALTER TABLE ingredient_purchases ADD COLUMN unit_weight_g REAL;');
    await db.execAsync(`
      UPDATE ingredient_purchases
      SET unit_weight_g = (SELECT i.avg_piece_weight_g FROM ingredients i WHERE i.id = ingredient_purchases.ingredient_id)
      WHERE unit = 'unite'
        AND (SELECT i.avg_piece_weight_g FROM ingredients i WHERE i.id = ingredient_purchases.ingredient_id) IS NOT NULL;
    `);
  }
  const ingredientColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info('ingredients')");
  if (ingredientColumns.length > 0 && !ingredientColumns.some((c) => c.name === 'archived')) {
    await db.execAsync('ALTER TABLE ingredients ADD COLUMN archived INTEGER NOT NULL DEFAULT 0;');
  }
}

export async function migrateDbIfNeeded(db: SQLiteDatabase): Promise<void> {
  // Installation neuve = aucune table encore créée. Sert à proposer des catégories génériques
  // (dans la langue du téléphone) plutôt que celles de l'utilisatrice d'origine.
  const settingsTable = await db.getFirstAsync(
    "SELECT name FROM sqlite_master WHERE type='table' AND name='app_settings'"
  );
  const isFreshInstall = !settingsTable;

  await migrateRecipeGroupItemsForComponents(db);
  await db.execAsync(CREATE_TABLES_SQL);
  await finishRecipeGroupItemsMigration(db);
  await migrateAppSettingsGeminiKey(db);
  await migrateIngredientCategoryId(db);
  await migrateVatSupport(db);
  await migrateResetDefaultVatRateToZero(db);
  await migrateRepairZeroPriceHtFromRestore(db);
  await migrateAppSettingsAccentTheme(db);
  await migrateAppSettingsOnboarding(db);
  await migrateAppSettingsAutoBackup(db);
  await migrateAppSettingsLocale(db);
  await migrateIngredientsAvgPieceWeight(db);
  await migrateExpenseCategoriesFromDailyExpensesApp(db);
  await migrateRecipeQuantitiesToWeight(db);
  await migrateUnitWeightsAndArchive(db);

  const existingActions = await db.getFirstAsync<{ count: number }>(
    'SELECT COUNT(*) as count FROM process_actions'
  );
  if (!existingActions || existingActions.count === 0) {
    const now = new Date().toISOString();
    for (let i = 0; i < DEFAULT_PROCESS_ACTIONS.length; i++) {
      await db.runAsync(
        'INSERT INTO process_actions (id, name, color, is_custom, created_at) VALUES (?, ?, ?, 0, ?)',
        [newId(), isFreshInstall ? tr(DEFAULT_PROCESS_ACTIONS[i]) : DEFAULT_PROCESS_ACTIONS[i], colorForIndex(i), now]
      );
    }
  }

  await seedExampleDataForFreshInstall(db, isFreshInstall);

  const existingExpenseCategories = await db.getFirstAsync<{ count: number }>(
    'SELECT COUNT(*) as count FROM expense_categories'
  );
  // Seulement à la toute première installation : sinon une liste vidée volontairement se remplirait
  // de nouveau à chaque démarrage.
  if (isFreshInstall && (!existingExpenseCategories || existingExpenseCategories.count === 0)) {
    const now = new Date().toISOString();
    const names = STARTER_EXPENSE_CATEGORIES.map(tr);
    for (const name of names) {
      await db.runAsync('INSERT INTO expense_categories (id, name, created_at) VALUES (?, ?, ?)', [
        newId(),
        name,
        now,
      ]);
    }
  }

  const existingSaleCategories = await db.getFirstAsync<{ count: number }>(
    'SELECT COUNT(*) as count FROM sale_categories'
  );
  if (isFreshInstall && (!existingSaleCategories || existingSaleCategories.count === 0)) {
    const now = new Date().toISOString();
    const names = STARTER_SALE_CATEGORIES.map(tr);
    for (const name of names) {
      await db.runAsync('INSERT INTO sale_categories (id, name, created_at) VALUES (?, ?, ?)', [newId(), name, now]);
    }
  }

  if (!isFreshInstall) {
    // Données propres à l'utilisatrice d'origine : jamais chez un nouvel utilisateur.
    await migrateHistoricalDataAugust2026(db);
    await migrateRemoveRawMaterialExpenseCategories(db);
  }

  const settings = await db.getFirstAsync('SELECT id FROM app_settings WHERE id = 1');
  if (!settings) {
    await db.runAsync(
      'INSERT INTO app_settings (id, default_hourly_rate, currency_symbol, updated_at) VALUES (1, 17.92, ?, ?)',
      [isFreshInstall ? deviceCurrencySymbol() : 'DH', new Date().toISOString()]
    );
  }
}
