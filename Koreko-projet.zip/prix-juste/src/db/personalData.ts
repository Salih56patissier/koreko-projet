// DONNÉES PERSONNELLES de l'utilisatrice d'origine (ses catégories de dépenses, son historique
// d'août 2026 importé une seule fois). Ce fichier n'est PAS inclus dans la version publique de
// l'application : voir database.ts (édition « personal » / « public ») et build-public.ps1.
// Rien de ce qui est ici ne doit apparaître chez un nouvel utilisateur.

// Catégories reprises telles quelles de l'application "Dépenses quotidiennes" de l'utilisateur,
// pour que ses dépenses boutique aient les mêmes intitulés des deux côtés, plus quelques
// catégories génériques qui n'ont pas d'équivalent direct dans cette liste.
// Les matières premières (ingrédients de recette : Beurre, Farine, Café...) n'y sont plus —
// elles se choisissent désormais via le chemin "Matière première" qui pointe vers un ingrédient
// précis (voir RAW_MATERIAL_CATEGORY_NAMES_TO_REMOVE ci-dessous pour la liste retirée).
export const DEFAULT_EXPENSE_CATEGORIES = [
  'Achats /ventes',
  'Autres charges',
  'Bureautique',
  'Cnss',
  'Coffre',
  'Comptable',
  'Emballage',
  'Eyoo',
  'Gardien',
  'Gasoil',
  'Gaz',
  'Gobelet',
  'Instagram / pub / marketing',
  'Loyer',
  'Matériel / réparation',
  'Papier cuisson',
  'Produit menager',
  'Redal',
  'Remboursements',
  'Régulation',
  'Salaires',
  'Souk',
  'Taxe',
  'Téléphone /internet',
  'Électricité/Eau',
  'Transport',
  'Autre',
];

// Catégories "matière première" retirées de la liste ci-dessus — désormais un achat de ces
// produits se fait via le chemin "Matière première" (choix d'un ingrédient précis), pas via
// une catégorie de dépense générique. Utilisé par une migration ponctuelle pour nettoyer les
// installations qui avaient déjà ces catégories (voir migrateRemoveRawMaterialExpenseCategories
// dans database.ts) — les dépenses déjà enregistrées avec ces catégories gardent leur montant et
// leur date, elles perdent juste l'étiquette de catégorie (comme pour toute suppression de
// catégorie dans l'app).
export const RAW_MATERIAL_EXPENSE_CATEGORY_NAMES_TO_REMOVE = [
  'Arôme',
  'Autres MP',
  'Beurre',
  'Café',
  'Chocolat / pâtes à glacer',
  'Crème /lait',
  'Décor',
  'Farine',
  'Feuilletine',
  'Fruit /purée',
  'Fruits secs',
  'Huile',
  'Kounafa',
  'Levure',
  'Margarine',
  'Nature',
  'Oeufs',
  'Poudre a crème',
  'Salé /fromage /mozzq',
  'Sucre/ glucose',
];


export const DEFAULT_SALE_CATEGORIES = ['Magasin', 'Revendeurs', 'Coffre'];

// Historique du "Rapport mensuel" (dépenses et recettes) que l'utilisateur a
// exporté depuis "Dépenses quotidiennes" pour août 2026, importé une seule
// fois au premier lancement après cette mise à jour (voir
// migrateHistoricalDataAugust2026 dans database.ts). Les noms doivent
// correspondre exactement à ceux de DEFAULT_EXPENSE_CATEGORIES /
// DEFAULT_SALE_CATEGORIES ci-dessus pour que le rattachement fonctionne.
export const AUGUST_2026_EXPENSES: { category: string; amount: number; count: number }[] = [
  { category: 'Salaires', amount: 26972, count: 13 },
  { category: 'Beurre', amount: 11950, count: 6 },
  { category: 'Redal', amount: 8916, count: 2 },
  { category: 'Loyer', amount: 8800, count: 3 },
  { category: 'Instagram / pub / marketing', amount: 8193, count: 7 },
  { category: 'Achats /ventes', amount: 6550, count: 8 },
  { category: 'Chocolat / pâtes à glacer', amount: 6122, count: 17 },
  { category: 'Remboursements', amount: 5000, count: 1 },
  { category: 'Emballage', amount: 4575, count: 26 },
  { category: 'Nature', amount: 4539, count: 39 },
  { category: 'Matériel / réparation', amount: 4243, count: 6 },
  { category: 'Fruits secs', amount: 3876, count: 10 },
  { category: 'Crème /lait', amount: 2766, count: 8 },
  { category: 'Cnss', amount: 2649, count: 1 },
  { category: 'Oeufs', amount: 2647, count: 6 },
  { category: 'Fruit /purée', amount: 2509, count: 22 },
  { category: 'Margarine', amount: 1737, count: 7 },
  { category: 'Farine', amount: 1500, count: 1 },
  { category: 'Autres MP', amount: 1387, count: 10 },
  { category: 'Coffre', amount: 1300, count: 2 },
  { category: 'Gaz', amount: 1032, count: 4 },
  { category: 'Sucre/ glucose', amount: 907, count: 4 },
  { category: 'Téléphone /internet', amount: 661, count: 2 },
  { category: 'Poudre a crème', amount: 457.5, count: 4 },
  { category: 'Feuilletine', amount: 280, count: 1 },
  { category: 'Gobelet', amount: 250, count: 2 },
  { category: 'Salé /fromage /mozzq', amount: 222.5, count: 3 },
  { category: 'Produit menager', amount: 170, count: 3 },
  { category: 'Huile', amount: 162, count: 2 },
  { category: 'Arôme', amount: 155, count: 2 },
  { category: 'Autres charges', amount: 130, count: 2 },
  { category: 'Levure', amount: 128, count: 3 },
  { category: 'Kounafa', amount: 100, count: 2 },
  { category: 'Gardien', amount: 100, count: 1 },
  { category: 'Gasoil', amount: 50, count: 1 },
  { category: 'Café', amount: 27, count: 1 },
  { category: 'Décor', amount: 20, count: 1 },
  { category: 'Bureautique', amount: 20, count: 1 },
  { category: 'Souk', amount: 12, count: 1 },
];

export const AUGUST_2026_SALES: { category: string; amount: number; count: number }[] = [
  { category: 'Magasin', amount: 121700, count: 9 },
  { category: 'Revendeurs', amount: 4574, count: 6 },
  { category: 'Coffre', amount: 4500, count: 1 },
];

