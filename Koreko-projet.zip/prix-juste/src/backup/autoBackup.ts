import { StorageAccessFramework } from 'expo-file-system/legacy';
import { type SQLiteDatabase } from 'expo-sqlite';
import { buildBackupData } from './backupRepo';
import { addPhotosToBackup } from './backupPhotos';
import { getSettings, updateAutoBackupFolder, updateLastAutoBackupAt } from '../db/repositories/settingsRepo';
import { todayIso } from '../utils/date';

// Keep a rolling window of daily auto-backups so a single bad/incomplete
// write never leaves the user with no usable safety net.
const KEEP_DAYS = 7;
const FILE_NAME_RE = /^prixjuste-auto-(\d{4}-\d{2}-\d{2})\.json$/;

function todayFileBaseName(): string {
  return `prixjuste-auto-${todayIso()}`;
}

function nameFromSafUri(uri: string): string {
  const decoded = decodeURIComponent(uri);
  const idx = decoded.lastIndexOf('/');
  return idx >= 0 ? decoded.slice(idx + 1) : decoded;
}

export type AutoBackupRequestResult = { granted: true; folderUri: string } | { granted: false };

// Asks the user, once, to pick a folder outside the app's own storage
// (e.g. "Téléchargements"). That folder survives an uninstall, unlike the
// app-internal SQLite database, so it's what actually protects the data.
export async function requestAutoBackupFolder(db: SQLiteDatabase): Promise<AutoBackupRequestResult> {
  const result = await StorageAccessFramework.requestDirectoryPermissionsAsync();
  if (!result.granted) return { granted: false };
  await updateAutoBackupFolder(db, result.directoryUri);
  return { granted: true, folderUri: result.directoryUri };
}

export async function disableAutoBackup(db: SQLiteDatabase): Promise<void> {
  await updateAutoBackupFolder(db, null);
}

export type AutoBackupRunResult = 'ok' | 'not-configured' | 'error' | 'skipped-empty';

let isRunning = false;

// Writes a fresh snapshot of the whole database into the chosen folder,
// overwriting today's file if one already exists, and prunes anything
// older than KEEP_DAYS. Safe to call often (app open, app backgrounded) —
// it no-ops quickly if no folder has been configured yet.
export async function runAutoBackup(db: SQLiteDatabase): Promise<AutoBackupRunResult> {
  if (isRunning) return 'ok';
  isRunning = true;
  try {
    const settings = await getSettings(db);
    const folderUri = settings.autoBackupFolderUri;
    if (!folderUri) return 'not-configured';

    let existingUris: string[];
    try {
      existingUris = await StorageAccessFramework.readDirectoryAsync(folderUri);
    } catch {
      // Permission was likely revoked (storage cleared, folder deleted…).
      // Clear it so the Settings screen can prompt the user to reconnect.
      await updateAutoBackupFolder(db, null);
      return 'error';
    }

    const dated = existingUris
      .map((uri) => ({ uri, match: FILE_NAME_RE.exec(nameFromSafUri(uri)) }))
      .filter((x): x is { uri: string; match: RegExpExecArray } => x.match !== null)
      .map((x) => ({ uri: x.uri, date: x.match[1] }))
      .sort((a, b) => (a.date < b.date ? 1 : -1)); // newest first

    const built = await buildBackupData(db);
    // Base (presque) vide — téléphone neuf, réinstallation — alors qu'une sauvegarde existe déjà :
    // on n'écrase RIEN, sinon la bonne copie du jour serait remplacée par du vide.
    const meaningfulRows =
      built.tables.recipes.length +
      built.tables.expenses.length +
      built.tables.sales.length +
      built.tables.ingredient_purchases.length;
    if (meaningfulRows === 0 && dated.length > 0) {
      return 'skipped-empty';
    }
    const data = await addPhotosToBackup(built);
    const json = JSON.stringify(data);

    const todayName = todayFileBaseName();
    const todayEntry = dated.find((d) => d.date === todayIso());
    // On supprime le fichier du jour avant de le réécrire : écrire par-dessus ne le raccourcit pas
    // toujours, et une sauvegarde plus courte que la précédente donnerait un JSON illisible.
    if (todayEntry) {
      try {
        await StorageAccessFramework.deleteAsync(todayEntry.uri);
      } catch {
        // Si la suppression échoue, on réécrit quand même par-dessus.
      }
    }
    const newUri = await StorageAccessFramework.createFileAsync(folderUri, todayName, 'application/json');
    await StorageAccessFramework.writeAsStringAsync(newUri, json);

    const toDelete = dated.filter((d) => d.date !== todayIso()).slice(KEEP_DAYS - 1);
    for (const entry of toDelete) {
      try {
        await StorageAccessFramework.deleteAsync(entry.uri);
      } catch {
        // Not critical — an extra old backup file is harmless.
      }
    }

    await updateLastAutoBackupAt(db, new Date().toISOString());
    return 'ok';
  } catch {
    return 'error';
  } finally {
    isRunning = false;
  }
}
