import { File } from 'expo-file-system';
import { type SQLiteDatabase } from 'expo-sqlite';
import { BackupData } from './backupRepo';
import { getPhotosDirectory, photoFileExists } from '../utils/photo';
import { newId } from '../utils/uuid';

// Les photos de recettes sont des fichiers à part, hors de la base : sans ce module, une
// sauvegarde ne garderait que leur adresse sur le téléphone, inutilisable après une
// réinstallation ou sur un autre téléphone. Elles sont donc ajoutées au fichier de sauvegarde
// (en base64), indexées par leur ancienne adresse.

export async function addPhotosToBackup(data: BackupData): Promise<BackupData> {
  const photos: Record<string, string> = {};
  for (const recipe of data.tables.recipes ?? []) {
    const uri = recipe.photo_uri as string | null;
    if (!photoFileExists(uri) || photos[uri]) continue;
    try {
      photos[uri] = await new File(uri).base64();
    } catch {
      // Photo illisible : la recette est sauvegardée sans elle.
    }
  }
  return { ...data, photos };
}

// À appeler après restoreBackupData : recrée chaque photo sur ce téléphone et met à jour
// l'adresse enregistrée dans la recette. Une photo absente du fichier et introuvable ici est
// retirée de la recette (sinon un cadre vide s'afficherait).
export async function restorePhotosFromBackup(db: SQLiteDatabase, data: BackupData): Promise<void> {
  const photos = data.photos ?? {};
  const recipes = await db.getAllAsync<{ id: string; photo_uri: string }>(
    'SELECT id, photo_uri FROM recipes WHERE photo_uri IS NOT NULL'
  );
  const restored = new Map<string, string>();
  for (const recipe of recipes) {
    const oldUri = recipe.photo_uri;
    if (photoFileExists(oldUri)) continue; // même téléphone : la photo est déjà là
    let newUri: string | null = restored.get(oldUri) ?? null;
    if (!newUri && photos[oldUri]) {
      try {
        const file = new File(getPhotosDirectory(), `${newId()}.jpg`);
        file.create();
        file.write(photos[oldUri], { encoding: 'base64' });
        newUri = file.uri;
        restored.set(oldUri, newUri);
      } catch {
        newUri = null;
      }
    }
    await db.runAsync('UPDATE recipes SET photo_uri = ? WHERE id = ?', [newUri, recipe.id]);
  }
}
