import { type SQLiteDatabase } from 'expo-sqlite';
import { priceExcludingVat } from '../utils/priceCalc';

export const BACKUP_VERSION = 1;

const TABLES_IN_DELETE_ORDER = [
  'shopping_list_items',
  'recipe_group_process_tags',
  'recipe_group_items',
  'recipe_extra_costs',
  'recipe_groups',
  'recipes',
  'ingredient_purchases',
  'expenses',
  'sales',
  'ingredients',
  'ingredient_categories',
  'categories',
  'suppliers',
  'expense_categories',
  'sale_categories',
  'process_actions',
  'app_settings',
] as const;

const TABLES_IN_INSERT_ORDER = [
  'categories',
  'ingredient_categories',
  'ingredients',
  'suppliers',
  'ingredient_purchases',
  'expense_categories',
  'expenses',
  'sale_categories',
  'sales',
  'process_actions',
  'recipes',
  'recipe_groups',
  'recipe_group_items',
  'recipe_extra_costs',
  'recipe_group_process_tags',
  'shopping_list_items',
  'app_settings',
] as const;

// Absentes des sauvegardes faites avant leur ajout : on garde alors ce qu'il y a sur le
// téléphone plutôt que de l'effacer (la liste de courses n'était pas sauvegardée au début).
const OPTIONAL_TABLES: readonly string[] = ['shopping_list_items'];

type TableName = (typeof TABLES_IN_INSERT_ORDER)[number];

// Colonnes de app_settings qui n'ont de sens que sur CE téléphone (dossier de sauvegarde auto, date
// de dernière sauvegarde) ou qui sont secrètes (clé API) : ni exportées, ni écrasées à la restauration.
const DEVICE_ONLY_SETTINGS = ['auto_backup_folder_uri', 'last_auto_backup_at', 'gemini_api_key'] as const;

export interface BackupData {
  version: number;
  exportedAt: string;
  tables: Record<TableName, Record<string, unknown>[]>;
  // Photos des recettes en base64, indexées par l'adresse enregistrée dans recipes.photo_uri
  // (voir backupPhotos.ts). Absent des sauvegardes faites avant leur ajout.
  photos?: Record<string, string>;
}

export async function buildBackupData(db: SQLiteDatabase): Promise<BackupData> {
  const tables = {} as Record<TableName, Record<string, unknown>[]>;
  for (const table of TABLES_IN_INSERT_ORDER) {
    tables[table] = await db.getAllAsync<Record<string, unknown>>(`SELECT * FROM ${table}`);
  }
  // Réglages propres au téléphone ou secrets : jamais dans un fichier de sauvegarde (qui se partage).
  for (const row of tables.app_settings) {
    for (const column of DEVICE_ONLY_SETTINGS) delete row[column];
  }
  return { version: BACKUP_VERSION, exportedAt: new Date().toISOString(), tables };
}

export class BackupRestoreError extends Error {}

export async function restoreBackupData(db: SQLiteDatabase, data: BackupData): Promise<void> {
  if (data.version !== BACKUP_VERSION || !data.tables) {
    throw new BackupRestoreError("Ce fichier n'est pas une sauvegarde Koreko valide.");
  }

  // Réglages du téléphone à conserver tels quels après la restauration.
  const keptSettings = await db.getFirstAsync<Record<string, unknown>>(
    `SELECT ${DEVICE_ONLY_SETTINGS.join(', ')} FROM app_settings WHERE id = 1`
  );

  await db.execAsync('PRAGMA foreign_keys = OFF;');
  try {
    await db.execAsync('BEGIN;');
    for (const table of TABLES_IN_DELETE_ORDER) {
      if (OPTIONAL_TABLES.includes(table) && !data.tables[table]) continue;
      await db.execAsync(`DELETE FROM ${table};`);
    }
    for (const table of TABLES_IN_INSERT_ORDER) {
      const rows = data.tables[table] ?? [];
      // Une sauvegarde faite avec une autre version de l'app peut contenir des colonnes qui
      // n'existent pas ici : on les ignore au lieu de faire échouer toute la restauration.
      const existingColumns = new Set(
        (await db.getAllAsync<{ name: string }>(`PRAGMA table_info('${table}')`)).map((c) => c.name)
      );
      for (const rawRow of rows) {
        // Une sauvegarde plus ancienne que le schéma actuel n'a exporté que les colonnes qui
        // existaient à ce moment-là — sans ce rattrapage, price_ht (absent des vieilles
        // sauvegardes) retomberait sur son défaut SQL (0 DH) au lieu du vrai prix.
        const row: Record<string, unknown> =
          table === 'ingredient_purchases' && !('price_ht' in rawRow)
            ? {
                ...rawRow,
                vat_rate: (rawRow.vat_rate as number) ?? 0,
                price_ht: priceExcludingVat(rawRow.price as number, (rawRow.vat_rate as number) ?? 0),
              }
            : rawRow;
        const columns = Object.keys(row).filter((c) => existingColumns.has(c));
        if (columns.length === 0) continue;
        const placeholders = columns.map(() => '?').join(',');
        await db.runAsync(
          `INSERT INTO ${table} (${columns.join(',')}) VALUES (${placeholders})`,
          columns.map((c) => row[c] as never)
        );
      }
    }
    if (keptSettings) {
      for (const column of DEVICE_ONLY_SETTINGS) {
        await db.runAsync(`UPDATE app_settings SET ${column} = ? WHERE id = 1`, [(keptSettings[column] ?? null) as never]);
      }
    }
    // Articles de liste de courses gardés (vieille sauvegarde) dont l'ingrédient n'existe plus.
    await db.execAsync('DELETE FROM shopping_list_items WHERE ingredient_id NOT IN (SELECT id FROM ingredients);');
    await db.execAsync(
      'UPDATE shopping_list_items SET supplier_id = NULL WHERE supplier_id IS NOT NULL AND supplier_id NOT IN (SELECT id FROM suppliers);'
    );
    await db.execAsync('COMMIT;');
  } catch (e) {
    await db.execAsync('ROLLBACK;');
    throw e;
  } finally {
    await db.execAsync('PRAGMA foreign_keys = ON;');
  }
}
