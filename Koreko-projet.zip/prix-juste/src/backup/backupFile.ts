import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { type SQLiteDatabase } from 'expo-sqlite';
import { buildBackupData } from './backupRepo';
import { addPhotosToBackup } from './backupPhotos';
import { todayIso } from '../utils/date';

function backupFileName(): string {
  const date = todayIso();
  return `prix-juste-sauvegarde-${date}.json`;
}

export async function exportBackupAndShare(db: SQLiteDatabase): Promise<void> {
  const data = await addPhotosToBackup(await buildBackupData(db));
  const json = JSON.stringify(data, null, 2);
  const file = new File(Paths.cache, backupFileName());
  if (file.exists) file.delete();
  file.create();
  file.write(json);
  await Sharing.shareAsync(file.uri, { mimeType: 'application/json', UTI: 'public.json' });
}

// Uses expo-file-system's built-in file picker so we don't need an extra
// document-picker dependency (and its own native-module version to track).
// No MIME filter: a file downloaded via chat/browser is often mislabeled
// (e.g. application/octet-stream instead of application/json), which makes
// Android's document picker hide it entirely when filtered strictly — so we
// accept any file and let JSON.parse + our own shape check reject bad ones.
export async function pickBackupFileContent(): Promise<string | null> {
  let result;
  try {
    result = await File.pickFileAsync(undefined, '*/*');
  } catch {
    return null; // choix annulé : ce n'est pas une erreur
  }
  const file = Array.isArray(result) ? result[0] : result;
  if (!file) return null;
  return file.text();
}

// Copie de sécurité de ce qu'il y a sur le téléphone, faite JUSTE AVANT une restauration (qui
// remplace tout) : le fichier « avant-restauration.json » reste dans le stockage de l'app.
export async function saveSafetyCopyBeforeRestore(db: SQLiteDatabase): Promise<void> {
  const data = await addPhotosToBackup(await buildBackupData(db));
  const file = new File(Paths.document, 'avant-restauration.json');
  if (file.exists) file.delete();
  file.create();
  file.write(JSON.stringify(data));
}
