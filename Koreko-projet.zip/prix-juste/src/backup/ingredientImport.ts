import { File } from 'expo-file-system';

export interface IngredientImportCandidate {
  name: string;
  lastPrice: number;
  hint?: string;
  suggestedInclude: boolean;
}

export interface IngredientImportFile {
  type: 'prixjuste-ingredients-import';
  version: 1;
  items: IngredientImportCandidate[];
}

export class IngredientImportParseError extends Error {}

export function parseIngredientImportFile(content: string): IngredientImportFile {
  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch {
    throw new IngredientImportParseError("Ce fichier n'est pas un JSON valide.");
  }
  const file = data as Partial<IngredientImportFile>;
  if (file.type !== 'prixjuste-ingredients-import' || file.version !== 1 || !Array.isArray(file.items)) {
    throw new IngredientImportParseError("Ce fichier n'est pas un fichier d'import d'ingrédients Koreko valide.");
  }
  return file as IngredientImportFile;
}

// No MIME filter — see the comment on pickBackupFileContent in backupFile.ts.
export async function pickIngredientImportFile(): Promise<string | null> {
  const result = await File.pickFileAsync(undefined, '*/*');
  const file = Array.isArray(result) ? result[0] : result;
  if (!file) return null;
  return file.text();
}
