import { useEffect, useState } from 'react';
import { Keyboard, Platform } from 'react-native';

// Tracks the real, live keyboard height reported by the OS — used to make sure a form's
// scroll area always has enough room below its last field to scroll it above the keyboard,
// regardless of how Android's own window resize/pan behavior behaves (edge-to-edge makes that
// native behavior unreliable, see KeyboardAwareScrollView).
export function useKeyboardHeight(): number {
  const [height, setHeight] = useState(0);

  useEffect(() => {
    const showEvent = Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow';
    const hideEvent = Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide';
    const showSub = Keyboard.addListener(showEvent, (e) => setHeight(e.endCoordinates.height));
    const hideSub = Keyboard.addListener(hideEvent, () => setHeight(0));
    return () => {
      showSub.remove();
      hideSub.remove();
    };
  }, []);

  return height;
}
