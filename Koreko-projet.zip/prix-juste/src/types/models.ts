// Unités d'achat. 'unite' / 'paquet' / 'carton' sont des unités « à compter » : on indique le poids
// d'une unité (voir unitWeightG) pour que le prix soit ramené au gramme dans les recettes.
export type PurchaseUnit = 'kg' | 'g' | 'l' | 'unite' | 'paquet' | 'carton';
export type BaseUnit = 'g' | 'ml' | 'unite';

export interface Ingredient {
  id: string;
  name: string;
  purchasePrice: number;
  purchaseQuantity: number;
  purchaseUnit: PurchaseUnit;
  baseUnit: BaseUnit;
  unitPrice: number;
  vatRate: number;
  categoryId: string | null;
  // Poids d'une PIÈCE en grammes (ex: 50 pour un œuf), connu quand l'ingrédient s'achète à la
  // pièce. Sert à convertir « 2 œufs » ↔ « 100 g ». null = inconnu. (Le poids d'un paquet, d'un
  // carton ou d'un litre est, lui, enregistré sur chaque achat : IngredientPurchase.unitWeightG.)
  avgPieceWeightG: number | null;
  // Retiré des listes et des sélecteurs mais gardé : ses achats restent dans la Caisse.
  archived?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  createdAt: string;
}

export interface IngredientPurchase {
  id: string;
  ingredientId: string;
  supplierId: string;
  supplierName: string;
  purchaseDate: string;
  price: number; // prix réellement payé (TTC)
  vatRate: number; // taux de TVA appliqué à cet achat (figé, ne change pas rétroactivement)
  priceHt: number; // prix hors taxe calculé — utilisé dans le calcul du coût de revient
  quantity: number;
  unit: PurchaseUnit;
  // Poids en grammes d'UNE unité achetée (pièce, paquet, carton, ou litre si on le précise).
  unitWeightG: number | null;
  unitPrice: number; // prix HT ramené à l'unité de base (g/ml/unité)
  note: string | null;
  createdAt: string;
}

// One row per supplier that has ever sold this ingredient, showing their
// latest known unit price — the data behind the price-comparison table.
export interface SupplierPriceRow {
  supplierId: string;
  supplierName: string;
  unitPrice: number;
  purchaseDate: string;
  isCheapest: boolean;
}

// Summary used to flag, in the ingredients list, when a cheaper supplier
// than the one currently priced in is known.
export interface IngredientPriceInfo {
  cheapestSupplierName: string | null;
  cheapestUnitPrice: number | null;
  trend: 'up' | 'down' | 'stable' | null;
}

// Un ingrédient déjà acheté chez ce fournisseur par le passé, proposé comme suggestion quand tu
// ouvres son onglet dans la liste de courses — pour ne pas oublier ce que tu prends d'habitude
// là-bas. lastQuantity/lastUnit reprennent le dernier achat, comme quantité de départ suggérée.
export interface SupplierIngredientSuggestion {
  ingredientId: string;
  ingredientName: string;
  lastQuantity: number;
  lastUnit: PurchaseUnit;
}

export interface ShoppingListItem {
  id: string;
  ingredientId: string;
  ingredientName: string;
  supplierId: string | null;
  supplierName: string | null; // null = pas encore de fournisseur connu (aucun achat enregistré pour cet ingrédient)
  quantity: number;
  unit: PurchaseUnit;
  checked: boolean;
  createdAt: string;
  // Estimation HT (quantité × dernier prix connu chez ce fournisseur, ou à défaut le prix
  // courant de l'ingrédient) — null si aucun prix n'est encore connu pour l'estimer.
  estimatedPrice: number | null;
}

export interface IngredientCategory {
  id: string;
  name: string;
  color: string;
  createdAt: string;
}

export interface ExpenseCategory {
  id: string;
  name: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  categoryId: string | null;
  categoryName: string | null;
  expenseDate: string;
  amount: number;
  payee: string | null;
  note: string | null;
  createdAt: string;
}

export interface SaleCategory {
  id: string;
  name: string;
  createdAt: string;
}

export interface Sale {
  id: string;
  categoryId: string | null;
  categoryName: string | null;
  saleDate: string;
  amount: number;
  note: string | null;
  createdAt: string;
}

export interface CashSummary {
  totalSales: number;
  totalSpending: number; // expenses + ingredient purchases
  balance: number; // totalSales - totalSpending
}

export interface CategoryBreakdownRow {
  categoryId: string | null; // null = no category (or the ingredient-purchases row)
  categoryName: string | null; // null = expenses with no category assigned
  isIngredientPurchases: boolean;
  // Achats d'ingrédients : une ligne par ingrédient (categoryName = nom de l'ingrédient).
  ingredientId?: string | null;
  total: number;
  count: number;
  percent: number;
}

// A unified, read-only view of "money spent" combining general expenses and
// ingredient purchases — the single feed the user asked for, so they never
// have to log the same purchase twice or check two different screens.
export interface SpendingEntry {
  id: string;
  kind: 'expense' | 'ingredientPurchase';
  date: string;
  label: string | null;
  amount: number;
  categoryOrSupplier: string | null;
  ingredientId?: string; // present when kind === 'ingredientPurchase', to navigate there
  note?: string | null;
  quantity?: number; // ingredient purchases only
  unit?: string; // ingredient purchases only
  vatRate?: number; // ingredient purchases only, in % (0, 10, 20…)
}

export interface Category {
  id: string;
  name: string;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface CategoryWithCount extends Category {
  recipeCount: number;
}

export interface ProcessAction {
  id: string;
  name: string;
  color: string;
  isCustom: boolean;
  createdAt: string;
}

export interface Recipe {
  id: string;
  categoryId: string;
  name: string;
  photoUri: string | null;
  laborHours: number;
  hourlyRate: number;
  marginPercent: number;
  servings: number;
  billedPrice: number | null;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface RecipeGroup {
  id: string;
  recipeId: string;
  name: string;
  instruction: string | null;
  sortOrder: number;
  processTagIds: string[];
}

export interface RecipeGroupItem {
  id: string;
  groupId: string;
  ingredientId: string | null;
  componentRecipeId: string | null;
  quantity: number;
  unit: BaseUnit;
  note: string | null;
  sortOrder: number;
}

export interface RecipeExtraCost {
  id: string;
  recipeId: string;
  label: string;
  cost: number;
  sortOrder: number;
}

export interface AppSettings {
  defaultHourlyRate: number;
  currencySymbol: string;
  geminiApiKey: string | null;
  accentThemeId: string;
  autoBackupFolderUri: string | null;
  lastAutoBackupAt: string | null;
  locale: string | null;
  onboardingSeen: boolean;
}

// --- Composite shapes used by the recipe editor / cost engine ---

// A resolved line: either a base ingredient or another recipe used as a
// component (e.g. "500 g of crème pâtissière"). `unitPrice` is DH per
// gram/ml/unit either way, so `lineCost` is computed the same way for both.
export interface RecipeGroupItemWithIngredient extends RecipeGroupItem {
  name: string;
  unitPrice: number;
  // Poids d'une pièce de l'ingrédient (ex: 50 g pour un œuf), pour convertir pièces ↔ grammes.
  avgPieceWeightG?: number | null;
  isComponent: boolean;
  lineCost: number;
}

export interface ComponentCandidateRecipe {
  id: string;
  name: string;
  categoryName: string;
  unitPrice: number;
  totalWeight: number;
}

export interface RecipeGroupWithItems extends RecipeGroup {
  items: RecipeGroupItemWithIngredient[];
  groupCost: number;
}

export interface RecipeFull extends Recipe {
  groups: RecipeGroupWithItems[];
  extraCosts: RecipeExtraCost[];
}

export interface RecipeCostSummary {
  ingredientsCost: number;
  laborCost: number;
  extraCostsTotal: number;
  totalRealCost: number;
  fairPrice: number;
  pricePerServing: number;
  isSellingAtLoss: boolean;
  lossAmount: number | null;
  effectiveHourlyEarnings: number | null;
  realMarginAmount: number | null;
  realMarginPercent: number | null;
}

export interface RecipeSummary {
  id: string;
  name: string;
  photoUri: string | null;
  fairPrice: number;
}
