import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ShoppingListStackParamList } from './types';
import ShoppingListScreen from '../screens/shoppingList/ShoppingListScreen';
import { navigatorScreenOptions } from './screenOptions';

const Stack = createNativeStackNavigator<ShoppingListStackParamList>();

export default function ShoppingListStack() {
  return (
    <Stack.Navigator screenOptions={navigatorScreenOptions}>
      <Stack.Screen name="ShoppingList" component={ShoppingListScreen} options={{ headerShown: false }} />
    </Stack.Navigator>
  );
}
