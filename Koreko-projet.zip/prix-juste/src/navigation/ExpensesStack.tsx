import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ExpensesStackParamList } from './types';
import ExpensesListScreen from '../screens/expenses/ExpensesListScreen';
import ExpenseFormScreen from '../screens/expenses/ExpenseFormScreen';
import SaleFormScreen from '../screens/expenses/SaleFormScreen';
import MaterialPurchaseFormScreen from '../screens/expenses/MaterialPurchaseFormScreen';
import { navigatorScreenOptions } from './screenOptions';

const Stack = createNativeStackNavigator<ExpensesStackParamList>();

export default function ExpensesStack() {
  return (
    <Stack.Navigator screenOptions={navigatorScreenOptions}>
      <Stack.Screen name="ExpensesList" component={ExpensesListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="ExpenseForm" component={ExpenseFormScreen} options={{ headerShown: false }} />
      <Stack.Screen name="SaleForm" component={SaleFormScreen} options={{ headerShown: false }} />
      <Stack.Screen name="MaterialPurchaseForm" component={MaterialPurchaseFormScreen} options={{ headerShown: false }} />
    </Stack.Navigator>
  );
}
