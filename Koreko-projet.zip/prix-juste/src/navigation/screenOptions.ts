import { NativeStackNavigationOptions } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';

export const navigatorScreenOptions: NativeStackNavigationOptions = {
  headerStyle: { backgroundColor: colors.surface },
  headerTintColor: colors.text,
  headerTitleStyle: { fontWeight: '700' },
  contentStyle: { backgroundColor: colors.background },
};
