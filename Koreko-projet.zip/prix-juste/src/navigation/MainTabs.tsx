import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { RootTabParamList } from './types';
import IngredientsStack from './IngredientsStack';
import CategoriesStack from './CategoriesStack';
import ShoppingListStack from './ShoppingListStack';
import ExpensesStack from './ExpensesStack';
import { useI18n } from '../i18n/I18nContext';

const Tab = createBottomTabNavigator<RootTabParamList>();

// Les 2 couleurs de l'icône Koreko (livre de recette orange -> calculatrice bleu turquoise) :
// la barre d'onglets reste en permanence sur ce dégradé, icônes/texte en blanc — plus "fade"
// comme la barre blanche d'avant. Le thème d'accent choisi dans Réglages continue de
// s'appliquer à l'intérieur de chaque écran.
const KOREKO_ORANGE = '#e8792a';
const KOREKO_TEAL = '#17a3a8';

function TabBarGradient() {
  return (
    <LinearGradient
      colors={[KOREKO_ORANGE, '#c98a56', KOREKO_TEAL]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0.3 }}
      style={{ flex: 1 }}
    />
  );
}

export default function MainTabs() {
  const { t } = useI18n();
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#ffffff',
        tabBarInactiveTintColor: 'rgba(255,255,255,0.72)',
        tabBarBackground: () => <TabBarGradient />,
        tabBarStyle: { backgroundColor: 'transparent', borderTopWidth: 0, elevation: 0 },
      }}
    >
      <Tab.Screen
        name="IngredientsTab"
        component={IngredientsStack}
        options={{
          title: t('Ingrédients'),
          tabBarIcon: ({ color, size }) => <Ionicons name="basket-outline" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="CategoriesTab"
        component={CategoriesStack}
        options={{
          title: t('Mes recettes'),
          tabBarIcon: ({ color, size }) => <Ionicons name="book-outline" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="ShoppingListTab"
        component={ShoppingListStack}
        options={{
          title: t('Courses'),
          tabBarIcon: ({ color, size }) => <Ionicons name="cart-outline" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="ExpensesTab"
        component={ExpensesStack}
        options={{
          title: t('Caisse'),
          tabBarIcon: ({ color, size }) => <Ionicons name="wallet-outline" size={size} color={color} />,
        }}
      />
    </Tab.Navigator>
  );
}
