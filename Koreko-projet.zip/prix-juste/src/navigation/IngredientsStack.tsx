import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { IngredientsStackParamList } from './types';
import IngredientsListScreen from '../screens/ingredients/IngredientsListScreen';
import IngredientFormScreen from '../screens/ingredients/IngredientFormScreen';
import ImportIngredientsScreen from '../screens/ingredients/ImportIngredientsScreen';
import { navigatorScreenOptions } from './screenOptions';

const Stack = createNativeStackNavigator<IngredientsStackParamList>();

export default function IngredientsStack() {
  return (
    <Stack.Navigator screenOptions={navigatorScreenOptions}>
      <Stack.Screen name="IngredientsList" component={IngredientsListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="IngredientForm" component={IngredientFormScreen} options={{ headerShown: false }} />
      <Stack.Screen name="ImportIngredients" component={ImportIngredientsScreen} options={{ headerShown: false }} />
    </Stack.Navigator>
  );
}
