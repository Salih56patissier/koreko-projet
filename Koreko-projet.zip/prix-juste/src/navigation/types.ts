export type IngredientsStackParamList = {
  IngredientsList: undefined;
  // month = 'AAAA-MM' : ouvre l'historique d'achats sur ce mois (depuis la Caisse).
  IngredientForm: { ingredientId?: string; month?: string };
  ImportIngredients: undefined;
};

export type CategoriesStackParamList = {
  CategoriesList: undefined;
  CategoryDetail: { categoryId: string; categoryName: string };
  RecipeForm: { recipeId: string; categoryId: string; categoryName: string };
};

export type ExpensesStackParamList = {
  ExpensesList: undefined;
  ExpenseForm: { expenseId?: string };
  SaleForm: { saleId?: string };
  MaterialPurchaseForm: undefined;
};

export type ShoppingListStackParamList = {
  ShoppingList: undefined;
};

export type RootTabParamList = {
  IngredientsTab: undefined;
  CategoriesTab: undefined;
  ShoppingListTab: undefined;
  ExpensesTab: undefined;
};

// Wraps the tab bar so Settings can be pushed on top of it (as a normal
// screen reached from a header button) instead of living in the tab bar.
export type RootStackParamList = {
  MainTabs: undefined;
  Settings: undefined;
  Onboarding: undefined;
  Premium: undefined;
};
