import React from 'react';
import { Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
// Reached from the header of any tab's root screen — Settings is no longer
// a tab of its own. Two levels up: this screen's own Stack, then the Tab
// navigator, then the outer Stack that actually holds "Settings". White to
// stay legible against the gradient header background.
export default function SettingsHeaderButton() {
  const navigation = useNavigation();
  return (
    <Pressable
      onPress={() => navigation.getParent()?.getParent()?.navigate('Settings' as never)}
      hitSlop={10}
      style={{ marginRight: 4 }}
    >
      <Ionicons name="settings-outline" size={22} color="#ffffff" />
    </Pressable>
  );
}
