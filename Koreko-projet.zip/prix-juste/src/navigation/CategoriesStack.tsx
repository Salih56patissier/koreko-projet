import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CategoriesStackParamList } from './types';
import CategoriesListScreen from '../screens/categories/CategoriesListScreen';
import CategoryDetailScreen from '../screens/categories/CategoryDetailScreen';
import RecipeFormScreen from '../screens/categories/RecipeFormScreen';
import { navigatorScreenOptions } from './screenOptions';

const Stack = createNativeStackNavigator<CategoriesStackParamList>();

export default function CategoriesStack() {
  return (
    <Stack.Navigator screenOptions={navigatorScreenOptions}>
      <Stack.Screen name="CategoriesList" component={CategoriesListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="CategoryDetail" component={CategoryDetailScreen} options={{ headerShown: false }} />
      <Stack.Screen name="RecipeForm" component={RecipeFormScreen} options={{ headerShown: false }} />
    </Stack.Navigator>
  );
}
