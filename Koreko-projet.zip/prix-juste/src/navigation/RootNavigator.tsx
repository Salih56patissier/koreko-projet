import React, { useEffect, useState } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useSQLiteContext } from 'expo-sqlite';
import { RootStackParamList } from './types';
import MainTabs from './MainTabs';
import SettingsScreen from '../screens/settings/SettingsScreen';
import PremiumScreen from '../screens/premium/PremiumScreen';
import OnboardingScreen from '../screens/onboarding/OnboardingScreen';
import { navigatorScreenOptions } from './screenOptions';
import { getSettings, markOnboardingSeen } from '../db/repositories/settingsRepo';
import ScreenContainer from '../components/common/ScreenContainer';

const Stack = createNativeStackNavigator<RootStackParamList>();

// Settings lives here, one level above the tab bar, rather than as a tab of
// its own — it's reached via a gear icon in the other screens' headers.
export default function RootNavigator() {
  const db = useSQLiteContext();
  // null = encore en train de vérifier — évite un flash de l'appli avant le tuto sur un premier
  // lancement.
  const [onboardingSeen, setOnboardingSeen] = useState<boolean | null>(null);

  useEffect(() => {
    getSettings(db).then((s) => setOnboardingSeen(s.onboardingSeen));
  }, [db]);

  if (onboardingSeen === null) return <ScreenContainer />;

  if (!onboardingSeen) {
    return (
      <OnboardingScreen
        onDone={async () => {
          await markOnboardingSeen(db);
          setOnboardingSeen(true);
        }}
      />
    );
  }

  return (
    <Stack.Navigator screenOptions={navigatorScreenOptions}>
      <Stack.Screen name="MainTabs" component={MainTabs} options={{ headerShown: false }} />
      <Stack.Screen name="Settings" component={SettingsScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Onboarding" component={OnboardingScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Premium" component={PremiumScreen} options={{ headerShown: false }} />
    </Stack.Navigator>
  );
}
