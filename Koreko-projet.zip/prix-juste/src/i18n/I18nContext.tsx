import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { I18nManager } from 'react-native';
import * as Localization from 'expo-localization';
import { useSQLiteContext } from 'expo-sqlite';
import { getSettings, updateLocale } from '../db/repositories/settingsRepo';
import { en } from './locales/en';
import { ar } from './locales/ar';
import { ru } from './locales/ru';
import { de } from './locales/de';
import { it } from './locales/it';
import { es } from './locales/es';

// Every UI string is written directly in French in the source (e.g.
// t('Enregistrer')). French therefore needs no dictionary — it's the
// identity case. Other locales map that exact French string to its
// translation. This avoids inventing/maintaining hundreds of key names.
export const SUPPORTED_LOCALES = ['fr', 'en', 'ar', 'ru', 'de', 'it', 'es'] as const;
export type LocaleCode = (typeof SUPPORTED_LOCALES)[number];

export const LOCALE_LABELS: Record<LocaleCode, string> = {
  fr: 'Français',
  en: 'English',
  ar: 'العربية',
  ru: 'Русский',
  de: 'Deutsch',
  it: 'Italiano',
  es: 'Español',
};

export const RTL_LOCALES: LocaleCode[] = ['ar'];

const DICTIONARIES: Record<LocaleCode, Record<string, string>> = {
  fr: {},
  en,
  ar,
  ru,
  de,
  it,
  es,
};

type Vars = Record<string, string | number>;

interface I18nContextValue {
  locale: LocaleCode;
  // true when following the device's language rather than an explicit choice.
  isSystemLocale: boolean;
  setLocale: (locale: LocaleCode | null) => void;
  t: (key: string, vars?: Vars) => string;
  isRTL: boolean;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function detectDeviceLocale(): LocaleCode {
  const deviceLocales = Localization.getLocales();
  for (const l of deviceLocales) {
    const code = l.languageCode?.toLowerCase();
    if (code && (SUPPORTED_LOCALES as readonly string[]).includes(code)) {
      return code as LocaleCode;
    }
  }
  return 'fr';
}

// Traduit un texte dans la langue du téléphone, hors de l'interface (ex: noms des catégories
// créées automatiquement à la première installation, avant même que l'écran soit affiché).
export function translateForDevice(key: string): string {
  return DICTIONARIES[detectDeviceLocale()][key] ?? key;
}

function interpolate(template: string, vars?: Vars): string {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (match, key) => {
    const value = vars[key];
    return value === undefined ? match : String(value);
  });
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const db = useSQLiteContext();
  // null = "follow the device language"; a locale = explicit user choice.
  const [storedLocale, setStoredLocale] = useState<LocaleCode | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    getSettings(db).then((s) => {
      const stored = s.locale && (SUPPORTED_LOCALES as readonly string[]).includes(s.locale) ? (s.locale as LocaleCode) : null;
      setStoredLocale(stored);
      setLoaded(true);
    });
  }, [db]);

  const locale = storedLocale ?? detectDeviceLocale();
  const isRTL = RTL_LOCALES.includes(locale);

  useEffect(() => {
    if (!loaded) return;
    if (I18nManager.isRTL !== isRTL) {
      I18nManager.allowRTL(isRTL);
      I18nManager.forceRTL(isRTL);
      // Changing writing direction only fully applies after the app reloads;
      // callers that switch locale should tell the user to restart.
    }
  }, [loaded, isRTL]);

  const value = useMemo<I18nContextValue>(
    () => ({
      locale,
      isSystemLocale: storedLocale === null,
      isRTL,
      setLocale: (next) => {
        setStoredLocale(next);
        updateLocale(db, next);
      },
      t: (key, vars) => {
        const dict = DICTIONARIES[locale];
        const translated = dict[key] ?? key;
        return interpolate(translated, vars);
      },
    }),
    [locale, storedLocale, isRTL, db]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within an I18nProvider');
  return ctx;
}
