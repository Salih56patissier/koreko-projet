import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { useSQLiteContext } from 'expo-sqlite';
import { listDismissedHintIds, dismissHint, resetAllHints } from './hintsRepo';

interface HintsContextValue {
  isDismissed: (hintId: string) => boolean;
  dismiss: (hintId: string) => void;
  resetAll: () => Promise<void>;
}

const HintsContext = createContext<HintsContextValue>({
  isDismissed: () => true,
  dismiss: () => {},
  resetAll: async () => {},
});

export function HintsProvider({ children }: { children: React.ReactNode }) {
  const db = useSQLiteContext();
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    listDismissedHintIds(db).then(setDismissedIds);
  }, [db]);

  const isDismissed = useCallback((hintId: string) => dismissedIds.has(hintId), [dismissedIds]);

  const dismiss = useCallback(
    (hintId: string) => {
      setDismissedIds((prev) => new Set(prev).add(hintId));
      dismissHint(db, hintId);
    },
    [db]
  );

  const resetAll = useCallback(async () => {
    await resetAllHints(db);
    setDismissedIds(new Set());
  }, [db]);

  return <HintsContext.Provider value={{ isDismissed, dismiss, resetAll }}>{children}</HintsContext.Provider>;
}

export function useHints(): HintsContextValue {
  return useContext(HintsContext);
}
