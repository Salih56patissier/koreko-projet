import { type SQLiteDatabase } from 'expo-sqlite';

export async function listDismissedHintIds(db: SQLiteDatabase): Promise<Set<string>> {
  const rows = await db.getAllAsync<{ id: string }>('SELECT id FROM dismissed_hints');
  return new Set(rows.map((r) => r.id));
}

export async function dismissHint(db: SQLiteDatabase, hintId: string): Promise<void> {
  await db.runAsync('INSERT OR IGNORE INTO dismissed_hints (id) VALUES (?)', [hintId]);
}

// "Revoir les astuces" dans Réglages : fait réapparaître toutes les petites explications sur les
// écrans, sans toucher au tutoriel de bienvenue (qui a son propre marqueur, onboarding_seen).
export async function resetAllHints(db: SQLiteDatabase): Promise<void> {
  await db.runAsync('DELETE FROM dismissed_hints');
}
