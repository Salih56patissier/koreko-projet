import { type SQLiteDatabase } from 'expo-sqlite';

export const TRIAL_DAYS = 90;
const DAY_MS = 24 * 60 * 60 * 1000;

export interface AccessState {
  isPremium: boolean;
  trialDaysLeft: number;
  canEdit: boolean;
}

export function computeAccess(trialStartedAt: string, premium: boolean, now: Date = new Date()): AccessState {
  const started = new Date(trialStartedAt).getTime();
  const elapsedDays = Number.isFinite(started) ? Math.floor((now.getTime() - started) / DAY_MS) : 0;
  const trialDaysLeft = Math.max(0, TRIAL_DAYS - Math.max(0, elapsedDays));
  return { isPremium: premium, trialDaysLeft, canEdit: premium || trialDaysLeft > 0 };
}

// Table à part (hors sauvegarde) : restaurer une sauvegarde ne doit pas permettre de remettre
// l'essai à zéro ni de le prolonger.
export async function loadAccess(db: SQLiteDatabase): Promise<AccessState> {
  let row = await db.getFirstAsync<{ trial_started_at: string; premium: number }>(
    'SELECT trial_started_at, premium FROM app_access WHERE id = 1'
  );
  if (!row) {
    const now = new Date().toISOString();
    await db.runAsync('INSERT INTO app_access (id, trial_started_at, premium) VALUES (1, ?, 0)', [now]);
    row = { trial_started_at: now, premium: 0 };
  }
  return computeAccess(row.trial_started_at, row.premium === 1);
}

export async function setPremium(db: SQLiteDatabase, value: boolean): Promise<void> {
  await db.runAsync('UPDATE app_access SET premium = ? WHERE id = 1', [value ? 1 : 0]);
}
