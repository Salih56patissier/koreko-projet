import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useSQLiteContext } from 'expo-sqlite';
import { AccessState, loadAccess } from './access';
import { useI18n } from '../i18n/I18nContext';

interface AccessContextValue extends AccessState {
  refresh: () => Promise<void>;
}

const AccessContext = createContext<AccessContextValue>({
  isPremium: false,
  trialDaysLeft: 0,
  canEdit: true,
  refresh: async () => {},
});

export function AccessProvider({ children }: { children: React.ReactNode }) {
  const db = useSQLiteContext();
  const [state, setState] = useState<AccessState>({ isPremium: false, trialDaysLeft: 0, canEdit: true });

  const refresh = useCallback(async () => {
    setState(await loadAccess(db));
  }, [db]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return <AccessContext.Provider value={{ ...state, refresh }}>{children}</AccessContext.Provider>;
}

export function useAccess(): AccessContextValue {
  return useContext(AccessContext);
}

// Renvoie une fonction à appeler avant toute action de création/modification : true = c'est
// permis, false = essai terminé (une alerte propose alors de voir les formules).
export function useEditGuard(): () => boolean {
  const { canEdit } = useAccess();
  const { t } = useI18n();
  const navigation = useNavigation<any>();
  return useCallback(() => {
    if (canEdit) return true;
    Alert.alert(
      t('Essai gratuit terminé'),
      t('Tes 3 mois gratuits sont terminés. Tu peux toujours consulter tes données ; passe à la version premium pour créer et modifier.'),
      [
        { text: t('Plus tard'), style: 'cancel' },
        { text: t('Voir les formules'), onPress: () => navigation.navigate('Premium') },
      ]
    );
    return false;
  }, [canEdit, t, navigation]);
}
