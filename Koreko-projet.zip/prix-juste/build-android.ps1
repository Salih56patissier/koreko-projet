# Construit Koreko pour Android, en version PERSONNELLE (la tienne) ou PUBLIQUE (vide, pour le Play Store).
#
#   .\build-android.ps1 -Edition personal   # ton APK, avec tes catégories et ton historique (par défaut)
#   .\build-android.ps1 -Edition public     # version vide : exemples seulement, AUCUNE donnée personnelle
#   .\build-android.ps1 -Edition public -Task bundleRelease   # fichier .aab pour le Play Store
#
# Pense à augmenter versionCode dans android/app/build.gradle avant chaque build.
# Le fichier src/db/personalData.ts (tes données) n'est pas embarqué dans l'édition publique.
param(
  [ValidateSet('personal', 'public')] [string] $Edition = 'personal',
  [ValidateSet('assembleRelease', 'bundleRelease')] [string] $Task = 'assembleRelease'
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

# Java 17 : le Java 25 d'Android Studio fait échouer le build.
$env:JAVA_HOME = 'C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot'
$env:EXPO_PUBLIC_KOREKO_EDITION = $Edition

# L'édition est lue à la compilation du JavaScript : sans ce nettoyage, Metro réutiliserait le
# résultat de l'édition précédente (même variable, même fichier = même cache).
Write-Host "Nettoyage du cache JavaScript..."
Get-ChildItem $env:TEMP -Filter 'metro-*' -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem $env:TEMP -Filter 'haste-map-*' -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$root\node_modules\.cache" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$root\android\app\build\generated\assets" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$root\android\app\build\intermediates\assets" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$root\android\app\build\intermediates\sourcemaps" -ErrorAction SilentlyContinue

Write-Host "Vérification du code..."
Push-Location $root
npx tsc --noEmit
if ($LASTEXITCODE -ne 0) { Pop-Location; throw "Le code contient des erreurs : build annulé." }

Write-Host "Build Android ($Edition, $Task)..."
Push-Location "$root\android"
.\gradlew.bat $Task
$code = $LASTEXITCODE
Pop-Location
Pop-Location
if ($code -ne 0) { throw "Le build a échoué (code $code). Relance-le : un fichier verrouillé par Windows suffit parfois." }

if ($Task -eq 'assembleRelease') {
  Write-Host "APK : $root\android\app\build\outputs\apk\release\app-release.apk"
} else {
  Write-Host "AAB : $root\android\app\build\outputs\bundle\release\app-release.aab"
}
